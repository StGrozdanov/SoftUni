export function isValid(formData) {
    let entries = Object.fromEntries(formData);
    return !Object.values(entries).some(field => field === '');
}