import { useContext } from "react";
import { useNavigate } from "react-router-dom";
import { UserContext } from "../contexts/UserContext";
import { isValid } from '../utils/formValidator'

export default async function useUserForms(event, userServiceFunction) {
    const [user, setUser] = useContext(UserContext);
    const navigate = useNavigate()

    if (event !== null) {
        event.preventDefault();
        const formData = new FormData(event.target);

        let data = Object.fromEntries(formData);

        if (isValid(formData)) {
            const loggedUser = await userServiceFunction(data);
            setUser(loggedUser);
            navigate('/')
        } else {
            alert('All fields are required!');
        }
    }
}