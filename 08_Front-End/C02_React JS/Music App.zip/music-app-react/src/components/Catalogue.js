import { useEffect, useState } from "react";
import {getAllAlbums} from '../services/albumService';
import CatalogueCard from "./CatalogueCard";
import { v4 as uuid } from "uuid";

export default function Catalogue() {
  const [albums, setAlbums] = useState({});

  useEffect(() => {
      getAllAlbums().then(response => setAlbums(response));
  }, []);

    return (
        <section id="catalogPage">
        <h1>All Albums</h1>
        {
        albums.length > 0
        ? albums.map(album => <CatalogueCard key={uuid()} album={album} />) 
        : <p>No Albums in Catalog!</p>
        }
      </section>
    );
}