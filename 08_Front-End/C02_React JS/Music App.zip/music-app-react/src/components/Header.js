import { useContext, useEffect } from "react";
import { NavLink } from "react-router-dom";
import { UserContext } from "../contexts/UserContext";

export default function Header() {
  const [user, setUser] = useContext(UserContext);

  useEffect(() => {
    setUser(user);
  }, [user]);

  function logoutHandler(e) {
    e.preventDefault();

    setUser({});
  }

  const userView = (
    <>
      <li><NavLink to="/create">Create Album</NavLink></li>
      <li><NavLink to="javascript:void[0]" onClick={logoutHandler}>Logout</NavLink></li>
    </>
  );

  const guestView = (
    <>
      <li><NavLink to="/login">Login</NavLink></li>
      <li><NavLink to="/register">Register</NavLink></li>
    </>
  );

  return (
    <header>
      <nav>
        <img src="./images/headphones.png" />
        <NavLink to='/'>Home</NavLink>
        <ul>
          <li><NavLink to="/catalogue">Catalog</NavLink></li>
          <li><NavLink to="/search">Search</NavLink></li>
          {user.email ? userView : guestView}
        </ul>
      </nav>
    </header>
  );
}