import { useContext, useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { UserContext } from '../contexts/UserContext'
import { deleteAlbum, getSingleAlbum } from "../services/albumService";

export default function Details() {
    const [user, setUser] = useContext(UserContext);
    const { id } = useParams();
    const [album, setAlbum] = useState({});
    const navigate = useNavigate();

    useEffect(() => {
        getSingleAlbum(id, user.accessToken).then(album => setAlbum(album));
    }, []);

    const ownerTemplate = (
        <div className="actionBtn">
            <Link to={`/edit/${id}`} className="edit">Edit</Link>
            <a href="javascript:void[0]" onClick={deleteHandler} className="remove">Delete</a>
        </div>
    );

    async function deleteHandler(e) {
        e.preventDefault();

        let confirmed = window.confirm(`Are you sure you want to delete ${album.name} ?`);
        if (confirmed) {
            await deleteAlbum(id, user.accessToken);
            navigate('/catalogue');
        }
    }

    return (
        <section id="detailsPage">
            <div className="wrapper">
                <div className="albumCover">
                    <img src={album.imgUrl} />
                </div>
                <div className="albumInfo">
                    <div className="albumText">
                        <h1>Name: {album.name}</h1>
                        <h3>Artist: {album.artist}</h3>
                        <h4>Genre: {album.genre}</h4>
                        <h4>Price: ${album.price}</h4>
                        <h4>Date: {album.releaseDate}</h4>
                        <p>Description: {album.description}</p>
                    </div>
                    {
                        album._ownerId === user._id
                            ? ownerTemplate
                            : null
                    }
                </div>
            </div>
        </section>
    );
}