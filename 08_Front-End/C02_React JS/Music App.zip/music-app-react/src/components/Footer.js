export default function Footer() {
    return (
        <footer>
            <div>
                &copy;SoftUni Team 2021. All rights reserved.
            </div>
        </footer>
    );
}