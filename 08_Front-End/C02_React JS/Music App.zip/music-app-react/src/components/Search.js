import { useContext, useEffect, useState } from "react";
import { findAlbum } from "../services/albumService";
import { v4 as uuid } from "uuid";
import CatalogueCard from '../components/CatalogueCard'

export default function Search() {
    const [albums, setAlbums] = useState({});
    const [noResultsField, setNoResultsField] = useState(null);

    useEffect(() => {
        let noResultField = document.querySelector('.no-result');
        noResultField.style.display = 'none';
        setNoResultsField(noResultField);
    }, []);

    async function searchHandler(e) {
        e.preventDefault();

        noResultsField.style.display = 'block';

        const inputField = document.getElementById('search-input');
        const query = inputField.value;
        if (query.trim() !== '') {
            const albumsFound = await findAlbum(query);
            setAlbums(albumsFound);
        } else {
            alert('Try with words this time :)')
        }
    }

    return (
        <section id="searchPage">
            <h1>Search by Name</h1>

            <div className="search">
                <input id="search-input" type="text" name="search" placeholder="Enter desired albums's name" />
                <button onClick={searchHandler} className="button-list">Search</button>
            </div>

            <h2>Results:</h2>

            <div className="search-result">
                {
                    albums.length > 0
                        ? albums.map(album => <CatalogueCard key={uuid()} album={album} />)
                        : <p className="no-result">No result.</p>
                }
            </div>
        </section>
    );
}