import { useContext } from "react";
import { useNavigate } from "react-router-dom";
import { UserContext } from "../contexts/UserContext";
import { register } from '../services/userService'
import { isValid } from '../utils/formValidator'

export default function Register() {
  const [user, setUser] = useContext(UserContext);
  const navigate = useNavigate()

  async function registerHandler(e) {
    e.preventDefault();
    const formData = new FormData(e.target);

    let { email, password, confirm } = Object.fromEntries(formData);

    if (isValid(formData)) {
      if (password === confirm) {
        const loggedUser = await register(email, password);
        setUser(loggedUser);
        navigate('/');
      } else {
        alert('passwords don\'t match!');
        throw new Error();
      }
    } else {
      alert('All fields are required!');
    }
  }

  return (
    <section id="registerPage">
      <form onSubmit={registerHandler}>
        <fieldset>
          <legend>Register</legend>

          <label for="email" className="vhide">Email</label>
          <input id="email" className="email" name="email" type="text" placeholder="Email" />

          <label for="password" className="vhide">Password</label>
          <input id="password" className="password" name="password" type="password" placeholder="Password" />

          <label for="conf-pass" className="vhide">Confirm Password:</label>
          <input id="conf-pass" className="conf-pass" name="confirm" type="password" placeholder="Confirm Password" />

          <button type="submit" className="register">Register</button>

          <p className="field">
            <span>If you already have profile click <a href="#">here</a></span>
          </p>
        </fieldset>
      </form>
    </section>
  );
}