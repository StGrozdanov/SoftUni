import { useContext, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { login } from "../services/userService";
import { isValid } from "../utils/formValidator";
import { UserContext } from '../contexts/UserContext'

export default function Login() {
  const [user, setUser] = useContext(UserContext);
  const navigate = useNavigate()

  async function loginHandler(e) {
    e.preventDefault();
    const formData = new FormData(e.target);

    let { email, password } = Object.fromEntries(formData);

    if (isValid(formData)) {
      const loggedUser = await login(email, password);
      setUser(loggedUser);
      navigate('/');
    } else {
      alert('All fields are required!');
    }
  }

  return (
    <section id="loginPage">
      <form onSubmit={loginHandler}>
        <fieldset>
          <legend>Login</legend>

          <label htmlFor="email" className="vhide">Email</label>
          <input id="email" className="email" name="email" type="text" placeholder="Email" />

          <label htmlFor="password" className="vhide">Password</label>
          <input id="password" className="password" name="password" type="password" placeholder="Password" />

          <button type="submit" className="login">Login</button>

          <p className="field">
            <span>If you don't have profile click <Link to="/register">here</Link></span>
          </p>
        </fieldset>
      </form>
    </section>
  );
}