import { useContext, useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { UserContext } from "../contexts/UserContext";
import { editAlbum, getSingleAlbum } from "../services/albumService";
import { isValid } from "../utils/formValidator";

export default function Edit() {
    const [user, setUser] = useContext(UserContext);
    const [album, setAlbum] = useState({});
    const navigate = useNavigate();
    const { id } = useParams();

    useEffect(() => {
        getSingleAlbum(id, user.accessToken).then(targetAlbum => setAlbum(targetAlbum));
    });

    async function editHandler(e) {
        e.preventDefault();
        const formData = new FormData(e.target);
    
        let data = Object.fromEntries(formData);

        if (isValid(formData)) {
            await editAlbum(id, user.accessToken, data);
            navigate(`/details/${id}`);
        } else {
            alert('All fields are required!');
        }
    }

    return (
        <section className="editPage">
            <form onSubmit={editHandler}>
                <fieldset>
                    <legend>Edit Album</legend>

                    <div className="container">
                        <label for="name" className="vhide">Album name</label>
                        <input id="name" name="name" className="name" type="text" defaultValue={album.name} />

                        <label for="imgUrl" className="vhide">Image Url</label>
                        <input id="imgUrl" name="imgUrl" className="imgUrl" type="text" defaultValue={album.imgUrl} />

                        <label for="price" className="vhide">Price</label>
                        <input id="price" name="price" className="price" type="text" defaultValue={album.price} />

                        <label for="releaseDate" className="vhide">Release date</label>
                        <input id="releaseDate" name="releaseDate" className="releaseDate" type="text" defaultValue={album.releaseDate} />

                        <label for="artist" className="vhide">Artist</label>
                        <input id="artist" name="artist" className="artist" type="text" defaultValue={album.artist} />

                        <label for="genre" className="vhide">Genre</label>
                        <input id="genre" name="genre" className="genre" type="text" defaultValue={album.genre} />

                        <label for="description" className="vhide">Description</label>
                        <textarea name="description" className="description" rows="10"
                            cols="10" defaultValue={album.description}></textarea>
                        <button className="edit-album" type="submit">Edit Album</button>
                    </div>
                </fieldset>
            </form>
        </section>
    );
}