import Catalogue from "./components/Catalogue";
import Create from "./components/Create";
import Details from "./components/Details";
import Footer from "./components/Footer";
import Header from "./components/Header";
import Landing from "./components/Landing";
import Login from './components/Login'
import Register from './components/Register'
import Search from "./components/Search";
import Edit from './components/Edit'
import { Routes, Route } from "react-router-dom";
import { useState } from "react";
import { UserContext } from './contexts/UserContext'

function App() {
  let [user, setUser] = useState({});

  return (
    <>
      <UserContext.Provider value={[user, setUser]}>
        <Header />
        <Routes>
          <Route path="/" element={<Landing />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/create" element={<Create />} />
          <Route path="/catalogue" element={<Catalogue />} />
          <Route path="/edit/:id" element={<Edit />} />
          <Route path="/details/:id" element={<Details />} />
          <Route path="/search" element={<Search />} />
        </Routes>
      </UserContext.Provider>
      <Footer />
    </>
  );
}

export default App;