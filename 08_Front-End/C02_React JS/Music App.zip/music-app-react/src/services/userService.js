import { BASE_URL } from './softuniService'

const USER_ENDPOINTS = {
    LOGIN: '/users/login',
    REGISTER: '/users/register',
}

export async function login(email, password) {
    const response = await fetch(BASE_URL + USER_ENDPOINTS.LOGIN, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ email, password })
    })
    if (response.ok) {
        return response.json();
    } else {
        const error = await response.json();
        alert(error.message);
        throw new Error(error.message);
    }
}

export async function register(email, password) {
    const response = await fetch(BASE_URL + USER_ENDPOINTS.REGISTER, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ email, password })
    })
    if (response.ok) {
        return response.json();
    } else {
        const error = await response.json();
        alert(error.message);
        throw new Error(error.message);
    }
}