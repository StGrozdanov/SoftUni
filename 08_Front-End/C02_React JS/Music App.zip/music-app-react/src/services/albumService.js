import { BASE_URL } from "./softuniService"

const ALBUM_ENDPOINTS = {
    ALL_ALBUMS: '/data/albums?sortBy=_createdOn%20desc&distinct=name',
    SINGLE_ALBUM: (id) => `/data/albums/${id}`,
    CREATE_ALBUM: '/data/albums',
    SEARCH: (query) => `/data/albums?where=name%20LIKE%20%22${query}%22`
}

export async function getAllAlbums() {
    const response = await fetch(BASE_URL + ALBUM_ENDPOINTS.ALL_ALBUMS);
    if (response.ok) {
        return response.json();
    } else {
        const error = await response.json();
        alert(error.message);
        throw new Error(error.message);
    }
}

export async function getSingleAlbum(id, accessToken) {
    const response = await fetch(BASE_URL + ALBUM_ENDPOINTS.SINGLE_ALBUM(id), {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
            'X-Authorization': accessToken
        }
    });
    if (response.ok) {
        return response.json();
    } else {
        const error = await response.json();
        alert(error.message);
        throw new Error(error.message);
    }
}

export async function deleteAlbum(id, accessToken) {
    const response = await fetch(BASE_URL + ALBUM_ENDPOINTS.SINGLE_ALBUM(id), {
        method: 'DELETE',
        headers: {
            'Content-Type': 'application/json',
            'X-Authorization': accessToken
        }
    });
    if (response.ok) {
        return response.json();
    } else {
        const error = await response.json();
        alert(error.message);
        throw new Error(error.message);
    }
}

export async function createAlbum(accessToken, body) {
    const response = await fetch(BASE_URL + ALBUM_ENDPOINTS.CREATE_ALBUM, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-Authorization': accessToken
        },
        body: JSON.stringify(body)
    });
    if (response.ok) {
        return response.json();
    } else {
        const error = await response.json();
        alert(error.message);
        throw new Error(error.message);
    }
}

export async function editAlbum(id, accessToken, body) {
    const response = await fetch(BASE_URL + ALBUM_ENDPOINTS.SINGLE_ALBUM(id), {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json',
            'X-Authorization': accessToken
        },
        body: JSON.stringify(body)
    });
    if (response.ok) {
        return response.json();
    } else {
        const error = await response.json();
        alert(error.message);
        throw new Error(error.message);
    }
}

export async function findAlbum(query) {
    const response = await fetch(BASE_URL + ALBUM_ENDPOINTS.SEARCH(query));
    if (response.ok) {
        return response.json();
    } else {
        const error = await response.json();
        alert(error.message);
        throw new Error(error.message);
    }
}