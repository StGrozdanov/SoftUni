export default function Footer() {
    return (
        <footer className="footer">
            <p>Created by SoftUni Delivery Team</p>
        </footer>
    );
}