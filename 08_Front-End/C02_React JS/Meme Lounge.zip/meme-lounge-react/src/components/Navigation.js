import { useContext, useEffect, useState } from "react";
import { NavLink } from "react-router-dom"
import { AuthorizationContext } from "../contexts/AuthenticationContext";

export default function Navigation() {
    const [user, setUser] = useContext(AuthorizationContext);
    const [navigationView, setNavigationView] = useState(guestNav);

    useEffect(() => {
        if (user.email) {
            setNavigationView(userNav);
        } else {
            setNavigationView(guestNav);
        }
    }, [user]);

    function userNav() {
        return (
            <div className="user">
                <NavLink to="/create-meme">Create Meme</NavLink>
                <div className="profile">
                    <span>Welcome, {user.email}</span>
                    <NavLink to="/my-profile">My Profile</NavLink>
                    <NavLink to="/logout">Logout</NavLink>
                </div>
            </div>
        );
    }

    function guestNav() {
        return (
            <div className="guest">
                <div className="profile">
                    <NavLink to="/login">Login</NavLink>
                    <NavLink to="/register">Register</NavLink>
                </div>
                <NavLink to="/">Home Page</NavLink>
            </div>
        );
    }

    return (
        <nav>
            <NavLink to='/catalogue'>All Memes</NavLink>
            {navigationView}
        </nav>
    );
}