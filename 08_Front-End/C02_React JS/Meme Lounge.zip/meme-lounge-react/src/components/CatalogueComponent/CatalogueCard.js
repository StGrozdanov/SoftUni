import { NavLink } from "react-router-dom";

export default function CatalogueCard({ info }) {
    const memeAdress = `/details/${info._id}`;

    return (
        <div className="meme">
            <div className="card">
                <div className="info">
                    <p className="meme-title">{info.title}</p>
                    <img className="meme-image" alt="meme-img" src={info.imageUrl} />
                </div>
                <div id="data-buttons">
                    <NavLink className="button" to={memeAdress}>Details</NavLink>
                </div>
            </div>
        </div>
    );
}