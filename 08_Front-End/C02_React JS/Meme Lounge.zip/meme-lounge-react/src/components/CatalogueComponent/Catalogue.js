import { useEffect, useState } from "react";
import { v4 as uuid } from "uuid";
import { getAllMemes } from "../../services/MemeService";
import CatalogueCard from "./CatalogueCard";

export default function Catalogue() {
    const [meme, setMeme] = useState([]);

    useEffect(() => {
        getAllMemes().then(response => setMeme(response));
    }, [])

    return (
        <section id="meme-feed">
            <h1>All Memes</h1>
            <div id="memes">
                {meme.length > 0
                    ? meme.map(memeInfo => <CatalogueCard key={uuid()} info={memeInfo} />)
                    : <p className="no-memes">No memes in database.</p>
                }
            </div>
        </section>
    );
}