import { useContext, useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { AuthorizationContext } from "../contexts/AuthenticationContext";
import { deleteMeme, getSingleMeme } from "../services/MemeService";

export default function Meme() {
    const [user, setUser] = useContext(AuthorizationContext);
    const [meme, setMeme] = useState([]);
    const { id } = useParams();
    const navigate = useNavigate();
    const EDIT_URL = `/edit/${id}`;

    useEffect(() => {
        getSingleMeme(id).then(response => setMeme(response));
    }, []);

    async function memeDeleteHandler() {
      let confirmed = window.confirm(`Are you sure you want to delete ${meme.title} ?`);

        if (confirmed) {
            await deleteMeme(meme._id, user.accessToken);
            navigate('/catalogue');
        }
    }

    const userDetailsView = (
        <>
            <Link to={{pathname: EDIT_URL}} className="button warning" meme={meme}>Edit</Link>
            <button className="button danger" onClick={memeDeleteHandler}>Delete</button>
        </>
    );

    return (
        <section id="meme-details">
            <h1>Meme Title: {meme.title}</h1>
            <div className="meme-details">
                <div className="meme-img">
                    <img alt="meme-alt" src={meme.imageUrl} />
                </div>
                <div className="meme-description">
                    <h2>Meme Description</h2>
                    <p>{meme.description}</p>
                    {user._id === meme._ownerId ? userDetailsView : null}
                </div>
            </div>
        </section>
    );
}