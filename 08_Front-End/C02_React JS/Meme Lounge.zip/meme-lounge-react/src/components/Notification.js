import { useEffect } from "react";

export default function Notify() {

    useEffect(() => {
        setTimeout(() => {
            <Notify style={{display: 'block'}} />
        }, 3000)
    }, []);

    return (
        <section id="notifications">
            <div id="errorBox" className="notification">
                <span>MESSAGE</span>
            </div>
        </section>
    );
}