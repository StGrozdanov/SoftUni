import { useContext, useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { userLogin } from "../services/UserService";
import useSubmitData from "../hooks/useSubmitData";

export default function Login() {
    const [submitEvent, setSubmitEvent] = useState(null);
    useSubmitData(submitEvent, userLogin, '/catalogue');

    function submitHandler(e) {
        e.preventDefault();
        setSubmitEvent(e);
    }

    return (
        <section id="login">
            <form id="login-form" onSubmit={submitHandler}>
                <div className="container">
                    <h1>Login</h1>
                    <label>Email</label>
                    <input id="email" placeholder="Enter Email" name="email" type="text" />
                    <label>Password</label>
                    <input id="password" type="password" placeholder="Enter Password" name="password" />
                    <input type="submit" className="registerbtn button" value="Login" />
                    <div className="container signin">
                        <p>Dont have an account?<Link to="/register">Sign up</Link>.</p>
                    </div>
                </div>
            </form>
        </section>
    );
}