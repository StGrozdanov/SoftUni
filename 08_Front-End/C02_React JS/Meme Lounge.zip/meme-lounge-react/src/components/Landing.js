import { NavLink } from "react-router-dom";

export default function Landing() {
    return (
        <section id="welcome">
            <div id="welcome-container">
                <h1>Welcome To Meme Lounge</h1>
                <img src="/images/welcome-meme.jpg" alt="meme" />
                <h2>Login to see our memes right away!</h2>
                <div id="button-div">
                    <NavLink to="/login" className="button">Login</NavLink>
                    <NavLink to="/register" className="button">Register</NavLink>
                </div>
            </div>
        </section>
    );
}