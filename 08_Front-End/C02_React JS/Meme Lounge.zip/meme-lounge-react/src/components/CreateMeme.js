import { useState } from "react";
import { createMeme } from "../services/MemeService";
import useSubmitDataCreate from "../hooks/useSubmitDataCreate";

export default function CreateMeme() {
    const [submitEvent, setSubmitEvent] = useState(null);
    useSubmitDataCreate(submitEvent, createMeme, '/catalogue');

    function submitHandler(e) {
        e.preventDefault();
        setSubmitEvent(e);
    }

    return (
        <section id="create-meme">
            <form id="create-form" onSubmit={submitHandler}>
                <div className="container">
                    <h1>Create Meme</h1>
                    <label htmlFor="title">Title</label>
                    <input id="title" type="text" placeholder="Enter Title" name="title" />
                    <label htmlFor="description">Description</label>
                    <textarea id="description" placeholder="Enter Description" name="description"></textarea>
                    <label htmlFor="imageUrl">Meme Image</label>
                    <input id="imageUrl" type="text" placeholder="Enter meme ImageUrl" name="imageUrl" />
                    <input type="submit" className="registerbtn button" value="Create Meme" />
                </div>
            </form>
        </section>
    );
}