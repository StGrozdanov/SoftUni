import { useContext, useState, useEffect } from "react";
import { v4 as uuid } from "uuid";
import { AuthorizationContext } from "../contexts/AuthenticationContext";
import { getUserMemes } from "../services/MemeService";
import CatalogueCard from "./CatalogueComponent/CatalogueCard";

export default function UserProfile() {
    const [user, setUser] = useContext(AuthorizationContext);
    const [memes, setMemes] = useState({});

    useEffect(() => {
        getUserMemes(user._id).then(response => setMemes(response));
    }, []);

    return (
        <section id="user-profile-page" className="user-profile">
            <article className="user-info">
                <img id="user-avatar-url" alt="user-profile" src={`/images/${user.gender}.png`} />
                <div className="user-content">
                    <p>Username: {user.username}</p>
                    <p>Email: {user.email}</p>
                    <p>My memes count: {Object.keys(memes).length}</p>
                </div>
            </article>
            <h1 id="user-listings-title">User Memes</h1>
            <div className="user-meme-listings">
                {memes.length > 0
                    ? memes.map(memeInfo => <CatalogueCard key={uuid()} info={memeInfo} />)
                    : <p className="no-memes">No memes in database.</p>
                }
            </div>
        </section>
    );
}