import { useContext, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { AuthorizationContext } from "../contexts/AuthenticationContext";

export default function Logout() {
    let [user, setUser] = useContext(AuthorizationContext);
    let navigate = useNavigate();

    useEffect(() => {
        setUser({});
        navigate('/')
    }, []);
}