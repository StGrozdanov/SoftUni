import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import useSubmitDataEdit from "../hooks/useSubmitDataEdit";
import { editMeme, getSingleMeme } from "../services/MemeService";

export default function EditMeme() {
    const [meme, setMeme] = useState({});
    const [event, setEvent] = useState(null);
    let { id } = useParams();
    useSubmitDataEdit(event, editMeme, id, `/details/${id}`);

    useEffect(() => {
        getSingleMeme(id).then(singleMeme => {
            setMeme(singleMeme);
        });
    }, [event]);

    function submitHandler(e) {
        e.preventDefault();

        setEvent(e);
    }

    return (
        <section id="edit-meme">
            <form id="edit-form" onSubmit={submitHandler}>
                <h1>Edit Meme</h1>
                <div className="container">
                    <label htmlFor="title">Title</label>
                    <input id="title" type="text" placeholder="Enter Title" name="title" defaultValue={meme.title} />
                    <label htmlFor="description">Description</label>
                    <textarea id="description" placeholder="Enter Description" name="description" defaultValue={meme.description}>
                    </textarea>
                    <label htmlFor="imageUrl">Image Url</label>
                    <input id="imageUrl" type="text" placeholder="Enter Meme ImageUrl" name="imageUrl" defaultValue={meme.imageUrl} />
                    <input type="submit" className="registerbtn button" value="Edit Meme" />
                </div>
            </form>
        </section>
    );
}