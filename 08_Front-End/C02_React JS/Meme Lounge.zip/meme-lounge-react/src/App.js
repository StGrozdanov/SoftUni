import Navigation from './components/Navigation'
import Footer from './components/Footer'
import { Routes, Route } from 'react-router-dom'
import Landing from './components/Landing'
import Login from './components/Login'
import Register from './components/Register'
import Logout from './components/Logout'
import CreateMeme from './components/CreateMeme'
import Catalogue from './components/CatalogueComponent/Catalogue'
import Meme from './components/Meme'
import EditMeme from './components/EditMeme'
import UserProfile from './components/UserProfile';
import { AuthorizationContext } from './contexts/AuthenticationContext'
import { useState } from 'react'

function App() {
  let [user, setUser] = useState({});

  return (
    <>
      <AuthorizationContext.Provider value={[user, setUser]}>
        <Navigation />
        <Routes>
          <Route path='/' element={<Landing />} />
          <Route path='/login' element={<Login />} />
          <Route path='/register' element={<Register />} />
          <Route path='/logout' element={<Logout />} />
          <Route path='/create-meme' element={<CreateMeme />} />
          <Route path='/catalogue' element={<Catalogue />} />
          <Route path='/details/:id' element={<Meme />} />
          <Route path='/edit/:id' element={<EditMeme />} />
          <Route path='/my-profile' element={<UserProfile />} />
        </Routes>
        <Footer />
      </AuthorizationContext.Provider>
    </>
  );
}

export default App;
