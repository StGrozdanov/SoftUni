export const BASE_URL = 'http://localhost:3030';

export const BASE_HEADERS = {
    'Content-Type': 'application/json'
}

export function AUTHORIZATION (token) {
    return { 'X-Authorization': token }
}