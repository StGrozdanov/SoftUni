import { BASE_URL, BASE_HEADERS, AUTHORIZATION_HEADERS } from "./SoftUniService";
import { requestError } from "./UserService";

const MEME_ENDPOINTS = {
    GET_ALL: '/data/memes?sortBy=_createdOn%20desc',
    CREATE: '/data/memes',
    GET_SINGLE: (id) => `/data/memes/${id}`,
    GET_USER_COLLECTION: (id) => `/data/memes?where=_ownerId%3D%22${id}%22&sortBy=_createdOn%20desc`,
}


export async function getAllMemes() {
    const response = await fetch(BASE_URL + MEME_ENDPOINTS.GET_ALL);
    return response.json();
}

export async function getSingleMeme(id) {
    const response = await fetch(BASE_URL + MEME_ENDPOINTS.GET_SINGLE(id));
    return response.json();
}

export async function createMeme([title, description, imageUrl, userToken]) {
    const response = await fetch(BASE_URL + MEME_ENDPOINTS.CREATE, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            "X-Authorization": userToken
        },
        body: JSON.stringify({ title, description, imageUrl })
    });
    if (response.ok) {
        return response.json();
    } else {
        const error = await response.json();
        requestError(error);
    }
}

export async function deleteMeme(id, userToken) {
    const response = await fetch(BASE_URL + MEME_ENDPOINTS.GET_SINGLE(id), {
        method: 'DELETE',
        headers: {
            'Content-Type': 'application/json',
            "X-Authorization": userToken
        }
    });
    if (response.ok) {
        return response.json();
    } else {
        const error = await response.json();
        requestError(error);
    }
}

export async function editMeme(id, [title, description, imageUrl, userToken]) {
    const response = await fetch(BASE_URL + MEME_ENDPOINTS.GET_SINGLE(id), {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json',
            "X-Authorization": userToken
        },
        body: JSON.stringify({ title, description, imageUrl })
    });
    if (response.ok) {
        return response.json();
    } else {
        const error = await response.json();
        requestError(error);
    }
}

export async function getUserMemes(userId) {
    const response = await fetch(BASE_URL + MEME_ENDPOINTS.GET_USER_COLLECTION(userId));
    if (response.ok) {
        return response.json();
    } else {
        const error = await response.json();
        requestError(error);
    }
}