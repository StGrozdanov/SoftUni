import { BASE_URL, BASE_HEADERS } from './SoftUniService'

const USERS_ENDPOINTS = {
    LOGIN: '/users/login',
    REGISTER: '/users/register',
    USER_DETAILS: 'users/me',
}

export async function userLogin([email, password]) {
    const response = await fetch(BASE_URL + USERS_ENDPOINTS.LOGIN, {
        method: 'POST',
        headers: BASE_HEADERS,
        body: JSON.stringify({ email, password })
    });
    if (response.ok) {
        return response.json();
    } else {
        const error = await response.json();
        requestError(error);
    }
}

export async function userRegister([username, email, password, gender]) {
    const response = await fetch(BASE_URL + USERS_ENDPOINTS.REGISTER, {
        method: 'POST',
        headers: BASE_HEADERS,
        body: JSON.stringify({ username, email, password, gender })
    });

    return response.ok ? response.json() : requestError(response);
}

export function requestError(request) {
    alert(request.message);
    throw new Error();
}