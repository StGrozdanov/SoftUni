import * as formDataValidator from './formDataValidator'

export async function submitMemeDataAuthorize(formData, fetchFunction, user, id) {
    const formDataValuesAsObject = Object.fromEntries(formData);
    const formDataValues = Object.values(formDataValuesAsObject);

    if (formDataValidator.isInvalid(formData)) {
        window.alert('All fields are required!');
        throw new Error
    }
    
    return await fetchFunction(id, [...formDataValues, user.accessToken]);
}