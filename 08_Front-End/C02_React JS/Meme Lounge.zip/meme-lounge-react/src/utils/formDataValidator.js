export function isInvalid(formData) {
    const formEntries = Object.fromEntries(formData);

    const formValues = Object.values(formEntries);

    return formValues.some(field => field === '');
}