import { useContext, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { AuthorizationContext } from "../contexts/AuthenticationContext";
import submitUserData from "../utils/submitUserData";
import useSubmitHandler from "./useSubmitHandler";

export default function useSubmitData(event, fetchUserFunction, location) {
    const [user, setUser] = useContext(AuthorizationContext);
    let formData = useSubmitHandler(event);
    const navigate = useNavigate();

    useEffect(() => {
        if (event !== null) {
            submitUserData(formData, fetchUserFunction)
                .then(newUser => {
                    setUser(newUser);
                    navigate(location);
                });
        }
    }, [event]);
}