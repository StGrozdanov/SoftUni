import { useContext, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { AuthorizationContext } from "../contexts/AuthenticationContext";
import { submitMemeDataAuthorize } from "../utils/submitMemeData";
import { submitUserDataAuthorize } from "../utils/submitUserData";
import useSubmitHandler from "./useSubmitHandler";


export default function useSubmitDataEdit(event, fetchUserFunction, id, location) {
    const [user, setUser] = useContext(AuthorizationContext);
    let formData = useSubmitHandler(event);
    const navigate = useNavigate();

    useEffect(() => {
        if (event !== null) {
            submitMemeDataAuthorize(formData, fetchUserFunction, user, id)
                .then(response => {
                    navigate(location);
                });
        }
    }, [event]);
}