export default function useSubmitHandler(e) {
    if (e !== null) {
        e.preventDefault();
        return new FormData(e.target);
    }
    return null
}