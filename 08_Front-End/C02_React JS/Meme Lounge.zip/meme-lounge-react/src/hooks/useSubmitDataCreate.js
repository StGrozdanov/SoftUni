import { useContext, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { AuthorizationContext } from "../contexts/AuthenticationContext";
import { submitUserDataAuthorize } from "../utils/submitUserData";
import useSubmitHandler from "./useSubmitHandler";


export default function useSubmitDataCreate(event, fetchUserFunction, location) {
    const [user, setUser] = useContext(AuthorizationContext);
    let formData = useSubmitHandler(event);
    const navigate = useNavigate();

    useEffect(() => {
        if (event !== null) {
            submitUserDataAuthorize(formData, fetchUserFunction, user)
                .then(response => {
                    navigate(location);
                });
        }
    }, [event]);
}