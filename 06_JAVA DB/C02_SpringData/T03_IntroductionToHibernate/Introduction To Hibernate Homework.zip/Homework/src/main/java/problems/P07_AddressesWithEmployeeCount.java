package problems;

import core.BaseTools;
import entities.Address;
import interfaces.Problem;

import javax.persistence.EntityManager;

public class P07_AddressesWithEmployeeCount extends BaseTools implements Problem {
    public P07_AddressesWithEmployeeCount(EntityManager manager) {
        super(manager);
    }

    @Override
    public void solve() {
        super.entityManager
                .createQuery("SELECT a FROM Address a ORDER BY a.employees.size DESC", Address.class)
                .setMaxResults(10)
                .getResultStream()
                .forEach(address -> System.out.printf("%s, %s - %d employees%n", address.getText(),
                                                                                 address.getTown().getName(),
                                                                                 address.getEmployees().size()));
    }
}
