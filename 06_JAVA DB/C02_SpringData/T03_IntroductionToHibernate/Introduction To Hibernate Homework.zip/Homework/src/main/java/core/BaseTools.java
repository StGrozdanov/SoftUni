package core;

import javax.persistence.EntityManager;
import java.util.Scanner;

public abstract class BaseTools {
    protected Scanner scanner;
    protected EntityManager entityManager;

    protected BaseTools(EntityManager manager) {
        this.scanner = new Scanner(System.in);
        this.entityManager = manager;
    }
}
