package problems;

import core.BaseTools;
import entities.Employee;
import interfaces.Problem;

import javax.persistence.EntityManager;
import java.util.List;

public class P03_ContainsEmployee extends BaseTools implements Problem {
    public P03_ContainsEmployee(EntityManager manager) {
        super(manager);
    }

    @Override
    public void solve() {
        System.out.println("Enter the first and second name, separated by space of the employee you are looking for in the database");
        String[] tokens = super.scanner.nextLine().split("\\s+");
        String firstName = tokens[0];
        String lastName = tokens[1];

        List<Employee> matchedEmployees = super.entityManager
                                                    .createQuery("SELECT e FROM Employee e WHERE " +
                                                    "e.firstName = :firstName AND e.lastName = :lastName", Employee.class)
                                                    .setParameter("firstName", firstName)
                                                    .setParameter("lastName", lastName)
                                                    .getResultList();

        String queryResult = matchedEmployees.isEmpty() ? "No" : "Yes";

        System.out.println(queryResult);
    }
}
