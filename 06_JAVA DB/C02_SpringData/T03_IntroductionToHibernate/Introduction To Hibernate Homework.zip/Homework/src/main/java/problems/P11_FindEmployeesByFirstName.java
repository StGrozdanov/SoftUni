package problems;

import core.BaseTools;
import entities.Employee;
import interfaces.Problem;

import javax.persistence.EntityManager;
import java.util.List;

public class P11_FindEmployeesByFirstName extends BaseTools implements Problem {
    public P11_FindEmployeesByFirstName(EntityManager manager) {
        super(manager);
    }

    @Override
    public void solve() {
        System.out.println("What are the starting letters of the employee first name you are looking for?");
        String letters =  super.scanner.nextLine();

        String criteriaSymbol = "%";
        String startingLettersPattern = letters + criteriaSymbol;

        List<Employee> matchedEmployees = super.entityManager
                .createQuery("SELECT e FROM Employee e WHERE e.firstName LIKE :pattern", Employee.class)
                .setParameter("pattern", startingLettersPattern)
                .getResultList();

        if (matchedEmployees.isEmpty()) {
            System.out.println("No employees matching your criteria were found");
        }
        matchedEmployees.forEach(employee -> System.out.printf("%s %s - %s - ($%.2f)%n", employee.getFirstName(),
                                                                                         employee.getLastName(),
                                                                                         employee.getJobTitle(),
                                                                                         employee.getSalary()));
    }
}
