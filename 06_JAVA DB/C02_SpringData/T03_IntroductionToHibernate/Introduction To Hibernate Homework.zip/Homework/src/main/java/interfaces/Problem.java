package interfaces;

public interface Problem {
    void solve();
}
