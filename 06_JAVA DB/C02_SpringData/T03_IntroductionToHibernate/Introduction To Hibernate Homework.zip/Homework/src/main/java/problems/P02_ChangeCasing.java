package problems;

import core.BaseTools;
import interfaces.Problem;

import javax.persistence.EntityManager;

public class P02_ChangeCasing extends BaseTools implements Problem {
    public P02_ChangeCasing(EntityManager manager) {
        super(manager);
    }

    @Override
    public void solve() {
        super.entityManager.getTransaction().begin();

        int affectedRows = super.entityManager
                .createQuery("UPDATE Town t SET t.name = UPPER(t.name) WHERE LENGTH(t.name) <= 5")
                .executeUpdate();

        super.entityManager.getTransaction().commit();

        System.out.printf("%d rows affected.%n", affectedRows);
    }
}
