package core;

import interfaces.Problem;
import problems.*;

import javax.persistence.EntityManager;
import java.util.LinkedHashMap;
import java.util.Map;

public class Engine extends BaseTools implements Runnable {
    public Engine(EntityManager manager) {
        super(manager);
    }

    @Override
    public void run() {
        System.out.println("Please, write down the exercise number you want to test - from 2 to 13");

        String input = super.scanner.nextLine();

        while (!input.equals("finish")) {
            int exerciseNumber = 0;
            try {
                exerciseNumber = Integer.parseInt(input);
            } catch (NumberFormatException e) {
                System.out.println("Try with a number this time :)");
            }
            testExerciseProblems(exerciseNumber, super.entityManager);
            System.out.println("Please enter the next exercise number you want to test or the same exercise number " +
                    "as the previous if you want to test the exercise with different input or write finish to end the " +
                    "program");
            input = super.scanner.nextLine();
        }
    }

    private static void testExerciseProblems(int problemNumber, EntityManager em) {
        Map<Integer, Problem> problemMap = new LinkedHashMap<>(Map.of(
                2, new P02_ChangeCasing(em),
                3, new P03_ContainsEmployee(em),
                4, new P04_EmployeesWithSalaryOver50K(em),
                5, new P05_EmployeesFromDepartment(em),
                6, new P06_AddingANewAddressAndUpdatingEmployee(em),
                7, new P07_AddressesWithEmployeeCount(em),
                8, new P08_GetEmployeeWithProject(em),
                9, new P09_FindLatest10Projects(em),
                10, new P10_IncreaseSalaries(em),
                11, new P11_FindEmployeesByFirstName(em)
        ));

        problemMap.put(12, new P12_EmployeesMaximumSalaries(em));
        problemMap.put(13, new P13_RemoveTowns(em));

        try {
            problemMap.get(problemNumber).solve();
        } catch (NullPointerException e) {
            System.out.println("There isn't such exercise number in my homework :)");
        }
    }
}