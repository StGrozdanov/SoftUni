package problems;

import core.BaseTools;
import entities.Address;
import entities.Employee;
import interfaces.Problem;

import javax.persistence.EntityManager;
import javax.persistence.Query;

public class P06_AddingANewAddressAndUpdatingEmployee extends BaseTools implements Problem {
    public P06_AddingANewAddressAndUpdatingEmployee(EntityManager manager) {
        super(manager);
    }

    @Override
    public void solve() {
        super.entityManager.getTransaction().begin();

        Address newAddress = new Address();
        newAddress.setText("Vitoshka 15");
        super.entityManager.persist(newAddress);

        System.out.println("What is the last name of the employee you want to give new address to?");
        String lastName = super.scanner.nextLine();

        int affectedEmployeeCount = super.entityManager
                .createQuery("UPDATE Employee e SET e.address.id = :id WHERE e.lastName = :last_name")
                .setParameter("id", newAddress.getId())
                .setParameter("last_name", lastName)
                .executeUpdate();

        super.entityManager.getTransaction().commit();

        if (affectedEmployeeCount > 0) {
            System.out.printf("%d employees were updated with a new address, %s new address is now with id: %d and name: %s%n",
                    affectedEmployeeCount, lastName, newAddress.getId(), newAddress.getText());
        } else {
            System.out.printf("No employees with last name %s were found in the database%n", lastName);
        }
    }
}
