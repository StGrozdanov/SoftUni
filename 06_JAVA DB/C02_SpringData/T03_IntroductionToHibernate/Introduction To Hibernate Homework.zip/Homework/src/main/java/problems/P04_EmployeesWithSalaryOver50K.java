package problems;

import core.BaseTools;
import interfaces.Problem;

import javax.persistence.EntityManager;

public class P04_EmployeesWithSalaryOver50K extends BaseTools implements Problem {
    public P04_EmployeesWithSalaryOver50K(EntityManager manager) {
        super(manager);
    }

    @Override
    public void solve() {
        super.entityManager
                .createQuery("SELECT e.firstName FROM Employee e WHERE e.salary > 50000")
                .getResultStream()
                .forEach(System.out::println);
    }
}
