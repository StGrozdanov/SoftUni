package problems;

import core.BaseTools;
import entities.Employee;
import entities.Project;
import interfaces.Problem;

import javax.persistence.EntityManager;
import java.util.Comparator;

public class P08_GetEmployeeWithProject extends BaseTools implements Problem {
    public P08_GetEmployeeWithProject(EntityManager manager) {
        super(manager);
    }

    @Override
    public void solve() {
        System.out.println("What is the id of the employee you are looking for?");
        int id = Integer.parseInt(super.scanner.nextLine());

        Employee targetEmployee = super.entityManager.find(Employee.class, id);

        if (targetEmployee == null) {
            System.out.printf("Employee with id %d is not found in the database.%n", id);
        } else {
            System.out.printf("%s %s - %s%n", targetEmployee.getFirstName(),
                                              targetEmployee.getLastName(),
                                              targetEmployee.getJobTitle());
            targetEmployee
                    .getProjects()
                    .stream()
                    .sorted(Comparator.comparing(Project::getName))
                    .forEach(project -> System.out.println(project.getName()));
        }
    }
}
