package problems;

import core.BaseTools;
import entities.Project;
import interfaces.Problem;

import javax.persistence.EntityManager;
import java.time.format.DateTimeFormatter;

public class P09_FindLatest10Projects extends BaseTools implements Problem {
    public P09_FindLatest10Projects(EntityManager manager) {
        super(manager);
    }

    @Override
    public void solve() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.S");

        super.entityManager
                .createQuery("SELECT p FROM Project p ORDER BY p.startDate DESC, p.name", Project.class)
                .setMaxResults(10)
                .getResultList()
                .forEach(project -> System.out.printf("Project name: %s%n   Project Description: %s%n   Project Start Date: %s%n" +
                        "   Project End Date: %s%n", project.getName(),
                                                     project.getDescription(),
                                                     project.getStartDate().format(formatter),
                                                     project.getEndDate() == null
                                                                             ? null
                                                                             : project.getEndDate().format(formatter)));
    }
}
