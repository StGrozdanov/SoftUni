package problems;

import core.BaseTools;
import entities.Address;
import entities.Town;
import interfaces.Problem;

import javax.persistence.EntityManager;

public class P13_RemoveTowns extends BaseTools implements Problem {
    public P13_RemoveTowns(EntityManager manager) {
        super(manager);
    }

    @Override
    public void solve() {
        System.out.println("What is the name of the town you want to remove?");
        String targetTownName = super.scanner.nextLine();

        try {
            Town townToRemove = findTownByName(targetTownName);

            detachEmployeesFromTargetAddressesByTownId(townToRemove.getId());

            int removedAddressesCount = removeAddressesByTownId(townToRemove.getId());

            removeTargetTown(townToRemove);

            if (removedAddressesCount > 1) {
                System.out.printf("%d addresses in %s deleted%n", removedAddressesCount, townToRemove.getName());
            } else {
                System.out.printf("%d address in %s deleted%n", removedAddressesCount, townToRemove.getName());
            }

        } catch (Exception e) {
            System.out.println("No such town is found in the database");
        }
    }

    private Town findTownByName(String targetTown) {
        return super.entityManager
                                .createQuery("SELECT t FROM Town t WHERE t.name = :target", Town.class)
                                .setParameter("target", targetTown)
                                .getSingleResult();
    }

    private void removeTargetTown(Town townToRemove) {
        super.entityManager.getTransaction().begin();

        super.entityManager.remove(townToRemove);

        super.entityManager.getTransaction().commit();
    }

    private void detachEmployeesFromTargetAddressesByTownId(Integer townId) {
        super.entityManager.getTransaction().begin();

        super.entityManager
                        .createQuery("SELECT a FROM Address a WHERE a.town.id = :id", Address.class)
                        .setParameter("id", townId)
                        .getResultList()
                        .forEach(address -> address
                                                .getEmployees()
                                                .forEach(employee -> employee.setAddress(null)));

        super.entityManager.getTransaction().commit();
    }

    private int removeAddressesByTownId(Integer targetId) {
        super.entityManager.getTransaction().begin();

        int affectedAddressCount = super.entityManager
                                                    .createQuery("DELETE FROM Address a WHERE a.town.id = :town_id")
                                                    .setParameter("town_id", targetId)
                                                    .executeUpdate();

        super.entityManager.getTransaction().commit();

        return affectedAddressCount;
    }
}
