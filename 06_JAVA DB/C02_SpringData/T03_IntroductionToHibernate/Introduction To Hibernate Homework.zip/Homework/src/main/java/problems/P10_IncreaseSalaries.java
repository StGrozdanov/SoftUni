package problems;

import core.BaseTools;
import entities.Employee;
import interfaces.Problem;

import javax.persistence.EntityManager;
import java.util.Set;

public class P10_IncreaseSalaries extends BaseTools implements Problem {
    public P10_IncreaseSalaries(EntityManager manager) {
        super(manager);
    }

    @Override
    public void solve() {
        Set<String> targetDepartments = Set.of("Engineering", "Tool Design", "Marketing", "Information Services");

        super.entityManager.getTransaction().begin();

        super.entityManager
                .createQuery("UPDATE Employee e SET e.salary = e.salary * 1.12 WHERE e.department.id IN :depart_ids")
                .setParameter("depart_ids", Set.of(1, 2, 4, 11))
                .executeUpdate();

        super.entityManager.getTransaction().commit();

        super.entityManager
                .createQuery("SELECT e FROM Employee e WHERE e.department.name IN :depart_names", Employee.class)
                .setParameter("depart_names", targetDepartments)
                .getResultList()
                .forEach(employee -> System.out.printf("%s %s ($%.2f)%n", employee.getFirstName(),
                                                                          employee.getLastName(),
                                                                          employee.getSalary()));

    }
}
