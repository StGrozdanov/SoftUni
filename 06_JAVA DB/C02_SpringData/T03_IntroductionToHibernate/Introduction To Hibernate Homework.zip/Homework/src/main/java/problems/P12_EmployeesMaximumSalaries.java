package problems;

import core.BaseTools;
import interfaces.Problem;

import javax.persistence.EntityManager;

public class P12_EmployeesMaximumSalaries extends BaseTools implements Problem {
    public P12_EmployeesMaximumSalaries(EntityManager manager) {
        super(manager);
    }

    @Override
    public void solve() {
        super.entityManager
                .createQuery("SELECT d.name, MAX(e.salary) " +
                                "FROM Employee AS e " +
                                "JOIN Department AS d " +
                                "ON d.id = e.department.id " +
                                "GROUP BY d.id " +
                                "HAVING MAX(e.salary) NOT BETWEEN 30000 AND 70000 ", Object[].class)
                .getResultList()
                .forEach(employee -> System.out.println(employee[0] + " " + employee[1]));

        //TODO: Ако някой има идея как се подкарва долният код да вади очакваните резултати да пише...
//        super.entityManager
//                .createQuery("SELECT e FROM Employee e WHERE e.salary NOT BETWEEN 30000 AND 70000 " +
//                        "GROUP BY e.department.id ORDER BY e.salary DESC", Employee.class)
//                .getResultList()
//                .forEach(employee -> System.out.printf("%s  %.2f%n", employee.getDepartment().getName(), employee.getSalary()));
    }
}
