package problems;

import core.BaseTools;
import entities.Employee;
import interfaces.Problem;

import javax.persistence.EntityManager;

public class P05_EmployeesFromDepartment extends BaseTools implements Problem {
    public P05_EmployeesFromDepartment(EntityManager manager) {
        super(manager);
    }

    @Override
    public void solve() {
        super.entityManager
                .createQuery("SELECT e FROM Employee e WHERE e.department.name = 'Research and Development' " +
                        "ORDER BY e.salary, e.id", Employee.class)
                .getResultList()
                .forEach(employee -> {
                    System.out.printf("%s %s from %s - $%.2f%n",  employee.getFirstName(),
                                                                  employee.getLastName(),
                                                                  employee.getDepartment().getName(),
                                                                  employee.getSalary()
                    );
                });

    }
}
