package softuni.springdatalab;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDataIntroLabApplicationTests {

    @Test
    void contextLoads() {
    }

}
