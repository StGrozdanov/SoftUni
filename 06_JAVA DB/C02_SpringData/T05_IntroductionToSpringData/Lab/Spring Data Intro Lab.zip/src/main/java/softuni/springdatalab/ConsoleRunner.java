package softuni.springdatalab;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import softuni.springdatalab.exceptions.InsufficientAccountBalance;
import softuni.springdatalab.exceptions.UserAlreadyExistsException;
import softuni.springdatalab.exceptions.UserNotFoundException;
import softuni.springdatalab.models.User;
import softuni.springdatalab.services.AccountService;
import softuni.springdatalab.services.UserService;

import javax.security.auth.login.AccountNotFoundException;
import java.math.BigDecimal;

@Component
public class ConsoleRunner implements CommandLineRunner {
    private final UserService userService;
    private final AccountService accountService;

    public ConsoleRunner(UserService userService, AccountService accountService) {
        this.userService = userService;
        this.accountService = accountService;
    }

    @Override
    public void run(String... args) {
//        User user = new User();
//        user.setUsername("Goshko");
//        user.setAge(18);
//
//        try {
//            this.userService.registerUser(user, new BigDecimal(1200));
//        } catch (UserAlreadyExistsException e) {
//            e.printStackTrace();
//        }
//
//        try {
//            this.userService.createNewBankAccount(BigDecimal.valueOf(500), 2L);
//        } catch (UserNotFoundException e) {
//            e.printStackTrace();
//        }
//        try {
//            this.accountService.depositMoney(BigDecimal.valueOf(250.55), 2L);
//            this.accountService.depositMoney(BigDecimal.valueOf(500), 1L);
//        } catch (AccountNotFoundException e) {
//            e.printStackTrace();
//        }
//        try {
//            this.accountService.withdrawMoney(BigDecimal.valueOf(1000), 1L);
//        } catch (AccountNotFoundException | InsufficientAccountBalance e) {
//            e.printStackTrace();
//        }
        try {
            this.userService.getUserTotalMoney(1L);
        } catch (UserNotFoundException e) {
            e.printStackTrace();
        }
        System.out.println();
    }
}
