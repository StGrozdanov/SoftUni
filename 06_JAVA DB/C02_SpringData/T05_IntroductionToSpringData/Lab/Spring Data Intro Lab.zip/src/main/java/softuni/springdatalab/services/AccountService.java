package softuni.springdatalab.services;

import softuni.springdatalab.exceptions.InsufficientAccountBalance;

import javax.security.auth.login.AccountNotFoundException;
import java.math.BigDecimal;

public interface AccountService {
    void withdrawMoney(BigDecimal amount, Long id) throws AccountNotFoundException, InsufficientAccountBalance;
    void depositMoney(BigDecimal amount, Long id) throws AccountNotFoundException;
}
