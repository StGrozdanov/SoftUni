package softuni.springdatalab.services;

import org.springframework.stereotype.Service;
import softuni.springdatalab.exceptions.InsufficientAccountBalance;
import softuni.springdatalab.models.Account;
import softuni.springdatalab.repositories.AccountRepository;

import javax.security.auth.login.AccountNotFoundException;
import java.math.BigDecimal;

@Service
public class AccountServiceImpl implements AccountService {
    private final AccountRepository accountRepository;

    public AccountServiceImpl(AccountRepository accountRepository) {
        this.accountRepository = accountRepository;
    }

    @Override
    public void withdrawMoney(BigDecimal amount, Long id) throws AccountNotFoundException, InsufficientAccountBalance {
        Account account = this.accountRepository.findById(id).orElseThrow(AccountNotFoundException::new);

        BigDecimal oldBalance = account.getBalance();
        BigDecimal newBalance = oldBalance.subtract(amount);

        if (newBalance.doubleValue() < 0) {
            throw new InsufficientAccountBalance("Not enough money in this bank account!");
        }

        account.setBalance(newBalance);
        this.accountRepository.save(account);
    }

    @Override
    public void depositMoney(BigDecimal amount, Long id) throws AccountNotFoundException {
        Account account = this.accountRepository.findById(id).orElseThrow(AccountNotFoundException::new);

        BigDecimal oldBalance = account.getBalance();
        BigDecimal newBalance = oldBalance.add(amount);

        account.setBalance(newBalance);
        this.accountRepository.save(account);
    }

}
