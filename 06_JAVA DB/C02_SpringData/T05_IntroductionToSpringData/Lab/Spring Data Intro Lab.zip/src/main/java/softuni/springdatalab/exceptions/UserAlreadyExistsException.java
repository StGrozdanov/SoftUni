package softuni.springdatalab.exceptions;

public class UserAlreadyExistsException extends Exception {
}
