package softuni.springdatalab.services;

import softuni.springdatalab.exceptions.UserAlreadyExistsException;
import softuni.springdatalab.exceptions.UserNotFoundException;
import softuni.springdatalab.models.User;

import java.math.BigDecimal;

public interface UserService {
    void registerUser(User user, BigDecimal initialAmount) throws UserAlreadyExistsException;
    void createNewBankAccount(BigDecimal initialAmount, long id) throws UserNotFoundException;
    void getUserTotalMoney(Long userId) throws UserNotFoundException;
}
