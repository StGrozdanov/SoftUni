package softuni.springdatalab.exceptions;

public class UserNotFoundException extends Exception {
}
