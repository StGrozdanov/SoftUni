package softuni.springdatalab.services;

import org.springframework.stereotype.Service;
import softuni.springdatalab.exceptions.UserAlreadyExistsException;
import softuni.springdatalab.exceptions.UserNotFoundException;
import softuni.springdatalab.models.Account;
import softuni.springdatalab.models.User;
import softuni.springdatalab.repositories.AccountRepository;
import softuni.springdatalab.repositories.UserRepository;

import javax.transaction.Transactional;
import java.math.BigDecimal;

@Service
public class UserServiceImpl implements UserService {
    private final UserRepository userRepository;
    private final AccountRepository accountRepository;

    public UserServiceImpl(UserRepository userRepository, AccountRepository accountRepository) {
        this.userRepository = userRepository;
        this.accountRepository = accountRepository;
    }

    @Override
    public void registerUser(User user, BigDecimal initialAmount) throws UserAlreadyExistsException {
        if (userRepository.existsByUsername(user.getUsername())) {
            throw new UserAlreadyExistsException();
        }

        this.userRepository.save(user);
        openNewAccount(user, initialAmount);
    }

    @Override
    public void createNewBankAccount(BigDecimal initialAmount, long id) throws UserNotFoundException {
        User user = this.userRepository.findById(id).orElseThrow(UserNotFoundException::new);

        openNewAccount(user, initialAmount);
    }

    @Override
    @Transactional
    public void getUserTotalMoney(Long userId) throws UserNotFoundException {
        double totalMoney = this.userRepository
                                        .findById(userId)
                                        .orElseThrow(UserNotFoundException::new)
                                        .getAccounts()
                                        .stream()
                                        .map(Account::getBalance)
                                        .mapToDouble(BigDecimal::doubleValue)
                                        .sum();
        System.out.printf("Total balance of the user is %.2f lv.", totalMoney);
    }

    private void openNewAccount(User user, BigDecimal initialAmount) {
        Account account = new Account();

        account.setBalance(initialAmount);
        account.setUser(user);

        this.accountRepository.save(account);
    }
}
