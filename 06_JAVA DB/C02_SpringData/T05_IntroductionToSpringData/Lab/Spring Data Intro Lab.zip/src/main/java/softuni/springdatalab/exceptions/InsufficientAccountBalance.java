package softuni.springdatalab.exceptions;

public class InsufficientAccountBalance extends Throwable {
    public InsufficientAccountBalance(String s) {
    }
}
