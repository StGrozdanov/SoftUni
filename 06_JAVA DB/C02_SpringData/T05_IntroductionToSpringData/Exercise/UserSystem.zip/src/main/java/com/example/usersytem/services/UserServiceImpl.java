package com.example.usersytem.services;

import com.example.usersytem.models.dtos.UserDto;
import com.example.usersytem.models.entities.User;
import com.example.usersytem.repositories.UserRepository;
import com.example.usersytem.utils.ValidationUtil;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import javax.validation.ConstraintViolation;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class UserServiceImpl implements UserService {
    private final ModelMapper modelMapper;
    private final ValidationUtil validationUtil;
    private final UserRepository userRepository;

    public UserServiceImpl(ModelMapper modelMapper, ValidationUtil validationUtil, UserRepository userRepository) {
        this.modelMapper = modelMapper;
        this.validationUtil = validationUtil;
        this.userRepository = userRepository;
    }


    @Override
    public void registerUser(UserDto user) {
        if (!this.validationUtil.findViolations(user).isEmpty()) {
            this.validationUtil.findViolations(user).stream().map(ConstraintViolation::getMessage)
                    .forEach(System.out::println);
            return;
        }

        User newUser = this.modelMapper.map(user, User.class);

        User savedUser = this.userRepository.save(newUser);

        System.out.printf("User %s is now saved in the database with id: %d%n",
                savedUser.generateFullName(), savedUser.getId());
    }

    @Override
    public Set<User> findUsersByEmailProvider(String emailProvider) {
        return this.userRepository.findAllByEmailEndingWith(emailProvider);
    }

    @Override
    @Transactional
    public void removeInactiveUsers(String lastLoginDate) {
        LocalDate inputAsDate = LocalDate.parse(lastLoginDate, DateTimeFormatter.ofPattern("dd-MM-yyyy"));

        LocalDateTime dateTime = LocalDateTime.now();
        LocalDateTime adjustedDateTime = dateTime.with(inputAsDate);

        Set<User> inactiveUsers = this.userRepository
                                                .findAllByLastTimeLoggedInBefore(adjustedDateTime)
                                                .stream()
                                                .map(user -> {
                                                    user.setDeleted(true);
                                                    return this.userRepository.save(user);
                                                })
                                                .collect(Collectors.toSet());

        System.out.printf("%d users are set as deleted, due to inactivity.%n", inactiveUsers.size());
    }
}
