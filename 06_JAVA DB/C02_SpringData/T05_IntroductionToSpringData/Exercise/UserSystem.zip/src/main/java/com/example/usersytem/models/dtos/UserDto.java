package com.example.usersytem.models.dtos;

import javax.validation.constraints.*;

public class UserDto {
    private String username;
    private String password;
    private String email;
    private Integer age;
    private String firstName;
    private String lastName;

    public UserDto(String username, String password, String email, Integer age, String firstName, String lastName) {
        this.username = username;
        this.password = password;
        this.email = email;
        this.age = age;
        this.firstName = firstName;
        this.lastName = lastName;
    }

    public UserDto() {
    }

    @Size(min = 4, max = 30, message = "Username must be between 4 and 30 symbols")
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    @Size(min = 6, max = 50, message = "Password must be between 6 and 50 symbols")
    @Pattern.List({
            @Pattern(regexp = "(?=.*[0-9]).+", message = "Password must contain at least one digit."),
            @Pattern(regexp = "(?=.*[a-z]).+", message = "Password must contain at least one lowercase letter."),
            @Pattern(regexp = "(?=.*[A-Z]).+", message = "Password must contain at least one upper letter."),
            @Pattern(regexp = "(?=.*[!||@||#||$||%||^||&||*||(||)||_||+||<||>||?]).+",
                    message = "Password must contain at least one special symbol."),
            @Pattern(regexp = "(?=\\S+$).+", message = "Password must not contain whitespace.")
    })
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Email(regexp = "^([A-Za-z0-9]+)([\\.||\\-||_]+[A-Za-z0-9]+)*@([A-Za-z-]{1,}\\.[A-Za-z]{1,}){1,}$",
            message = "Invalid Email.")
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Min(value = 1, message = "User age cannot be less than 1.")
    @Max(value = 120, message = "User age cannot be more than 120.")
    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
}
