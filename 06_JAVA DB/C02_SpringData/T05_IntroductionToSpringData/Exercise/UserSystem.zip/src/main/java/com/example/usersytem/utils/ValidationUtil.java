package com.example.usersytem.utils;

import javax.validation.ConstraintViolation;
import java.util.Set;

public interface ValidationUtil {
    <T> Set<ConstraintViolation<T>> findViolations(T entity);
}
