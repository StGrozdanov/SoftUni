package com.example.usersytem;

import com.example.usersytem.models.dtos.UserDto;
import com.example.usersytem.models.entities.User;
import com.example.usersytem.services.UserService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.Scanner;
import java.util.Set;

@Component
public class Main implements CommandLineRunner {
    private final UserService userService;

    public Main(UserService userService) {
        this.userService = userService;
    }

    @Override
    public void run(String... args) throws Exception {
        this.userService.registerUser(new UserDto("Stoyan", "1Aa!Aa", "stoyan@abv.bg", 20,
                "Stoyan", "Grozdanov"));

        this.userService.registerUser(new UserDto("Radka", "1Aa!Aa", "radka@yahoo.co.uk",
                30,
                "Radinka", "Dimitrinkova"));

        this.userService.registerUser(new UserDto("Shmatka", "1Aa!Aa", "shmatka@yahoo.co.uk",
                30,
                "Shmatka", "Shmatkova"));

        this.userService.registerUser(new UserDto("Pep4eto", "1Aa!Aa", "pepa@yahoo.co.uk",
                30,
                "Pepa", "Pepelqnkova"));

        this.userService.registerUser(new UserDto("Motika", "1Aa!Aa", "motika@abv.bg",
                30,
                "Motichko", "Motichkov"));

        Scanner scanner = new Scanner(System.in);

        System.out.println("What is the email provider you are looking for?");
        String emailProvider = scanner.nextLine();

        Set<User> users = this.userService.findUsersByEmailProvider(emailProvider);

        if (users.isEmpty()) {
            System.out.printf("No users found with domain %s%n", emailProvider);
        } else {
            users.forEach(user -> System.out.printf("username: %s email: %s%n", user.getUsername(), user.getEmail()));
        }

        System.out.println("What is the target date? Format: dd-MM-yyyy");
        this.userService.removeInactiveUsers(scanner.nextLine());

    }
}
