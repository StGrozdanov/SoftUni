package com.example.usersytem.services;

import com.example.usersytem.models.dtos.UserDto;
import com.example.usersytem.models.entities.User;

import java.util.Set;

public interface UserService {
    void registerUser(UserDto user);

    Set<User> findUsersByEmailProvider(String emailProvider);

    void removeInactiveUsers(String lastLoginDate);
}
