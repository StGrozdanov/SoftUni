package com.example.usersytem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserSytemApplication {

    public static void main(String[] args) {
        SpringApplication.run(UserSytemApplication.class, args);
    }

}
