package softuni.introtospringdatahomework.services;

import org.springframework.stereotype.Service;
import softuni.introtospringdatahomework.models.Author;
import softuni.introtospringdatahomework.repositories.AuthorRepository;
import softuni.introtospringdatahomework.services.interfaces.AuthorService;

import javax.transaction.Transactional;
import java.util.concurrent.ThreadLocalRandom;

@Service
public class AuthorServiceImpl implements AuthorService {
    private final AuthorRepository authorRepository;

    public AuthorServiceImpl(AuthorRepository authorRepository) {
        this.authorRepository = authorRepository;
    }

    @Override
    public void registerAuthor(Author author) {
        this.authorRepository.save(author);
    }

    @Override
    public Author getRandomAuthor() {
        long randomLong = ThreadLocalRandom.current().nextLong(1, this.getAuthorsCount() + 1);
        return this.authorRepository.getById(randomLong);
    }

    @Override
    public long getAuthorsCount() {
        return this.authorRepository.count();
    }

    @Override
    @Transactional
    public void findAllAuthorsAndOrderByBookCountDesc() {
        this.authorRepository.getAuthorsByBookCount().forEach(author -> {
            System.out.printf("%s %s has written %d books.%n",
                    author.getFirstName(), author.getLastName(), author.getBooks().size());
        });
    }
}
