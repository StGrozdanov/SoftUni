package softuni.introtospringdatahomework.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import softuni.introtospringdatahomework.models.Book;

import java.time.LocalDate;
import java.util.Set;

@Repository
public interface BookRepository extends JpaRepository<Book, Long> {
    Set<Book> findBooksByReleaseDateAfter(LocalDate releaseDate);

    Set<Book> findBooksByReleaseDateBefore(LocalDate releaseDate);

    Set<Book> findBooksByAuthorFirstNameAndAuthorLastNameOrderByReleaseDateDescTitle(String firstName, String lastName);
}
