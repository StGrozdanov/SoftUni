package softuni.introtospringdatahomework.services.interfaces;

import softuni.introtospringdatahomework.models.Author;

public interface AuthorService {
    void registerAuthor(Author author);

    Author getRandomAuthor();

    long getAuthorsCount();

    void findAllAuthorsAndOrderByBookCountDesc();
}
