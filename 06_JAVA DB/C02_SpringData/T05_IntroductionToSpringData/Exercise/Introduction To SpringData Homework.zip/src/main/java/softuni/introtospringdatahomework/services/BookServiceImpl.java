package softuni.introtospringdatahomework.services;

import org.springframework.stereotype.Service;
import softuni.introtospringdatahomework.models.Book;
import softuni.introtospringdatahomework.repositories.BookRepository;
import softuni.introtospringdatahomework.services.interfaces.BookService;

import javax.transaction.Transactional;
import java.time.LocalDate;

@Service
public class BookServiceImpl implements BookService {
    private final BookRepository bookRepository;

    public BookServiceImpl(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    @Override
    public void registerBook(Book book) {
        this.bookRepository.save(book);
    }

    @Override
    public long getBooksCount() {
        return this.bookRepository.count();
    }

    @Override
    public void printBookTitlesReleasedAfterTheYearOf2000() {
        LocalDate criteriaDate = LocalDate.of(1999, 12, 31);

        this.bookRepository
                .findBooksByReleaseDateAfter(criteriaDate)
                .forEach(book -> System.out.println(book.getTitle()));
    }

    @Override
    public void printBookAuthorsOfBooksReleasedBefore1990() {
        LocalDate criteriaDate = LocalDate.of(1999, 1, 1);

        this.bookRepository
                .findBooksByReleaseDateBefore(criteriaDate)
                .stream()
                .map(Book::getAuthor)
                .distinct()
                .forEach(author -> System.out.printf("%s %s%n", author.getFirstName(), author.getLastName()));
    }

    @Override
    @Transactional
    public void printBooksOrderedByReleaseDateByAuthorName(String firstName, String lastName) {
        this.bookRepository
                .findBooksByAuthorFirstNameAndAuthorLastNameOrderByReleaseDateDescTitle(firstName, lastName)
                .forEach(book -> System.out.printf("Title: %s, Release Date: %s, Copies: %d%n",
                        book.getTitle(), book.getReleaseDate(), book.getCopies()));
    }
}
