package softuni.introtospringdatahomework.services.interfaces;

import softuni.introtospringdatahomework.models.Category;

import java.util.Set;

public interface CategoryService {
    void registerCategory(Category category);

    Set<Category> getRandomCategories();

    long getCategoriesCount();
}
