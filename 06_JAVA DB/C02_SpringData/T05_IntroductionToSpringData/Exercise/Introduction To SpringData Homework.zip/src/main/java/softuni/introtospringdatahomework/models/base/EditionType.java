package softuni.introtospringdatahomework.models.base;

public enum EditionType {
    NORMAL,
    PROMO,
    GOLD
}
