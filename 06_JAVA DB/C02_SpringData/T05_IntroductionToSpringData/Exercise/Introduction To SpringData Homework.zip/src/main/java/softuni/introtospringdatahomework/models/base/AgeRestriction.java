package softuni.introtospringdatahomework.models.base;

public enum AgeRestriction {
    MINOR,
    TEEN,
    ADULT
}
