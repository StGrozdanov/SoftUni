package softuni.introtospringdatahomework.consoleControler;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import softuni.introtospringdatahomework.models.Author;
import softuni.introtospringdatahomework.models.Book;
import softuni.introtospringdatahomework.models.Category;
import softuni.introtospringdatahomework.models.base.AgeRestriction;
import softuni.introtospringdatahomework.models.base.EditionType;
import softuni.introtospringdatahomework.services.interfaces.AuthorService;
import softuni.introtospringdatahomework.services.interfaces.BookService;
import softuni.introtospringdatahomework.services.interfaces.CategoryService;

import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Set;
import java.util.stream.Collectors;

@Component
public class ConsoleRunner implements CommandLineRunner {
    private final CategoryService categoryService;
    private final AuthorService authorService;
    private final BookService bookService;

    public ConsoleRunner(CategoryService categoryService, AuthorService authorService, BookService bookService) {
        this.categoryService = categoryService;
        this.authorService = authorService;
        this.bookService = bookService;
    }

    @Override
    public void run(String... args) {
        try {
            seedDatabase();
        } catch (IOException e) {
            e.printStackTrace();
        }

        this.bookService.printBookTitlesReleasedAfterTheYearOf2000();
        this.bookService.printBookAuthorsOfBooksReleasedBefore1990();
        this.authorService.findAllAuthorsAndOrderByBookCountDesc();
        this.bookService.printBooksOrderedByReleaseDateByAuthorName("George", "Powell");
    }

    private void seedDatabase() throws IOException {
        String CATEGORIES_PATH = "src/main/resources/files/categories.txt";
        String AUTHORS_PATH = "src/main/resources/files/authors.txt";
        String BOOKS_PATH = "src/main/resources/files/books.txt";

        seedCategories(CATEGORIES_PATH);
        seedAuthors(AUTHORS_PATH);
        seedBooks(BOOKS_PATH);
    }

    private void seedBooks(String path) throws IOException {
        if (this.bookService.getBooksCount() == 0) {
            Files.readAllLines(Path.of(path)).forEach(input -> {

                Book book = createBookByInput(input);
                Author author = this.authorService.getRandomAuthor();
                Set<Category> categories = this.categoryService.getRandomCategories();

                book.setAuthor(author);
                book.setCategories(categories);

                this.bookService.registerBook(book);
            });
        }
    }

    private Book createBookByInput(String input) {
        String[] tokens = input.split("\\s+");

        int editionTypeNumber = Integer.parseInt(tokens[0]);
        String date = tokens[1];
        double priceAsDouble = Double.parseDouble(tokens[3]);
        int ageRestrictionNumber = Integer.parseInt(tokens[4]);

        Integer soldCopies = Integer.parseInt(tokens[2]);
        String title = Arrays.stream(tokens).skip(5).collect(Collectors.joining(" "));
        EditionType editionType = EditionType.values()[editionTypeNumber];
        LocalDate releaseDate = LocalDate.parse(date, DateTimeFormatter.ofPattern("d/M/yyyy"));
        BigDecimal price = BigDecimal.valueOf(priceAsDouble);
        AgeRestriction ageRestriction = AgeRestriction.values()[ageRestrictionNumber];

        return new Book(title, releaseDate, price, soldCopies, editionType, ageRestriction);
    }

    private void seedAuthors(String path) throws IOException {
        if (this.authorService.getAuthorsCount() == 0) {
            Files.
                    readAllLines(Path.of(path))
                    .forEach(input -> {
                        String[] tokens = input.split("\\s+");
                        String firstName = tokens[0];
                        String lastName = tokens[1];

                        Author author = new Author(firstName, lastName);

                        this.authorService.registerAuthor(author);
                    });
        }
    }

    private void seedCategories(String path) throws IOException {
        if (this.categoryService.getCategoriesCount() == 0) {
            Files.
                    readAllLines(Path.of(path))
                    .stream()
                    .filter(category -> !category.isEmpty())
                    .collect(Collectors.toList())
                    .forEach(categoryName -> {
                        Category category = new Category(categoryName);
                        this.categoryService.registerCategory(category);
                    });
        }
    }
}
