package softuni.introtospringdatahomework.services.interfaces;

import softuni.introtospringdatahomework.models.Book;

public interface BookService {
    void registerBook(Book book);

    long getBooksCount();

    void printBookTitlesReleasedAfterTheYearOf2000();

    void printBookAuthorsOfBooksReleasedBefore1990();

    void printBooksOrderedByReleaseDateByAuthorName(String firstName, String lastName);
}
