package com.example.springdataautomappingobjectshomework.models.entities;

import com.example.springdataautomappingobjectshomework.models.entities.base.BaseEntity;

import javax.persistence.*;
import java.util.LinkedHashSet;
import java.util.Objects;
import java.util.Set;

@Entity
@Table(name = "orders")
public class Order extends BaseEntity {
    private User user;
    private Set<Game> games;
    @Transient private Game game;

    public Order(User user, Game game) {
        this.user = user;
        this.game = game;
        this.games = new LinkedHashSet<>();
    }

    public Order() {
        this.games = new LinkedHashSet<>();
    }

    @ManyToOne
    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    @ManyToMany
    public Set<Game> getGames() {
        return games;
    }

    public void setGames(Set<Game> games) {
        this.games = games;
    }

    public void addGame() {
        this.games.add(this.game);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Order order = (Order) o;
        return game.equals(order.game);
    }

    @Override
    public int hashCode() {
        return Objects.hash(game);
    }
}
