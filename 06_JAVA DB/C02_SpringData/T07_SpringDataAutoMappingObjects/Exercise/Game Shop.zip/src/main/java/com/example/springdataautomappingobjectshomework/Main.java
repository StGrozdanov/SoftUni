package com.example.springdataautomappingobjectshomework;

import com.example.springdataautomappingobjectshomework.models.dtos.games.AllGamesViewDto;
import com.example.springdataautomappingobjectshomework.models.dtos.games.GameDetailsViewDto;
import com.example.springdataautomappingobjectshomework.models.dtos.games.GameOperationDto;
import com.example.springdataautomappingobjectshomework.models.dtos.users.UserLoginDto;
import com.example.springdataautomappingobjectshomework.models.dtos.users.UserRegisterDto;
import com.example.springdataautomappingobjectshomework.services.interfaces.GameService;
import com.example.springdataautomappingobjectshomework.services.interfaces.OrderService;
import com.example.springdataautomappingobjectshomework.services.interfaces.UserService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

@Component
public class Main implements CommandLineRunner {
    private final Scanner scanner;
    private final UserService userService;
    private final GameService gameService;
    private final OrderService orderService;

    public Main(UserService userService, GameService gameService, OrderService orderService) {
        this.userService = userService;
        this.gameService = gameService;
        this.orderService = orderService;
        this.scanner = new Scanner(System.in);
    }

    @Override
    public void run(String... args) {
        System.out.println("Welcome to the game system! Type your commands bellow or type finish if you want to exit:");
        String input = scanner.nextLine();

        while (!input.equals("finish")) {
            String[] tokens = input.split("\\|");
            String command = tokens[0];

            switch (command) {
                case "RegisterUser" -> userRegister(tokens);
                case "LoginUser" -> userLogin(tokens);
                case "Logout" -> this.userService.logoutUser();
                case "AddGame" -> gameAdd(tokens);
                case "EditGame" -> gameEdit(tokens);
                case "DeleteGame" -> gameDelete(tokens);
                case "AllGames" -> printAllGames();
                case "DetailGame" -> getGameDetails(tokens);
                case "OwnedGames" -> this.userService.printAllGamesOfTheCurrentUser();
                case "AddItem" -> this.orderService.addGameToTheShoppingCart(tokens[1]);
                case "RemoveItem" -> this.orderService.removeGameFromTheShoppingCart(tokens[1]);
                case "BuyItem" -> this.orderService.buyAllGames();
                default -> System.out.printf("Unknown command %s%n", input);
            }
            input = scanner.nextLine();
        }
    }

    private void getGameDetails(String[] tokens) {
        String detailGameTitle = tokens[1];
        try {
            GameDetailsViewDto game = this.gameService.getGameByTitle(detailGameTitle);
            System.out.println(game);
        } catch (IllegalArgumentException e) {
            System.out.print(e.getMessage());
        }
    }

    private void printAllGames() {
        List<AllGamesViewDto> allGames = this.gameService.getAllGames();
        if (allGames.isEmpty()) {
            System.out.println("There are currently no games in the database.");
            return;
        }
        allGames.forEach(System.out::println);
    }

    private void gameDelete(String[] tokens) {
        Long gameId = Long.parseLong(tokens[1]);
        this.gameService.deleteGame(gameId);
    }

    private void gameEdit(String[] tokens) {
        Long targetId = Long.parseLong(tokens[1]);
        List<String> values = Arrays.stream(tokens).skip(2).toList();
        this.gameService.editGame(targetId, values);
    }

    private void gameAdd(String[] tokens) {
        String title = tokens[1];
        BigDecimal price = new BigDecimal(tokens[2]);
        double size = Double.parseDouble(tokens[3]);
        String trailer = tokens[4];
        String thumbnailUrl = tokens[5];
        String description = tokens[6];
        LocalDate releaseDate = LocalDate.parse(tokens[7], DateTimeFormatter.ofPattern("dd-MM-yyyy"));
        GameOperationDto newGame = new GameOperationDto(title, price, size, trailer, thumbnailUrl,
                description, releaseDate);
        this.gameService.addGame(newGame);
    }

    private void userLogin(String[] tokens) {
        String loginEmail = tokens[1];
        String loginPassword = tokens[2];
        UserLoginDto userForLogin = new UserLoginDto(loginEmail, loginPassword);
        this.userService.loginUser(userForLogin);
    }

    private void userRegister(String[] tokens) {
        String registerEmail = tokens[1];
        String registerPassword = tokens[2];
        String registerRePassword = tokens[3];
        String registerFullName = tokens[4];

        if (!registerPassword.equals(registerRePassword)) {
            System.out.println("Both passwords should match!");
            return;
        }

        UserRegisterDto userForRegister = new UserRegisterDto(registerEmail, registerPassword,
                registerRePassword, registerFullName);

        this.userService.registerUser(userForRegister);
    }
}
