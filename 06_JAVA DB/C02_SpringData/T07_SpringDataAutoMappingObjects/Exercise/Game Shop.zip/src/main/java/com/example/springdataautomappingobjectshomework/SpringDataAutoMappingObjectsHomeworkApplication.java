package com.example.springdataautomappingobjectshomework;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDataAutoMappingObjectsHomeworkApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringDataAutoMappingObjectsHomeworkApplication.class, args);
    }

}
