package com.example.springdataautomappingobjectshomework.utils;

import javax.validation.ConstraintViolation;
import java.util.Set;

public interface Validator {
    <T>Set<ConstraintViolation<T>> getViolations(T entity);
}
