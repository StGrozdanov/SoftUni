package com.example.springdataautomappingobjectshomework.services;

import com.example.springdataautomappingobjectshomework.utils.ValidatorImpl;
import com.example.springdataautomappingobjectshomework.models.dtos.users.UserLoginDto;
import com.example.springdataautomappingobjectshomework.models.dtos.users.UserRegisterDto;
import com.example.springdataautomappingobjectshomework.models.entities.Game;
import com.example.springdataautomappingobjectshomework.models.entities.User;
import com.example.springdataautomappingobjectshomework.repositories.UserRepository;
import com.example.springdataautomappingobjectshomework.services.interfaces.UserService;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import javax.validation.ConstraintViolation;
import java.util.Set;

@Service
public class UserServiceImpl implements UserService {
    private final UserRepository userRepository;
    private final ValidatorImpl validator;
    private final ModelMapper mapper;
    private User loggedInUser;

    public UserServiceImpl(UserRepository userRepository, ValidatorImpl validator, ModelMapper mapper) {
        this.userRepository = userRepository;
        this.validator = validator;
        this.mapper = mapper;
    }

    @Override
    public void registerUser(UserRegisterDto user) {
        if (!validator.getViolations(user).isEmpty()) {
            validator.getViolations(user).stream().map(ConstraintViolation::getMessage).forEach(System.out::println);
            return;
        }

        User userByEmail = this.userRepository.findUserByEmail(user.getEmail());

        if (userByEmail != null) {
            System.out.println("There is already an registered user with this email! Use a different one.");
            return;
        }

        User newUser = this.mapper.map(user, User.class);

        if (this.userRepository.count() == 0) {
            newUser.setAdministrator(true);
        }

        this.userRepository.save(newUser);
        System.out.printf("%s was registered.%n", newUser.getFullName());
    }

    @Override
    public void loginUser(UserLoginDto userForLogin) {
        if (!validator.getViolations(userForLogin).isEmpty()) {
            validator.getViolations(userForLogin).stream().map(ConstraintViolation::getMessage).forEach(System.out::println);
            return;
        }

        User user = this.userRepository.findUserByEmailAndPassword(userForLogin.getEmail(),
                userForLogin.getPassword());

        if (user == null) {
            System.out.println("Incorrect username / password");
            return;
        }

        if (this.loggedInUser != null && this.loggedInUser.getEmail().equals(user.getEmail())) {
            System.out.printf("%s is already logged in!", user.getFullName());
            return;
        }

        this.loggedInUser = user;
        System.out.printf("Successfully logged in %s%n", user.getFullName());
    }

    @Override
    public void logoutUser() {
        if (this.loggedInUser != null) {
            System.out.printf("User %s successfully logged out%n", this.loggedInUser.getFullName());
            this.loggedInUser = null;
        } else {
            System.out.println("Cannot log out. No user was logged in.");
        }
    }

    @Override
    public boolean loggedInUserIsAdministrator() {
        return this.loggedInUser != null && this.loggedInUser.isAdministrator();
    }

    @Override
    public void printAllGamesOfTheCurrentUser() {
        if (this.loggedInUser == null) {
            System.out.println("You should be logged in if you want to view your games.");
            return;
        }
        if (this.loggedInUser.getGames().isEmpty()) {
            System.out.println("You currently don't have any games. To add your first one, do it manually from the " +
                    "database, cuz this homework left me brainless anyway. Good luck, have fun.");
            return;
        }
        this.loggedInUser.getGames().stream().map(Game::getTitle).forEach(System.out::println);
    }

    @Override
    public User getCurrentUser() {
        return this.loggedInUser;
    }

    @Override
    public boolean thereIsAUserLoggedIn() {
        return this.loggedInUser != null;
    }

    @Override
    @Transactional
    public void addGamesToCurrentUser(Set<Game> games) {
        this.loggedInUser.addGames(games);
        games.forEach(game -> game.getUsers().add(this.loggedInUser));
        this.userRepository.save(loggedInUser);
    }
}

