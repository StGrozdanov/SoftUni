package com.example.springdataautomappingobjectshomework.services;

import com.example.springdataautomappingobjectshomework.models.entities.Game;
import com.example.springdataautomappingobjectshomework.models.entities.Order;
import com.example.springdataautomappingobjectshomework.models.entities.User;
import com.example.springdataautomappingobjectshomework.repositories.OrderRepository;
import com.example.springdataautomappingobjectshomework.services.interfaces.GameService;
import com.example.springdataautomappingobjectshomework.services.interfaces.OrderService;
import com.example.springdataautomappingobjectshomework.services.interfaces.UserService;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

@Service
public class OrderServiceImpl implements OrderService {
    private final OrderRepository orderRepository;
    private final GameService gameService;
    private final UserService userService;

    public OrderServiceImpl(OrderRepository orderRepository, GameService gameService, UserService userService) {
        this.orderRepository = orderRepository;
        this.gameService = gameService;
        this.userService = userService;
    }

    @Override
    @Transactional
    public void addGameToTheShoppingCart(String gameTitle) {
        if (!this.userService.thereIsAUserLoggedIn()) {
            System.out.println("No user is logged in!");
            return;
        }
        try {
            Game targetGame = this.gameService.findGameByTitle(gameTitle);
            User currentUser = this.userService.getCurrentUser();

            if (currentUser.getGames().contains(targetGame)) {
                System.out.printf("%s has already bought %s%n", currentUser.getFullName(), targetGame.getTitle());
                return;
            }

            Order specificUserOrder = getSpecificUserOrder(targetGame, currentUser);

            if (specificUserOrder != null) {
                System.out.printf("%s is in the shopping cart already!%n", gameTitle);
                return;
            }

            Order newOrder = new Order(currentUser, targetGame);
            newOrder.addGame();

            this.orderRepository.save(newOrder);
            System.out.printf("%s added to cart.%n", gameTitle);

        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        }
    }

    @Override
    @Transactional
    public void removeGameFromTheShoppingCart(String gameTitle) {
        if (!this.userService.thereIsAUserLoggedIn()) {
            System.out.println("No user is logged in!");
            return;
        }

        Order specificUserOrder = getSpecificUserOrder(this.gameService.findGameByTitle(gameTitle),
                this.userService.getCurrentUser());

        if (specificUserOrder == null) {
            System.out.printf("There is no game %s in this user shopping cart!%n", gameTitle);
            return;
        }

        this.orderRepository.delete(specificUserOrder);
        System.out.printf("%s removed from the cart.%n", gameTitle);
    }

    @Override
    @Transactional
    public void buyAllGames() {
        List<Order> userOrders = this.orderRepository.findAllByUserEquals(this.userService.getCurrentUser());

        Set<Game> orderedGames = new LinkedHashSet<>();
        userOrders.forEach(order -> orderedGames.addAll(order.getGames()));

        this.userService.addGamesToCurrentUser(orderedGames);

        System.out.println("Successfully bought games:");

        if (orderedGames.isEmpty()) {
            System.out.println("None.");
        } else {
            orderedGames.forEach(game -> System.out.println(game.getTitle()));
            this.orderRepository.deleteAll(userOrders);
        }
    }

    private Order getSpecificUserOrder(Game targetGame, User currentUser) {
        return this.orderRepository.findAllByUserEquals(currentUser)
                .stream()
                .filter(orderedGame -> orderedGame.getGames().contains(targetGame))
                .findFirst()
                .orElse(null);
    }
}
