package com.example.springdataautomappingobjectshomework.services.interfaces;

import com.example.springdataautomappingobjectshomework.models.dtos.games.AllGamesViewDto;
import com.example.springdataautomappingobjectshomework.models.dtos.games.GameDetailsViewDto;
import com.example.springdataautomappingobjectshomework.models.dtos.games.GameOperationDto;
import com.example.springdataautomappingobjectshomework.models.entities.Game;
import com.example.springdataautomappingobjectshomework.models.entities.User;

import java.util.List;
import java.util.Optional;
import java.util.Set;

public interface GameService {
    void addGame(GameOperationDto game);

    void editGame(Long id, List<String> values);

    void deleteGame(Long gameId);

    List<AllGamesViewDto> getAllGames();

    GameDetailsViewDto getGameByTitle(String title);

    Game findGameByTitle(String gameTitle);
}
