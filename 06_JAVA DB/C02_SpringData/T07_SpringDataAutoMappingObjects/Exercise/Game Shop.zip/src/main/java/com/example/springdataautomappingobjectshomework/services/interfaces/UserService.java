package com.example.springdataautomappingobjectshomework.services.interfaces;

import com.example.springdataautomappingobjectshomework.models.dtos.users.UserLoginDto;
import com.example.springdataautomappingobjectshomework.models.dtos.users.UserRegisterDto;
import com.example.springdataautomappingobjectshomework.models.entities.Game;
import com.example.springdataautomappingobjectshomework.models.entities.User;

import java.util.Set;

public interface UserService {
    void registerUser(UserRegisterDto user);

    void loginUser(UserLoginDto userForLogin);

    void logoutUser();

    boolean loggedInUserIsAdministrator();

    void printAllGamesOfTheCurrentUser();

    User getCurrentUser();

    boolean thereIsAUserLoggedIn();

    void addGamesToCurrentUser(Set<Game> games);
}

