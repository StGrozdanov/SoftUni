package com.example.springdataautomappingobjectshomework.models.dtos.games;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Positive;
import javax.validation.constraints.Size;
import java.math.BigDecimal;
import java.time.LocalDate;

public class GameOperationDto {
    private String title;
    private BigDecimal price;
    private Double size;
    private String trailer;
    private String thumbnailURL;
    private String description;
    private LocalDate releaseDate;

    public GameOperationDto() {
    }

    public GameOperationDto(String title, BigDecimal price, Double size, String trailer, String thumbnailURL,
                            String description, LocalDate releaseDate) {
        this.title = title;
        this.price = price;
        this.size = size;
        this.trailer = trailer;
        this.thumbnailURL = thumbnailURL;
        this.description = description;
        this.releaseDate = releaseDate;
    }

    @Pattern(regexp = "^[A-Z].{2,100}", message = "Title must start with uppercase latter and must have length between " +
            "3 and 100 symbols")
    public String getTitle() {
        return title;
    }

    @Positive(message = "Price must be positive.")
    public BigDecimal getPrice() {
        return price;
    }

    @Positive(message = "Size must be positive.")
    public Double getSize() {
        return size;
    }

    @Size(min = 11, max = 11, message = "Trailer must be exactly 11 characters long.")
    public String getTrailer() {
        return trailer;
    }

    @Pattern(regexp = "(http:\\/\\/.*)|(https:\\/\\/.*)", message = "Invalid url.")
    public String getThumbnailURL() {
        return thumbnailURL;
    }

    @Size(min = 20, message = "Description must be at least 20 symbols.")
    public String getDescription() {
        return description;
    }

    public LocalDate getReleaseDate() {
        return releaseDate;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public void setSize(Double size) {
        this.size = size;
    }

    public void setTrailer(String trailer) {
        this.trailer = trailer;
    }

    public void setThumbnailURL(String thumbnailURL) {
        this.thumbnailURL = thumbnailURL;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setReleaseDate(LocalDate releaseDate) {
        this.releaseDate = releaseDate;
    }
}
