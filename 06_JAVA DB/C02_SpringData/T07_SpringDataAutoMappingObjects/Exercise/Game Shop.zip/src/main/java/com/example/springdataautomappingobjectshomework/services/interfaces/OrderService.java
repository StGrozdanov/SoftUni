package com.example.springdataautomappingobjectshomework.services.interfaces;

public interface OrderService {
    void addGameToTheShoppingCart(String gameTitle);

    void removeGameFromTheShoppingCart(String gameTitle);

    void buyAllGames();
}
