package com.example.springdataautomappingobjectshomework;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDataAutoMappingObjectsHomeworkApplicationTests {

    @Test
    void contextLoads() {
    }

}
