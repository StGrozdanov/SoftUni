package com.example.springdataautomappingobjectshomework.services;

import com.example.springdataautomappingobjectshomework.helpers.ValidatorImpl;
import com.example.springdataautomappingobjectshomework.models.dtos.games.AllGamesViewDto;
import com.example.springdataautomappingobjectshomework.models.dtos.games.GameDetailsViewDto;
import com.example.springdataautomappingobjectshomework.models.dtos.games.GameOperationDto;
import com.example.springdataautomappingobjectshomework.models.entities.Game;
import com.example.springdataautomappingobjectshomework.repositories.GameRepository;
import com.example.springdataautomappingobjectshomework.services.interfaces.GameService;
import com.example.springdataautomappingobjectshomework.services.interfaces.UserService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.*;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import javax.validation.ConstraintViolation;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class GameServiceImpl implements GameService {
    private final GameRepository gameRepository;
    private final ModelMapper mapper;
    private final ValidatorImpl validator;
    private final UserService userService;

    public GameServiceImpl(GameRepository gameRepository, ModelMapper mapper, ValidatorImpl validator,
                           UserService userService) {
        this.gameRepository = gameRepository;
        this.mapper = mapper;
        this.validator = validator;
        this.userService = userService;
    }

    @Override
    public void addGame(GameOperationDto game) {
        if (!this.validator.getViolations(game).isEmpty()) {
            this.validator.getViolations(game).stream().map(ConstraintViolation::getMessage).forEach(System.out::println);
            return;
        }

        if (!this.userService.loggedInUserIsAdministrator()) {
            System.out.println("Only administrators can add games!");
            return;
        }

        Game newGame = this.mapper.map(game, Game.class);
        this.gameRepository.save(newGame);
        System.out.printf("Added %s%n", newGame.getTitle());
    }

    @Override
    public void editGame(Long id, List<String> values) {
        Game targetGame = this.gameRepository.findById(id).orElse(null);

        if (targetGame == null) {
            System.out.printf("There is no game with id %d in the database.%n", id);
            return;
        }

        if (!this.userService.loggedInUserIsAdministrator()) {
            System.out.println("Only administrators can edit games!");
            return;
        }

        GameOperationDto gameDto = new GameOperationDto();

        try {
            populateTargetClassFields(values, gameDto);
        } catch (InvalidPropertyException | PropertyAccessException e) {
            System.out.println("Invalid fields are given in the input!");
            return;
        }

        if (!this.validator.getViolations(gameDto).isEmpty()) {
            this.validator.getViolations(gameDto)
                    .stream()
                    .map(ConstraintViolation::getMessage)
                    .forEach(System.out::println);
            return;
        }

        System.out.printf("Edited %s%n", targetGame.getTitle());
        populateTargetClassFields(values, targetGame);
        this.gameRepository.save(targetGame);
    }

    @Override
    @Modifying
    @Transactional
    public void deleteGame(Long gameId) {
        Game targetGame = this.gameRepository.findById(gameId).orElse(null);
        if (targetGame == null) {
            System.out.printf("There is no game with id %d in the database!%n", gameId);
            return;
        }
        this.gameRepository.deleteById(gameId);
        System.out.printf("Deleted %s%n", targetGame.getTitle());
    }

    @Override
    public List<AllGamesViewDto> getAllGames() {
        List<Game> allGames = this.gameRepository.findAll();
        return allGames
                .stream()
                .map(game -> this.mapper.map(game, AllGamesViewDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public GameDetailsViewDto getGameByTitle(String title) {
        Game targetGame = this.gameRepository.findByTitle(title);
        if (targetGame == null) {
            throw new IllegalArgumentException(String.format("There is no game with title %s in the database.%n",
                    title));
        } else {
            return this.mapper.map(targetGame, GameDetailsViewDto.class);
        }
    }

    private void populateTargetClassFields(List<String> values, Object game) {
        for (String value : values) {
            String[] tokens = value.split("=");
            String targetField = tokens[0];
            try {
                double fieldValue = Double.parseDouble(tokens[1]);
                PropertyAccessor testFieldsAccessor = PropertyAccessorFactory.forDirectFieldAccess(game);
                if (targetField.equals("price")) {
                    testFieldsAccessor.setPropertyValue(targetField, BigDecimal.valueOf(fieldValue));
                } else {
                    testFieldsAccessor.setPropertyValue(targetField, fieldValue);
                }
            } catch (NumberFormatException e) {
                String fieldValue = tokens[1];
                PropertyAccessor testFieldsAccessor = PropertyAccessorFactory.forDirectFieldAccess(game);
                if (fieldValue.contains("-")) {
                    LocalDate date = LocalDate.parse(fieldValue, DateTimeFormatter.ofPattern("dd-MM-yyyy"));
                    testFieldsAccessor.setPropertyValue(targetField, date);
                } else {
                    testFieldsAccessor.setPropertyValue(targetField, fieldValue);
                }
            }

        }
    }
}
