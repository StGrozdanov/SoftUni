package com.example.springdataautomappingobjectshomework.helpers;

import javax.validation.ConstraintViolation;
import java.util.Set;

public interface Validator {
    <T>Set<ConstraintViolation<T>> getViolations(T entity);
}
