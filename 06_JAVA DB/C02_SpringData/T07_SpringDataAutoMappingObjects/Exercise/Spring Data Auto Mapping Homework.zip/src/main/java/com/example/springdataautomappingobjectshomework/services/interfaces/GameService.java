package com.example.springdataautomappingobjectshomework.services.interfaces;

import com.example.springdataautomappingobjectshomework.models.dtos.games.AllGamesViewDto;
import com.example.springdataautomappingobjectshomework.models.dtos.games.GameDetailsViewDto;
import com.example.springdataautomappingobjectshomework.models.dtos.games.GameOperationDto;
import java.util.List;

public interface GameService {
    void addGame(GameOperationDto game);

    void editGame(Long id, List<String> values);

    void deleteGame(Long gameId);

    List<AllGamesViewDto> getAllGames();

    GameDetailsViewDto getGameByTitle(String title);
}
