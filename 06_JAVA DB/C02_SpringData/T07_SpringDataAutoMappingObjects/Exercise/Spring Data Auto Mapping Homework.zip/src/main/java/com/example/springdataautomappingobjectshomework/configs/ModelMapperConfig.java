package com.example.springdataautomappingobjectshomework.configs;

import com.example.springdataautomappingobjectshomework.models.dtos.games.GameOperationDto;
import com.example.springdataautomappingobjectshomework.models.entities.Game;
import org.modelmapper.ModelMapper;
import org.modelmapper.PropertyMap;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ModelMapperConfig {

    @Bean
    public ModelMapper mapper() {
        ModelMapper mapper = new ModelMapper();

        mapper
                .typeMap(GameOperationDto.class, Game.class)
                .addMappings(new PropertyMap<GameOperationDto, Game>() {
                    @Override
                    protected void configure() {
                        map().setImageThumbnail(source.getThumbnailURL());
                    }
                });
        return mapper;
    }

}
