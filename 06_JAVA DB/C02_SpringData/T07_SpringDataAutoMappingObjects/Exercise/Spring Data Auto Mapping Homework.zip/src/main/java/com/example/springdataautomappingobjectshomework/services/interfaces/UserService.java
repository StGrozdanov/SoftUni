package com.example.springdataautomappingobjectshomework.services.interfaces;

import com.example.springdataautomappingobjectshomework.models.dtos.users.UserLoginDto;
import com.example.springdataautomappingobjectshomework.models.dtos.users.UserRegisterDto;

public interface UserService {
    void registerUser(UserRegisterDto user);

    void loginUser(UserLoginDto userForLogin);

    void logoutUser();

    boolean loggedInUserIsAdministrator();

    void printAllGamesOfTheCurrentUser();
}

