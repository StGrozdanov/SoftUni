package com.example.springdataautomappingobjectshomework;

import com.example.springdataautomappingobjectshomework.models.dtos.games.AllGamesViewDto;
import com.example.springdataautomappingobjectshomework.models.dtos.games.GameDetailsViewDto;
import com.example.springdataautomappingobjectshomework.models.dtos.games.GameOperationDto;
import com.example.springdataautomappingobjectshomework.models.dtos.users.UserLoginDto;
import com.example.springdataautomappingobjectshomework.models.dtos.users.UserRegisterDto;
import com.example.springdataautomappingobjectshomework.services.interfaces.GameService;
import com.example.springdataautomappingobjectshomework.services.interfaces.UserService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

@Component
public class Main implements CommandLineRunner {
    private final Scanner scanner;
    private final UserService userService;
    private final GameService gameService;

    public Main(UserService userService, GameService gameService) {
        this.userService = userService;
        this.gameService = gameService;
        this.scanner = new Scanner(System.in);
    }

    @Override
    public void run(String... args) {
        System.out.println("Welcome to the game system! Type your commands bellow or type finish if you want to exit:");
        String input = scanner.nextLine();

        while (!input.equals("finish")) {
            String[] tokens = input.split("\\|");
            String command = tokens[0];
            switch (command) {
                case "RegisterUser":
                    String registerEmail = tokens[1];
                    String registerPassword = tokens[2];
                    String registerRePassword = tokens[3];
                    String registerFullName = tokens[4];

                    if (!registerPassword.equals(registerRePassword)) {
                        System.out.println("Both passwords should match!");
                        break;
                    }

                    UserRegisterDto userForRegister = new UserRegisterDto(registerEmail, registerPassword,
                            registerRePassword, registerFullName);

                    this.userService.registerUser(userForRegister);

                    break;
                case "LoginUser":
                    String loginEmail = tokens[1];
                    String loginPassword = tokens[2];

                    UserLoginDto userForLogin = new UserLoginDto(loginEmail, loginPassword);

                    this.userService.loginUser(userForLogin);
                    break;
                case "Logout":
                    this.userService.logoutUser();
                    break;
                case "AddGame":
                    String title = tokens[1];
                    BigDecimal price = new BigDecimal(tokens[2]);
                    double size = Double.parseDouble(tokens[3]);
                    String trailer = tokens[4];
                    String thumbnailUrl = tokens[5];
                    String description = tokens[6];
                    LocalDate releaseDate = LocalDate.parse(tokens[7], DateTimeFormatter.ofPattern("dd-MM-yyyy"));

                    GameOperationDto newGame = new GameOperationDto(title, price, size, trailer, thumbnailUrl,
                            description, releaseDate);

                    this.gameService.addGame(newGame);
                    break;
                case "EditGame":
                    Long targetId = Long.parseLong(tokens[1]);
                    List<String> values = Arrays.stream(tokens).skip(2).toList();

                    this.gameService.editGame(targetId, values);
                    break;
                case "DeleteGame":
                    Long gameId = Long.parseLong(tokens[1]);
                    this.gameService.deleteGame(gameId);
                    break;
                case "AllGames":
                    List<AllGamesViewDto> allGames = this.gameService.getAllGames();
                    if (allGames.isEmpty()) {
                        System.out.println("There are currently no games in the database.");
                        break;
                    }
                    allGames.forEach(System.out::println);
                    break;
                case "DetailGame":
                    String detailGameTitle = tokens[1];
                    try {
                        GameDetailsViewDto game = this.gameService.getGameByTitle(detailGameTitle);
                        System.out.println(game);
                    } catch (IllegalArgumentException e) {
                        System.out.print(e.getMessage());
                    }
                    break;
                case "OwnedGames":
                    this.userService.printAllGamesOfTheCurrentUser();
                    break;
                default:
                    System.out.printf("Unknown command %s%n", input);
            }
            input = scanner.nextLine();
        }
    }
}
