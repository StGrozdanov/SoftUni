package com.example.springdataautomappingobjectshomework.helpers;

import org.springframework.stereotype.Component;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import java.util.Set;


@Component
public class ValidatorImpl implements Validator {

    private final javax.validation.Validator validator;

    public ValidatorImpl() {
        this.validator = Validation.buildDefaultValidatorFactory().getValidator();
    }

    @Override
    public <T> Set<ConstraintViolation<T>> getViolations(T entity) {
        return validator.validate(entity);
    }
}
