package com.example.automappinglab;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AutoMappingLabApplication {

    public static void main(String[] args) {
        SpringApplication.run(AutoMappingLabApplication.class, args);
    }

}
