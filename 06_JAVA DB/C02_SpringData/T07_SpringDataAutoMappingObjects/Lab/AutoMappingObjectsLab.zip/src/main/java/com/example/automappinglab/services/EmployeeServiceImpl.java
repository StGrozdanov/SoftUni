package com.example.automappinglab.services;

import com.example.automappinglab.models.dto.EmployeeDTO;
import com.example.automappinglab.models.dto.ManagerDTO;
import com.example.automappinglab.models.entities.Employee;
import com.example.automappinglab.repositories.EmployeeRepository;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeServiceImpl implements EmployeeService{
    private final EmployeeRepository employeeRepository;
    private final ModelMapper mapper;

    public EmployeeServiceImpl(EmployeeRepository employeeRepository, ModelMapper mapper) {
        this.employeeRepository = employeeRepository;
        this.mapper = mapper;
    }

    @Override
    public EmployeeDTO getEmployeeById(long id) {
        var employee = this.employeeRepository.findById(id).orElse(null);
        return this.mapper.map(employee, EmployeeDTO.class);
    }

    @Override
    public List<EmployeeDTO> getAllEmployees() {
        List<Employee> employees = this.employeeRepository.findAllByManagerIsNotNull();
        return employees.stream().map(e -> this.mapper.map(e, EmployeeDTO.class)).toList();
    }

    @Override
    public List<ManagerDTO> getAllManagers() {
        return this.employeeRepository
                .findAllByManagerIsNull()
                .stream()
                .map(m -> this.mapper.map(m, ManagerDTO.class)).toList();
    }
}
