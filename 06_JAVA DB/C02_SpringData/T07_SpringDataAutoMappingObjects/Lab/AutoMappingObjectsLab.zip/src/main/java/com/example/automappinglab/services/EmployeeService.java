package com.example.automappinglab.services;

import com.example.automappinglab.models.dto.EmployeeDTO;
import com.example.automappinglab.models.dto.ManagerDTO;

import java.util.List;

public interface EmployeeService {
    EmployeeDTO getEmployeeById(long id);

    List<EmployeeDTO> getAllEmployees();

    List<ManagerDTO> getAllManagers();
}
