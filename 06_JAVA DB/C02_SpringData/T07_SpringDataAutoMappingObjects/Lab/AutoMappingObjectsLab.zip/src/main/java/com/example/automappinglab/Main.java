package com.example.automappinglab;

import com.example.automappinglab.services.EmployeeService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class Main implements CommandLineRunner {
    private final EmployeeService employeeService;

    public Main(EmployeeService employeeService) {
        this.employeeService = employeeService;
    }

    @Override
    public void run(String... args) throws Exception {
//        System.out.println("Regular Employees of the company:");
//        this.employeeService.getAllEmployees().forEach(e -> {
//            System.out.printf("%s %s %.2f%n", e.getFirstName(), e.getLastName(), e.getSalary());
//        });
//        System.out.println("Company managers:");
//        this.employeeService.getAllManagers().forEach(m -> {
//            System.out.printf("%s %s is in charge of %d employees.%n", m.getFirstName(), m.getLastName(), m.getEmployeesInChargeOfCount());
//        });
        this.employeeService.getAllManagers().forEach(manager -> {
            System.out.printf("%s %s | Employees: %d%n",
                    manager.getFirstName(), manager.getLastName(), manager.getEmployeesInChargeOfCount());
                    manager.getInChargeOf().forEach(employee -> {
                        System.out.printf("\t- %s %s %.2f%n", employee.getFirstName(), employee.getLastName(),
                                employee.getSalary());
                    });
        });
    }
}
