package com.example.automappinglab.models.dto;

import java.util.ArrayList;
import java.util.List;

public class ManagerDTO {
    private String firstName;
    private String lastName;
    private List<EmployeeDTO> inChargeOf;

    public ManagerDTO() {
        this.inChargeOf = new ArrayList<>();
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public List<EmployeeDTO> getInChargeOf() {
        return inChargeOf;
    }

    public void setInChargeOf(List<EmployeeDTO> inChargeOf) {
        this.inChargeOf = inChargeOf;
    }

    public int getEmployeesInChargeOfCount() {
        return this.inChargeOf.size();
    }
}
