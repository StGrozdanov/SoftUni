package entities;

import javax.persistence.*;

@MappedSuperclass
public abstract class Person {
    private long id;
    private String firstName;
    private String lastName;
    private Integer phoneNumber;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    protected long getId() {
        return id;
    }

    protected void setId(long id) {
        this.id = id;
    }

    @Column(name = "first_name")
    protected String getFirstName() {
        return firstName;
    }

    protected void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    @Column(name = "last_name")
    protected String getLastName() {
        return lastName;
    }

    protected void setLastName(String lastName) {
        this.lastName = lastName;
    }

    @Column(name = "phone_number")
    protected Integer getPhoneNumber() {
        return phoneNumber;
    }

    protected void setPhoneNumber(Integer phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
}
