package entities;

import javax.persistence.Column;
import javax.persistence.Entity;

@Entity
public class Student extends Person {
    private double averageGrade;
    private Integer attendance;

    @Column(name = "average_grade")
    public double getAverageGrade() {
        return averageGrade;
    }

    public void setAverageGrade(double averageGrade) {
        this.averageGrade = averageGrade;
    }

    public Integer getAttendance() {
        return attendance;
    }

    public void setAttendance(Integer attendance) {
        this.attendance = attendance;
    }
}
