package entities;

import helpers.Validator;

import javax.persistence.*;
import java.util.Date;

@Entity
public class Visitation {
    private long id;
    private Date date;
    private String comment;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    @Column(columnDefinition = "DATE", nullable = false)
    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    @Column(nullable = false)
    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        if (!Validator.stringIsInvalid(comment)) {
            this.comment = comment;
        } else {
            throw new IllegalArgumentException("Comments cannot be empty!");
        }
    }
}
