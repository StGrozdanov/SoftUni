package helpers;

public class Validator {
    public static boolean stringIsInvalid(String field) {
        return field == null || field.trim().isEmpty();
    }
}
