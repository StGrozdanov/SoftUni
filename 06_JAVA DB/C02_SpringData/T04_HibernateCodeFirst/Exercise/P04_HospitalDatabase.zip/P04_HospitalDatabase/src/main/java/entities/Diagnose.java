package entities;

import helpers.Validator;

import javax.persistence.*;

@Entity
public class Diagnose {
    private long id;
    private String name;
    private String comment;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    @Column(nullable = false)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        if(!Validator.stringIsInvalid(name)) {
            this.name = name;
        } else {
            throw new IllegalArgumentException("Diagnose name cannot be empty!");
        }
    }

    @Column(nullable = false)
    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }
}
