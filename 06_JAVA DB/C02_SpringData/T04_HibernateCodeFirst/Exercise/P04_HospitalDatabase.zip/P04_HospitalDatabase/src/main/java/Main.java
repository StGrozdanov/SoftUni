import entities.Diagnose;
import entities.Medicament;
import entities.Patient;
import entities.Visitation;
import javax.persistence.EntityManager;
import javax.persistence.Persistence;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.atomic.AtomicInteger;

public class Main {
    public static void main(String[] args) {
        EntityManager entityManager = Persistence
                .createEntityManagerFactory("Hospital")
                .createEntityManager();
        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome to the Hospital Database!");
        mainUserInterface();
        int choiceNumber = Integer.parseInt(scanner.nextLine());

        while (choiceNumber != 5) {
            switch (choiceNumber) {
                case 1:
                    printAllPatients(entityManager);
                    break;
                case 2:
                    printFullInfoForPatientsWithDiagnosis(entityManager);
                    break;
                case 3:
                    try {
                        addNewPatient(entityManager, scanner);
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }
                    break;
                case 4:
                    getPatientLastVisitByPatientId(entityManager, scanner);
                default:
                    break;
            }
            mainUserInterface();
            choiceNumber = Integer.parseInt(scanner.nextLine());
        }
    }

    private static void printAllPatients(EntityManager entityManager) {
        List<Patient> patients = entityManager
                .createQuery("SELECT p FROM Patient p", Patient.class)
                .getResultList();

        if (!patients.isEmpty()) {
            patients.forEach(patient -> System.out.println(patient.getFirstName() + " " + patient.getLastName()));
        } else {
            System.out.println("There are currently no patients in the database.");
        }
    }

    private static void printFullInfoForPatientsWithDiagnosis(EntityManager entityManager) {
        List<Patient> patients = entityManager
                .createQuery("SELECT p FROM Patient p WHERE p.diagnoses.size > 0", Patient.class)
                .getResultList();

        if (!patients.isEmpty()) {
            patients.forEach(patient -> {
                AtomicInteger counter = new AtomicInteger();

                System.out.println("********************************************************");
                System.out.printf("Patient name: %s %s%nDiagnoses:%n", patient.getFirstName(), patient.getLastName());

                patient.getDiagnoses().forEach(diagnose -> {
                    int incrementedCounter = counter.getAndIncrement();
                    incrementedCounter++;
                    System.out.printf("%d.%s - %s%n", incrementedCounter, diagnose.getName(), diagnose.getComment());
                });

                System.out.print("Prescribed medications:");

                if (patient.getMedications().isEmpty()) {
                    System.out.println(" N/A");
                } else {
                    counter.set(0);
                    System.out.println();

                    patient.getMedications().forEach(medicament -> {
                        int incrementedCounter = counter.getAndIncrement();
                        incrementedCounter++;
                        System.out.printf("%d.%s%n", incrementedCounter, medicament.getName());
                    });
                }

                System.out.print("Visits:");

                if (patient.getVisitations().isEmpty()) {
                    System.out.println(" N/A");
                } else {
                    counter.set(0);
                    System.out.println();

                    patient.getVisitations().forEach(visitation -> {
                        int incrementedCounter = counter.getAndIncrement();
                        incrementedCounter++;
                        System.out.printf("%d.%s - %s%n", incrementedCounter, visitation.getDate(), visitation.getComment());
                    });
                }
                System.out.println("********************************************************");
            });
        } else {
            System.out.println("There are currently no patients with diagnosis in the database.");
        }
    }

    private static void addNewPatient(EntityManager entityManager, Scanner scanner) throws ParseException {
        entityManager.getTransaction().begin();

        Patient patient = new Patient();

        System.out.println("The first name of the patient:");
        String firstName = scanner.nextLine();
        patient.setFirstName(firstName);
        System.out.println("The last name of the patient:");
        String lastName = scanner.nextLine();
        patient.setLastName(lastName);
        System.out.println("What is the birthdate of the patient? Format: dd/mm/year");
        String birthDate = scanner.nextLine();
        patient.setDateOfBirth(new SimpleDateFormat("dd/MM/yyyy").parse(birthDate));
        System.out.println("What is the address of the patient?");
        String address = scanner.nextLine();
        patient.setAddress(address);
        System.out.println("Does the patient have medical insurance? Yes / No");
        String insurance = scanner.nextLine();
        if (insurance.equals("Yes")) {
            patient.setMedicalInsurance(true);
        }

        innerUserInterface();
        int choice = Integer.parseInt(scanner.nextLine());

        while (choice != 4) {
            switch (choice) {
                case 1:
                    System.out.println("Enter comment for the visitation:");
                    String comment = scanner.nextLine();
                    Visitation visitation = new Visitation();
                    visitation.setComment(comment);
                    visitation.setDate(new Date());

                    entityManager.persist(visitation);

                    patient.getVisitations().add(visitation);
                    break;
                case 2:
                    System.out.println("What is the medicament name?");
                    String medicamentName = scanner.nextLine();
                    try {
                        Medicament medicament = entityManager
                                .createQuery("SELECT m FROM Medicament m WHERE m.name = :medicament", Medicament.class)
                                .setParameter("medicament", medicamentName)
                                .getSingleResult();

                        patient.getMedications().add(medicament);
                    } catch (Exception e) {
                        Medicament medicament = new Medicament();
                        medicament.setName(medicamentName);
                        entityManager.persist(medicament);

                        patient.getMedications().add(medicament);
                    }
                    break;
                case 3:
                    System.out.println("What is the diagnose name?");
                    String diagnoseName = scanner.nextLine();
                    try {
                        Diagnose diagnose = entityManager
                                .createQuery("SELECT d FROM Diagnose d WHERE d.name = :diagnose", Diagnose.class)
                                .setParameter("diagnose", diagnoseName)
                                .getSingleResult();

                        patient.getDiagnoses().add(diagnose);
                    } catch (Exception e) {
                        Diagnose diagnose = new Diagnose();
                        diagnose.setName(diagnoseName);
                        System.out.println("Your comment for the diagnose?");
                        diagnose.setComment(scanner.nextLine());

                        entityManager.persist(diagnose);

                        patient.getDiagnoses().add(diagnose);
                    }
                    break;
            }
            innerUserInterface();
            choice = Integer.parseInt(scanner.nextLine());
        }
        entityManager.persist(patient);

        entityManager.getTransaction().commit();
    }

    private static void getPatientLastVisitByPatientId(EntityManager entityManager, Scanner scanner) {
        System.out.println("What is the id of the patient you are looking for ?");
        long id = Integer.parseInt(scanner.nextLine());

        Patient patient = entityManager.find(Patient.class, id);

        if (patient != null) {

            System.out.println("Patient name: " + patient.getFirstName() + " " + patient.getLastName());

            patient.getVisitations()
                    .stream()
                    .sorted((v1, v2) -> v2.getDate().compareTo(v1.getDate()))
                    .limit(1)
                    .forEach(visit -> {
                        System.out.println("Patient last visit was on: " + visit.getDate());
                    });
        } else {
            System.out.printf("There is no patient with id %d in the database%n", id);
        }
    }

    private static void mainUserInterface() {
        System.out.println("Enter your choice by selecting a number 1-4");
        System.out.println("1. Get all patients");
        System.out.println("2. Get info for all patients with diagnosis");
        System.out.println("3. Add new patient");
        System.out.println("4. Get Patient last visit by patient id");
        System.out.println("5. Exit from the program");
    }

    private static void innerUserInterface() {
        System.out.println("You now have the following options for your patient from 1-4:");
        System.out.println("1 - Record a visitation");
        System.out.println("2 - Prescribe medicament");
        System.out.println("3 - Add diagnose");
        System.out.println("4 - Add patient to the database");
    }
}