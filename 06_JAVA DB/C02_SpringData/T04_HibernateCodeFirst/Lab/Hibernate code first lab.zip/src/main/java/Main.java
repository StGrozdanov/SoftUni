import javax.persistence.EntityManager;
import javax.persistence.Persistence;
import entities.LicensePlate;

public class Main {
    public static void main(String[] args) {
        EntityManager em = Persistence.createEntityManagerFactory("auto_house").createEntityManager();

        em.getTransaction().begin();

        LicensePlate licensePlate = em.find(LicensePlate.class, 1L);
        System.out.println(licensePlate.getCar().getModel());
        System.out.println(licensePlate.getCar().getLicensePlate().getNumber());

        em.getTransaction().commit();
    }
}
