package com.example.cardealer.services;

import com.example.cardealer.models.dtos.sales.SaleSummaryDto;
import com.example.cardealer.models.dtos.sales.SaleSummaryViewDto;
import com.example.cardealer.models.entities.Car;
import com.example.cardealer.models.entities.Sale;
import com.example.cardealer.repositories.CarRepository;
import com.example.cardealer.repositories.CustomerRepository;
import com.example.cardealer.repositories.SaleRepository;
import com.example.cardealer.services.interfaces.SaleService;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

@Service
public class SaleServiceImpl implements SaleService {
    private final SaleRepository saleRepository;
    private final ModelMapper modelMapper;
    private final CustomerRepository customerRepository;
    private final CarRepository carRepository;

    public SaleServiceImpl(SaleRepository saleRepository, ModelMapper modelMapper, CustomerRepository customerRepository, CarRepository carRepository) {
        this.saleRepository = saleRepository;
        this.modelMapper = modelMapper;
        this.customerRepository = customerRepository;
        this.carRepository = carRepository;
    }


    @Override
    public void seedSales() {
        if (this.saleRepository.count() == 0) {
            long totalCarsCount = this.carRepository.count();

            this.customerRepository.findAll().forEach(customer -> {
                List<Double> discountTypes = List.of(0.0, 0.05, 0.1, 0.15, 0.2, 0.3, 0.4, 0.5);

                int randomAmountOfSalesPerCustomer = ThreadLocalRandom.current().nextInt(1, 6);

                for (int i = 0; i < randomAmountOfSalesPerCustomer; i++) {
                    int discountIndex = ThreadLocalRandom.current().nextInt(0, 8);
                    Double discount = discountTypes.get(discountIndex);

                    long randomCarId = ThreadLocalRandom.current().nextLong(1, totalCarsCount + 1);
                    Car car = this.carRepository.findById(randomCarId).orElse(null);

                    Sale sale = new Sale(car, customer, discount);
                    Sale savedSale = this.saleRepository.save(sale);

                    car.setSale(savedSale);
                    car.setCustomer(customer);
                    this.carRepository.save(car);
                    customer.setSale(savedSale);
                    this.customerRepository.save(customer);
                }
            });

        }
    }

    @Override
    public SaleSummaryViewDto getAllSales() {
        List<SaleSummaryDto> saleSummaryDto = this.saleRepository
                .findAllByCarIsNotNullAndCustomerIsNotNull()
                .stream()
                .map(sale -> {
                    SaleSummaryDto dto = this.modelMapper.map(sale, SaleSummaryDto.class);

                    BigDecimal salePrice = sale.getCar().calculateCarPrice();
                    dto.setPrice(salePrice);

                    Double discount = dto.getDiscount();

                    BigDecimal salePriceWithDiscount =
                            discount == 0
                                    ? salePrice
                                    : salePrice.multiply(new BigDecimal(1).subtract(BigDecimal.valueOf(discount)));

                    dto.setPriceWithDiscount(salePriceWithDiscount);
                    return dto;
                })
                .toList();

        return new SaleSummaryViewDto(saleSummaryDto);
    }
}
