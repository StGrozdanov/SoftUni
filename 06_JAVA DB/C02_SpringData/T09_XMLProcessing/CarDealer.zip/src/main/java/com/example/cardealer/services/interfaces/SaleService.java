package com.example.cardealer.services.interfaces;

import com.example.cardealer.models.dtos.sales.SaleSummaryViewDto;

public interface SaleService {
    void seedSales();

    SaleSummaryViewDto getAllSales();
}
