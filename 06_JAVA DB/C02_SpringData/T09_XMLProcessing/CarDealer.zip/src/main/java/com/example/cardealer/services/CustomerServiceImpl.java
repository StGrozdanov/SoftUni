package com.example.cardealer.services;

import com.example.cardealer.models.dtos.customers.*;
import com.example.cardealer.models.entities.Car;
import com.example.cardealer.models.entities.Customer;
import com.example.cardealer.repositories.CustomerRepository;
import com.example.cardealer.services.interfaces.CustomerService;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Service
public class CustomerServiceImpl implements CustomerService {
    private final CustomerRepository customerRepository;
    private final ModelMapper modelMapper;

    public CustomerServiceImpl(CustomerRepository customerRepository, ModelMapper modelMapper) {
        this.customerRepository = customerRepository;
        this.modelMapper = modelMapper;
    }

    @Override
    public void seedCustomers(CustomerSeedDto customers) {
        if (this.customerRepository.count() == 0) {
            List<Customer> customersToAdd = customers.getCustomers()
                            .stream()
                            .map(customerDto -> {
                                Customer customer = this.modelMapper.map(customerDto, Customer.class);

                                LocalDate birth = LocalDate.parse(customerDto.getBirthDate(),
                                        DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss"));
                                customer.setBirthDate(birth);

                                return customer;
                            })
                            .toList();

            this.customerRepository.saveAll(customersToAdd);
        }
    }

    @Override
    public OrderedCustomerViewDto getAllCustomersOrderedByBirthdateAscOrByDriverExperience() {
        List<OrderedCustomersDto> customerList = this.customerRepository
                .findAllCustomersOrderedByBirthdateAscOrByDriverExperience()
                .stream()
                .sorted((c1, c2) -> {
                    if (c1.getBirthDate() == c2.getBirthDate()) {
                        return c1.getYoungDriver().compareTo(c2.getYoungDriver());
                    }
                    return c1.getBirthDate().compareTo(c2.getBirthDate());
                })
                .map(customer -> this.modelMapper.map(customer, OrderedCustomersDto.class))
                .toList();

        return new OrderedCustomerViewDto(customerList);
    }

    @Override
    public CustomersWithCarsViewDto getAllCustomersWithBoughtCars() {
        List<CustomersWithBoughtCarsDto> customersWithBoughtCarsDto = this.customerRepository
                .findAllCustomersThatBoughtAtLeastOneCar()
                .stream()
                .map(customer -> {
                    CustomersWithBoughtCarsDto dto = new CustomersWithBoughtCarsDto();
                    dto.setFullName(customer.getName());
                    dto.setBoughtCars(customer.getCars().size());

                    BigDecimal customerSpentMoneysOnCars = BigDecimal.valueOf(customer
                                    .getCars()
                                    .stream()
                                    .map(Car::calculateCarPrice)
                                    .mapToDouble(BigDecimal::doubleValue)
                                    .sum())
                            .setScale(2, RoundingMode.CEILING);

                    dto.setSpentMoney(customerSpentMoneysOnCars);
                    return dto;
                })
                .sorted((c1, c2) -> {
                    if (c2.getSpentMoney().compareTo(c1.getSpentMoney()) == 0) {
                        return c2.getBoughtCars().compareTo(c1.getBoughtCars());
                    }
                    return c2.getSpentMoney().compareTo(c1.getSpentMoney());
                })
                .toList();

        return new CustomersWithCarsViewDto(customersWithBoughtCarsDto);
    }
}
