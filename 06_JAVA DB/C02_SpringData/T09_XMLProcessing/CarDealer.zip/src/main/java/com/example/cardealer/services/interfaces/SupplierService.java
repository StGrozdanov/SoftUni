package com.example.cardealer.services.interfaces;

import com.example.cardealer.models.dtos.suppliers.LocalSupplierViewDto;
import com.example.cardealer.models.dtos.suppliers.SupplierSeedDto;

public interface SupplierService {
    void seedSuppliers(SupplierSeedDto suppliers);

    LocalSupplierViewDto getAllLocalSuppliers();
}
