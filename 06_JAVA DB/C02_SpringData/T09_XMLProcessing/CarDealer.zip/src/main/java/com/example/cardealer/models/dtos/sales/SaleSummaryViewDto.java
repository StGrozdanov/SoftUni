package com.example.cardealer.models.dtos.sales;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "sales")
@XmlAccessorType(XmlAccessType.FIELD)
public class SaleSummaryViewDto {
    @XmlElement(name = "sale")
    private List<SaleSummaryDto> sales;

    public SaleSummaryViewDto() {
    }

    public SaleSummaryViewDto(List<SaleSummaryDto> sales) {
        this.sales = sales;
    }

    public List<SaleSummaryDto> getSales() {
        return sales;
    }

    public void setSales(List<SaleSummaryDto> sales) {
        this.sales = sales;
    }
}
