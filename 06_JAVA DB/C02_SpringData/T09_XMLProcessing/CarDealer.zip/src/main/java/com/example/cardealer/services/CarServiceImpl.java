package com.example.cardealer.services;

import com.example.cardealer.models.dtos.cars.*;
import com.example.cardealer.models.entities.Car;
import com.example.cardealer.models.entities.Part;
import com.example.cardealer.repositories.CarRepository;
import com.example.cardealer.repositories.PartRepository;
import com.example.cardealer.services.interfaces.CarService;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.Collectors;

@Service
public class CarServiceImpl implements CarService {
    private final CarRepository carRepository;
    private final ModelMapper modelMapper;
    private final PartRepository partRepository;

    public CarServiceImpl(CarRepository carRepository, ModelMapper modelMapper, PartRepository partRepository) {
        this.carRepository = carRepository;
        this.modelMapper = modelMapper;
        this.partRepository = partRepository;
    }

    @Override
    @Transactional
    public void seedCars(CarSeedDto cars) {
        if (this.carRepository.count() == 0) {
            List<Car> carsToAdd = cars.getCars()
                    .stream()
                    .map(car -> this.modelMapper.map(car, Car.class))
                    .toList();

            this.carRepository.saveAll(carsToAdd);

            long totalParts = this.partRepository.count();

            this.carRepository
                    .findAll()
                    .forEach(car -> {
                        int partsPerCar = ThreadLocalRandom.current().nextInt(3, 6);
                        Set<Part> collectedParts = new LinkedHashSet<>();

                        while (collectedParts.size() < 3) {
                            for (int i = 0; i < partsPerCar; i++) {
                                long randomPartId = ThreadLocalRandom.current().nextLong(1, totalParts + 1);
                                collectedParts.add(this.partRepository.getById(randomPartId));
                            }
                        }

                        car.setParts(collectedParts.stream().limit(5).collect(Collectors.toSet()));
                    });
        }
    }

    @Override
    public CarByModelViewDto getAndOrderCarsFromSpecificMake(String make) {
        List<OrderedCarsByMakeDto> carList = this.carRepository
                .findAllByMakeOrderByModelAscTravelledDistanceDesc(make)
                .stream()
                .map(car -> this.modelMapper.map(car, OrderedCarsByMakeDto.class))
                .toList();

        return new CarByModelViewDto(carList);
    }

    @Override
    public CarSummaryViewDto getAllCarsAlongWithTheirParts() {
        List<CarsAndPartsDto> carList = this.carRepository
                .findAll()
                .stream()
                .map(car -> this.modelMapper.map(car, CarsAndPartsDto.class))
                .toList();

        return new CarSummaryViewDto(carList);
    }
}
