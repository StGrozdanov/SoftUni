package com.example.cardealer.services.interfaces;

import com.example.cardealer.models.dtos.cars.*;

public interface CarService {
    void seedCars(CarSeedDto cars);

    CarByModelViewDto getAndOrderCarsFromSpecificMake(String make);

    CarSummaryViewDto getAllCarsAlongWithTheirParts();
}
