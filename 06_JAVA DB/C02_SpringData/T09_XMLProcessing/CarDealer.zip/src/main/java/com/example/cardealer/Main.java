package com.example.cardealer;

import com.example.cardealer.models.dtos.cars.CarByModelViewDto;
import com.example.cardealer.models.dtos.cars.CarSeedDto;
import com.example.cardealer.models.dtos.cars.CarSummaryViewDto;
import com.example.cardealer.models.dtos.customers.CustomerSeedDto;
import com.example.cardealer.models.dtos.customers.CustomersWithCarsViewDto;
import com.example.cardealer.models.dtos.customers.OrderedCustomerViewDto;
import com.example.cardealer.models.dtos.parts.PartSeedDto;
import com.example.cardealer.models.dtos.sales.SaleSummaryViewDto;
import com.example.cardealer.models.dtos.suppliers.LocalSupplierViewDto;
import com.example.cardealer.models.dtos.suppliers.SupplierSeedDto;
import com.example.cardealer.services.interfaces.*;
import com.example.cardealer.utils.XMLTool;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import javax.xml.bind.JAXBException;
import java.io.IOException;

@Component
public class Main implements CommandLineRunner {
    private static final String SUPPLIERS_PATH = "src/main/resources/files/suppliers.xml";
    private static final String PARTS_PATH = "src/main/resources/files/parts.xml";
    private static final String CARS_PATH = "src/main/resources/files/cars.xml";
    private static final String CUSTOMERS_PATH = "src/main/resources/files/customers.xml";
    private static final String ORDERED_CUSTOMERS_EXPORT_PATH = "src/main/resources/exports/ordered-customers.xml";
    private static final String ORDERED_CARS_BY_MAKE_PATH = "src/main/resources/exports/cars-by-specific-make.xml";
    private static final String LOCAL_SUPPLIERS_PATH = "src/main/resources/exports/local-suppliers.xml";
    private static final String CARS_AND_PARTS_PATH = "src/main/resources/exports/cars-and-parts.xml";
    private static final String CUSTOMERS_TOTAL_SALES_PATH = "src/main/resources/exports/customers-total-sales.xml";
    private static final String SALES_DISCOUNTS_PATH = "src/main/resources/exports/sales-discounts.xml";

    private final SupplierService supplierService;
    private final PartService partService;
    private final CarService carService;
    private final CustomerService customerService;
    private final SaleService saleService;
    private final XMLTool xmlTool;

    public Main(SupplierService supplierService, PartService partService, CarService carService,
                CustomerService customerService, SaleService saleService, XMLTool xmlTool) {
        this.supplierService = supplierService;
        this.partService = partService;
        this.carService = carService;
        this.customerService = customerService;
        this.saleService = saleService;
        this.xmlTool = xmlTool;
    }

    @Override
    public void run(String... args) throws Exception {
        seedDatabase();

        //Query 1 - Order Customers
        OrderedCustomerViewDto customers = this.customerService
                .getAllCustomersOrderedByBirthdateAscOrByDriverExperience();
        this.xmlTool.toXMLFile(ORDERED_CUSTOMERS_EXPORT_PATH, customers);

        //Query 2 - Cars From Make Toyota
        String make = "Toyota";
        CarByModelViewDto cars = this.carService.getAndOrderCarsFromSpecificMake(make);
        this.xmlTool.toXMLFile(ORDERED_CARS_BY_MAKE_PATH, cars);

        //Query 3 - Local Suppliers
        LocalSupplierViewDto suppliers = this.supplierService.getAllLocalSuppliers();
        this.xmlTool.toXMLFile(LOCAL_SUPPLIERS_PATH, suppliers);

        //Query 4 - Cars With Their List Of Parts
        CarSummaryViewDto carsSummary = this.carService.getAllCarsAlongWithTheirParts();
        this.xmlTool.toXMLFile(CARS_AND_PARTS_PATH, carsSummary);

        //Query 5 - Total Sales By Customer
        CustomersWithCarsViewDto customersWithCars = this.customerService.getAllCustomersWithBoughtCars();
        this.xmlTool.toXMLFile(CUSTOMERS_TOTAL_SALES_PATH, customersWithCars);

        //Query 6 - Sales with Applied Discount
        SaleSummaryViewDto sales = this.saleService.getAllSales();
        this.xmlTool.toXMLFile(SALES_DISCOUNTS_PATH, sales);
    }

    private void seedDatabase() throws IOException, JAXBException {
        SupplierSeedDto suppliers = this.xmlTool.fromXML(SUPPLIERS_PATH, SupplierSeedDto.class);
        this.supplierService.seedSuppliers(suppliers);

        PartSeedDto parts = this.xmlTool.fromXML(PARTS_PATH, PartSeedDto.class);
        this.partService.seedParts(parts);

        CarSeedDto cars = this.xmlTool.fromXML(CARS_PATH, CarSeedDto.class);
        this.carService.seedCars(cars);

        CustomerSeedDto customers = this.xmlTool.fromXML(CUSTOMERS_PATH, CustomerSeedDto.class);
        this.customerService.seedCustomers(customers);

        this.saleService.seedSales();
    }
}
