package com.example.cardealer.models.dtos.cars;

import com.example.cardealer.models.dtos.parts.PartsByCarDto;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import javax.xml.bind.annotation.*;
import java.util.List;

@XmlRootElement(name = "car")
@XmlAccessorType(XmlAccessType.FIELD)
public class CarsAndPartsDto {
    @XmlAttribute
    private String make;
    @XmlAttribute
    private String model;
    @XmlAttribute
    private Long travelledDistance;
    @XmlElementWrapper(name = "parts")
    @XmlElement(name = "part")
    private List<PartsByCarDto> parts;

    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public Long getTravelledDistance() {
        return travelledDistance;
    }

    public void setTravelledDistance(Long travelledDistance) {
        this.travelledDistance = travelledDistance;
    }

    public List<PartsByCarDto> getParts() {
        return parts;
    }

    public void setParts(List<PartsByCarDto> parts) {
        this.parts = parts;
    }
}
