package com.example.cardealer.services.interfaces;

import com.example.cardealer.models.dtos.customers.*;

public interface CustomerService {
    void seedCustomers(CustomerSeedDto customers);

    OrderedCustomerViewDto getAllCustomersOrderedByBirthdateAscOrByDriverExperience();

    CustomersWithCarsViewDto getAllCustomersWithBoughtCars();
}
