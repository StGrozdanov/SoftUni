package com.example.cardealer.services;

import com.example.cardealer.models.dtos.suppliers.LocalSupplierViewDto;
import com.example.cardealer.models.dtos.suppliers.LocalSuppliersDto;
import com.example.cardealer.models.dtos.suppliers.SupplierSeedDto;
import com.example.cardealer.models.entities.Supplier;
import com.example.cardealer.repositories.SupplierRepository;
import com.example.cardealer.services.interfaces.SupplierService;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class SupplierServiceImpl implements SupplierService {
    private final SupplierRepository supplierRepository;
    private final ModelMapper modelMapper;

    public SupplierServiceImpl(SupplierRepository supplierRepository, ModelMapper modelMapper) {
        this.supplierRepository = supplierRepository;
        this.modelMapper = modelMapper;
    }

    @Override
    public void seedSuppliers(SupplierSeedDto suppliers) {
        if (this.supplierRepository.count() == 0) {
            List<Supplier> suppliersToAdd = suppliers.getSuppliers()
                    .stream()
                    .map(supplier -> this.modelMapper.map(supplier, Supplier.class))
                    .toList();

            this.supplierRepository.saveAll(suppliersToAdd);
        }
    }

    @Override
    public LocalSupplierViewDto getAllLocalSuppliers() {
        List<LocalSuppliersDto> suppliersList = this.supplierRepository
                .findAllByImporterIsFalse()
                .stream()
                .map(supplier -> {
                    LocalSuppliersDto dto = this.modelMapper.map(supplier, LocalSuppliersDto.class);
                    dto.setPartsCount(supplier.getParts().size());
                    return dto;
                })
                .toList();

        return new LocalSupplierViewDto(suppliersList);
    }
}
