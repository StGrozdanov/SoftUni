package com.example.cardealer.services.interfaces;

import com.example.cardealer.models.dtos.parts.PartSeedDto;

public interface PartService {
    void seedParts(PartSeedDto parts);
}
