package com.example.cardealer.services;

import com.example.cardealer.models.dtos.parts.PartSeedDto;
import com.example.cardealer.models.entities.Part;
import com.example.cardealer.repositories.PartRepository;
import com.example.cardealer.repositories.SupplierRepository;
import com.example.cardealer.services.interfaces.PartService;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

@Service
public class PartServiceImpl implements PartService {
    private final PartRepository partRepository;
    private final ModelMapper modelMapper;
    private final SupplierRepository supplierRepository;

    public PartServiceImpl(PartRepository partRepository, ModelMapper modelMapper, SupplierRepository supplierRepository) {
        this.partRepository = partRepository;
        this.modelMapper = modelMapper;
        this.supplierRepository = supplierRepository;
    }

    @Override
    public void seedParts(PartSeedDto parts) {
        if (this.partRepository.count() == 0) {
            List<Part> partsToAdd = parts.getParts()
                    .stream()
                    .map(part -> this.modelMapper.map(part, Part.class))
                    .toList();

            long totalSuppliersCount = this.supplierRepository.count();

            partsToAdd.forEach(part -> {
                long randomSupplierId = ThreadLocalRandom.current().nextLong(1, totalSuppliersCount + 1);
                part.setSupplier(this.supplierRepository.findById(randomSupplierId).orElse(null));
            });

            this.partRepository.saveAll(partsToAdd);
        }
    }
}
