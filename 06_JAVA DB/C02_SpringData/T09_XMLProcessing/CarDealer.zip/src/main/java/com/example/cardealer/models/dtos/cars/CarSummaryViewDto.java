package com.example.cardealer.models.dtos.cars;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "cars")
@XmlAccessorType(XmlAccessType.FIELD)
public class CarSummaryViewDto {
    @XmlElement(name = "car")
    List<CarsAndPartsDto> cars;

    public CarSummaryViewDto() {
    }

    public CarSummaryViewDto(List<CarsAndPartsDto> cars) {
        this.cars = cars;
    }

    public List<CarsAndPartsDto> getCars() {
        return cars;
    }

    public void setCars(List<CarsAndPartsDto> cars) {
        this.cars = cars;
    }
}
