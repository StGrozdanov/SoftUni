package com.example.demo.services;

import com.example.demo.models.dtos.categories.CategoriesByProductsCountDto;
import com.example.demo.models.dtos.categories.CategoriesByProductsCountViewDto;
import com.example.demo.models.dtos.categories.CategoryDto;
import com.example.demo.models.dtos.categories.CategorySeedDto;
import com.example.demo.models.entities.Category;
import com.example.demo.models.entities.Product;
import com.example.demo.repositories.CategoryRepository;
import com.example.demo.repositories.ProductRepository;
import com.example.demo.services.interfaces.CategoryService;
import com.example.demo.utils.interfaces.ValidationUtil;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;

@Service
public class CategoryServiceImpl implements CategoryService {
    private final CategoryRepository categoryRepository;
    private final ValidationUtil validator;
    private final ModelMapper modelMapper;
    private final ProductRepository productRepository;

    public CategoryServiceImpl(CategoryRepository categoryRepository, ValidationUtil validator, ModelMapper modelMapper, ProductRepository productRepository) {
        this.categoryRepository = categoryRepository;
        this.validator = validator;
        this.modelMapper = modelMapper;
        this.productRepository = productRepository;
    }

    @Override
    public void seedCategories(CategorySeedDto categorySeeds) {
        if (this.categoryRepository.count() == 0) {
            List<CategoryDto> validCategoryDto = categorySeeds.getCategories()
                    .stream().filter(this.validator::isValid).toList();

            List<Category> categories = validCategoryDto
                    .stream()
                    .map(categoryDto -> this.modelMapper.map(categoryDto, Category.class))
                    .toList();

            this.categoryRepository.saveAll(categories);

            this.productRepository.findAll().forEach(product -> {
                long categoriesPerProduct = ThreadLocalRandom.current().nextLong(1, 5);
                Set<Category> categoriesToAdd = new LinkedHashSet<>();

                for (int i = 0; i < categoriesPerProduct; i++) {
                    long randomCategoryId = ThreadLocalRandom.current().nextLong(1, categories.size() + 1);
                    Category category = this.categoryRepository.getById(randomCategoryId);
                    categoriesToAdd.add(category);
                }
                product.setCategories(categoriesToAdd);
            });
        }
    }

    @Override
    public CategoriesByProductsCountViewDto getCategoriesByProductsCount() {
        List<Category> allCategoriesOrderedByProductCount = this.categoryRepository.findAll();

        List<CategoriesByProductsCountDto> dtoList = allCategoriesOrderedByProductCount
                .stream()
                .map(category -> {
                    Long productsCount = (long) category.getProducts().size();

                    BigDecimal avgPrice = BigDecimal.valueOf(category
                            .getProducts()
                            .stream()
                            .map(Product::getPrice)
                            .mapToDouble(BigDecimal::doubleValue)
                            .average()
                            .orElse(0));

                    BigDecimal totalRevenue = BigDecimal.valueOf(category
                            .getProducts()
                            .stream()
                            .map(Product::getPrice)
                            .mapToDouble(BigDecimal::doubleValue)
                            .sum());
                    CategoriesByProductsCountDto dto = this.modelMapper.map(category, CategoriesByProductsCountDto.class);

                    dto.setProductsCount(productsCount);
                    dto.setAveragePrice(avgPrice);
                    dto.setTotalRevenue(totalRevenue);

                    return dto;
                })
                .toList();

        return new CategoriesByProductsCountViewDto(dtoList);
    }
}
