package com.example.demo.models.dtos.products;

import javax.xml.bind.annotation.*;
import java.util.Set;

@XmlRootElement(name = "product")
@XmlAccessorType(XmlAccessType.FIELD)
public class SoldProductsSummaryDto {
    @XmlAttribute
    private int count;
    @XmlElement(name = "product")
    private Set<SoldProductsByCountDto> products;

    public SoldProductsSummaryDto() {
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public Set<SoldProductsByCountDto> getProducts() {
        return products;
    }

    public void setProducts(Set<SoldProductsByCountDto> products) {
        this.products = products;
    }
}
