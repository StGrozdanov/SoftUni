package com.example.demo;

import com.example.demo.models.dtos.categories.CategoriesByProductsCountViewDto;
import com.example.demo.models.dtos.categories.CategorySeedDto;
import com.example.demo.models.dtos.products.ProductSeedDto;
import com.example.demo.models.dtos.products.ProductWithoutBuyerViewDto;
import com.example.demo.models.dtos.users.*;
import com.example.demo.services.interfaces.CategoryService;
import com.example.demo.services.interfaces.ProductService;
import com.example.demo.services.interfaces.UserService;
import com.example.demo.utils.interfaces.XMLTool;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import javax.xml.bind.JAXBException;
import java.io.IOException;
import java.math.BigDecimal;

@Component
public class Main implements CommandLineRunner {
    private static final String USERS_PATH = "src/main/resources/files/users.xml";
    private static final String PRODUCTS_PATH = "src/main/resources/files/products.xml";
    private static final String CATEGORIES_PATH = "src/main/resources/files/categories.xml";
    private static final String EXPORT_PRODUCTS_IN_RANGE_PATH = "src/main/resources/exports/products-in-range.xml";
    private static final String EXPORT_SOLD_PRODUCTS_PATH = "src/main/resources/exports/users-sold-products.xml";
    private static final String EXPORT_CATEGORIES_BY_PRODUCTS_PATH = "src/main/resources/exports/categories-by-products.xml";
    private static final String EXPORT_USERS_PRODUCTS_PATH = "src/main/resources/exports/users-and-products.xml";

    private final UserService userService;
    private final ProductService productService;
    private final CategoryService categoryService;
    private final XMLTool xmlTool;

    public Main(UserService userService, ProductService productService, CategoryService categoryService, XMLTool xmlTool) {
        this.userService = userService;
        this.productService = productService;
        this.categoryService = categoryService;
        this.xmlTool = xmlTool;
    }

    @Override
    public void run(String... args) throws Exception {
        //Add DB records
        seedDatabase();

        //Query 1 - Products In Range
        BigDecimal lowerBound = new BigDecimal(500);
        BigDecimal upperBound = new BigDecimal(1000);

        ProductWithoutBuyerViewDto productsWithoutBuyers = this.productService
                .getAllProductsWithoutBuyerInPriceRange(lowerBound, upperBound);
        this.xmlTool.toXMLFile(EXPORT_PRODUCTS_IN_RANGE_PATH, productsWithoutBuyers);

        //Query 2 - Successfully Sold Products
        SellerViewDto successfulSellers = this.userService.getUsersWithOneOrMoreSoldProducts();
        this.xmlTool.toXMLFile(EXPORT_SOLD_PRODUCTS_PATH, successfulSellers);

        //Query 3 - Categories By Products Count
        CategoriesByProductsCountViewDto categoriesByProductsCount = this.categoryService
                .getCategoriesByProductsCount();
        this.xmlTool.toXMLFile(EXPORT_CATEGORIES_BY_PRODUCTS_PATH, categoriesByProductsCount);

        //Query 4 - Users And Products
        UserSummaryDto usersAndProducts = this.userService.getUsersAndProducts();
        this.xmlTool.toXMLFile(EXPORT_USERS_PRODUCTS_PATH, usersAndProducts);
    }

    private void seedDatabase() throws IOException, JAXBException {
        UserSeedDto userSeedDto = this.xmlTool.fromXML(USERS_PATH, UserSeedDto.class);
        this.userService.seedUsers(userSeedDto);

        CategorySeedDto categorySeedDto = this.xmlTool.fromXML(CATEGORIES_PATH, CategorySeedDto.class);
        this.categoryService.seedCategories(categorySeedDto);

        ProductSeedDto productSeedDto = this.xmlTool.fromXML(PRODUCTS_PATH, ProductSeedDto.class);
        this.productService.seedProducts(productSeedDto);
    }
}
