package com.example.demo.models.dtos.users;

import javax.xml.bind.annotation.*;
import java.util.Set;

@XmlRootElement(name = "users")
@XmlAccessorType(XmlAccessType.FIELD)
public class UserSummaryDto {
    @XmlAttribute(name = "count")
    private int usersCount;
    @XmlElement(name = "user")
    private Set<SellerBySoldProductsCountDto> users;

    public UserSummaryDto() {
    }

    public UserSummaryDto(int usersCount, Set<SellerBySoldProductsCountDto> users) {
        this.usersCount = usersCount;
        this.users = users;
    }

    public int getUsersCount() {
        return usersCount;
    }

    public void setUsersCount(int usersCount) {
        this.usersCount = usersCount;
    }

    public Set<SellerBySoldProductsCountDto> getUsers() {
        return users;
    }

    public void setUsers(Set<SellerBySoldProductsCountDto> users) {
        this.users = users;
    }
}
