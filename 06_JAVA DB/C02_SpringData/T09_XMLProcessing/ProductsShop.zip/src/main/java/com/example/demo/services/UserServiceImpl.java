package com.example.demo.services;

import com.example.demo.models.dtos.products.SoldProductsByCountDto;
import com.example.demo.models.dtos.products.SoldProductsSummaryDto;
import com.example.demo.models.dtos.users.*;
import com.example.demo.models.dtos.products.SoldProductsDto;
import com.example.demo.models.entities.User;
import com.example.demo.repositories.UserRepository;
import com.example.demo.services.interfaces.UserService;
import com.example.demo.utils.interfaces.ValidationUtil;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

@Service
public class UserServiceImpl implements UserService {
    private final UserRepository userRepository;
    private final ModelMapper modelMapper;
    private final ValidationUtil validator;

    public UserServiceImpl(UserRepository userRepository, ModelMapper modelMapper, ValidationUtil validator) {
        this.userRepository = userRepository;
        this.modelMapper = modelMapper;
        this.validator = validator;
    }

    @Override
    public void seedUsers(UserSeedDto userDtoList) {
        if (this.userRepository.count() == 0) {
            List<User> users = userDtoList
                    .getUsers()
                    .stream()
                    .filter(this.validator::isValid)
                    .map(userDto -> this.modelMapper.map(userDto, User.class))
                    .toList();

            this.userRepository.saveAll(users);
        }
    }

    @Override
    public SellerViewDto getUsersWithOneOrMoreSoldProducts() {
        List<SellerDto> sellerDtoSet = this.userRepository
                .findAllUsersWithOneOrMoreSoldProducts()
                .stream()
                .map(user -> {
                    SellerDto dto = modelMapper.map(user, SellerDto.class);

                    List<SoldProductsDto> soldProducts = dto
                            .getSoldProducts()
                            .stream()
                            .filter(this.validator::isValid)
                            .toList();

                    dto.setSoldProducts(soldProducts);

                    return dto;
                })
                .toList();

        return new SellerViewDto(sellerDtoSet);
    }

    @Override
    public UserSummaryDto getUsersAndProducts() {
        AtomicInteger counter = new AtomicInteger();

        LinkedHashSet<SellerBySoldProductsCountDto> sellers = this.userRepository
                .findAllUsersWithOneOrMoreSoldProducts()
                .stream()
                .map(user -> {
                    SellerBySoldProductsCountDto sellerDto = this.modelMapper.map(user, SellerBySoldProductsCountDto.class);

                    Set<SoldProductsByCountDto> soldProductsByCountDto = user.getSoldProducts()
                            .stream()
                            .map(product -> this.modelMapper.map(product, SoldProductsByCountDto.class))
                            .collect(Collectors.toSet())
                            .stream()
                            .filter(this.validator::isValid)
                            .collect(Collectors.toSet());

                    SoldProductsSummaryDto productSummaryDto = new SoldProductsSummaryDto();
                    productSummaryDto.setCount(soldProductsByCountDto.size());
                    productSummaryDto.setProducts(soldProductsByCountDto);

                    sellerDto.setSoldProducts(productSummaryDto);

                    counter.getAndIncrement();

                    return sellerDto;
                })
                .collect(Collectors.toSet())
                .stream()
                .sorted((seller1, seller2) -> {
                    if (seller2.getSoldProducts().getProducts().size() == seller1.getSoldProducts().getProducts().size()) {
                        return seller1.getLastName().compareTo(seller2.getLastName());
                    }
                    return Integer.compare(seller2.getSoldProducts().getProducts().size(), seller1.getSoldProducts().getProducts().size());
                })
                .collect(Collectors.toCollection(LinkedHashSet::new));

            return new UserSummaryDto(sellers.size(), sellers);
    }


}
