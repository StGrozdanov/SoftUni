package com.example.demo.services.interfaces;

import com.example.demo.models.dtos.categories.CategoriesByProductsCountViewDto;
import com.example.demo.models.dtos.categories.CategorySeedDto;

public interface CategoryService {
    void seedCategories(CategorySeedDto categorySeeds);

    CategoriesByProductsCountViewDto getCategoriesByProductsCount();
}
