package com.example.demo.services.interfaces;

import com.example.demo.models.dtos.products.ProductSeedDto;
import com.example.demo.models.dtos.products.ProductWithoutBuyerViewDto;

import java.math.BigDecimal;

public interface ProductService {
    void seedProducts(ProductSeedDto products);

    ProductWithoutBuyerViewDto getAllProductsWithoutBuyerInPriceRange(BigDecimal lowerBound, BigDecimal upperBound);
}
