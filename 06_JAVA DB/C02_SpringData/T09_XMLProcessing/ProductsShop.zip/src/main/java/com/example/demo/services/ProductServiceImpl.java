package com.example.demo.services;

import com.example.demo.models.dtos.products.ProductDto;
import com.example.demo.models.dtos.products.ProductSeedDto;
import com.example.demo.models.dtos.products.ProductWithoutBuyerViewDto;
import com.example.demo.models.dtos.products.ProductsWithoutBuyerDto;
import com.example.demo.models.entities.Category;
import com.example.demo.models.entities.Product;
import com.example.demo.repositories.CategoryRepository;
import com.example.demo.repositories.ProductRepository;
import com.example.demo.repositories.UserRepository;
import com.example.demo.services.interfaces.ProductService;
import com.example.demo.utils.interfaces.ValidationUtil;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.math.BigDecimal;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;

@Service
public class ProductServiceImpl implements ProductService {
    private final ProductRepository productRepository;
    private final ValidationUtil validator;
    private final ModelMapper modelMapper;
    private final UserRepository userRepository;
    private final CategoryRepository categoryRepository;


    public ProductServiceImpl(ProductRepository productRepository, ValidationUtil validator, ModelMapper modelMapper, UserRepository userRepository, CategoryRepository categoryRepository) {
        this.productRepository = productRepository;
        this.validator = validator;
        this.modelMapper = modelMapper;
        this.userRepository = userRepository;
        this.categoryRepository = categoryRepository;
    }

    @Override
    @Transactional
    public void seedProducts(ProductSeedDto products) {
        long totalProducts = this.productRepository.count();

        if (totalProducts == 0) {
            List<ProductDto> validProductsDto = products.getProducts().stream()
                    .filter(this.validator::isValid).toList();

            long totalUsers = this.userRepository.count();

            validProductsDto.forEach(product -> {
                long randomSellerId = 0;
                long randomBuyerId = 0;

                while (randomBuyerId == randomSellerId) {
                    randomSellerId = ThreadLocalRandom.current().nextLong(1, totalUsers + 1);
                    randomBuyerId = ThreadLocalRandom.current().nextLong(1, totalUsers + 1);
                }

                product.setSeller(this.userRepository.getById(randomSellerId));

                if (product.getPrice().compareTo(BigDecimal.valueOf(700)) < 0) {
                    product.setBuyer(this.userRepository.getById(randomBuyerId));
                }

                long categoriesPerProduct = ThreadLocalRandom.current().nextLong(1, 5);
                long totalCategoriesCount = this.categoryRepository.count();
                Set<Category> categoriesToAdd = new LinkedHashSet<>();

                for (int i = 0; i < categoriesPerProduct; i++) {
                    long randomCategoryId = ThreadLocalRandom.current().nextLong(1, totalCategoriesCount + 1);
                    Category category = this.categoryRepository.getById(randomCategoryId);
                    categoriesToAdd.add(category);
                }
                product.setCategories(categoriesToAdd);
            });

            List<Product> productList = validProductsDto
                    .stream()
                    .map(productDto -> this.modelMapper.map(productDto, Product.class))
                    .toList();

            this.productRepository.saveAll(productList);
        }
    }

    @Override
    public ProductWithoutBuyerViewDto getAllProductsWithoutBuyerInPriceRange(BigDecimal lowerBound, BigDecimal upperBound) {
        List<ProductsWithoutBuyerDto> productsWithoutBuyerDto = this.productRepository
                .findAllByBuyerIsNullAndPriceBetweenOrderByPrice(lowerBound, upperBound)
                .stream()
                .map(product -> {
                    ProductsWithoutBuyerDto productDto = this.modelMapper
                            .map(product, ProductsWithoutBuyerDto.class);

                    String fullName =
                            product.getSeller().getFirstName() == null
                                    ? product.getSeller().getLastName()
                                    : product.getSeller().getFirstName() + " " + product.getSeller().getLastName();
                    productDto.setSeller(fullName);

                    return productDto;
                })
                .toList();

        return new ProductWithoutBuyerViewDto(productsWithoutBuyerDto);
    }
}