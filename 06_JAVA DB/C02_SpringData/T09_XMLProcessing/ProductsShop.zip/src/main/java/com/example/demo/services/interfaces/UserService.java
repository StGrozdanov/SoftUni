package com.example.demo.services.interfaces;

import com.example.demo.models.dtos.users.*;

public interface UserService {
    void seedUsers(UserSeedDto userDtoList);

    SellerViewDto getUsersWithOneOrMoreSoldProducts();

    UserSummaryDto getUsersAndProducts();
}
