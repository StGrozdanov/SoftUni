package com.example.demo.models.dtos.users;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "users")
@XmlAccessorType(XmlAccessType.FIELD)
public class SellerViewDto {
    @XmlElement(name = "user")
    List<SellerDto> sellers;

    public SellerViewDto() {
    }

    public SellerViewDto(List<SellerDto> sellers) {
        this.sellers = sellers;
    }

    public void setSellers(List<SellerDto> sellers) {
        this.sellers = sellers;
    }

    public List<SellerDto> getSellers() {
        return sellers;
    }
}
