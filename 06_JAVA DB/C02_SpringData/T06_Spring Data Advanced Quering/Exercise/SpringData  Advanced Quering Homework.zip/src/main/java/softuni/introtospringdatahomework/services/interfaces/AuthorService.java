package softuni.introtospringdatahomework.services.interfaces;

import softuni.introtospringdatahomework.models.Author;

import java.util.List;

public interface AuthorService {
    void registerAuthor(Author author);

    Author getRandomAuthor();

    long getAuthorsCount();

    void findAllAuthorsAndOrderByBookCountDesc();

    List<String> getAuthorsByFirstNameEndingWith(String symbols);

    List<String> getAuthorsByLastNameStartingWith(String criteria);

    List<String> getAuthorsTotalBookCopies();

}
