package softuni.introtospringdatahomework.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import softuni.introtospringdatahomework.models.Book;
import softuni.introtospringdatahomework.models.base.AgeRestriction;
import softuni.introtospringdatahomework.models.base.EditionType;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Set;

@Repository
public interface BookRepository extends JpaRepository<Book, Long> {
    Set<Book> findBooksByReleaseDateAfter(LocalDate releaseDate);

    Set<Book> findBooksByReleaseDateBefore(LocalDate releaseDate);

    Set<Book> findBooksByAuthorFirstNameAndAuthorLastNameOrderByReleaseDateDescTitle(String firstName, String lastName);

    Set<Book> findBooksByAgeRestriction(AgeRestriction ageRestriction);

    Set<Book> findBooksByEditionTypeAndCopiesLessThan(EditionType editionType, Integer copies);

    Set<Book> findBooksByPriceLessThanOrPriceGreaterThan(BigDecimal lowerBound, BigDecimal upperBound);

    Set<Book> findBooksByReleaseDateGreaterThanOrReleaseDateLessThan(LocalDate upperBound, LocalDate lowerBound);

    Set<Book> findBooksByTitleContaining(String title);

    Set<Book> findAllByAuthorLastNameStartsWith(String criteria);

    @Query("SELECT COUNT(b) FROM Book b WHERE LENGTH(b.title) > :number")
    int countBooksByTitleGreaterThan(int number);

    Set<Book> findBooksByTitle(String title);

    long deleteAllByCopiesLessThan(Integer copies);

    @Modifying
    @Query("UPDATE Book b SET b.copies = b.copies + :increaseBy WHERE b.releaseDate > :releaseDate")
    int increaseBookCopiesForBooksReleasedAfter(Integer increaseBy, LocalDate releaseDate);
}
