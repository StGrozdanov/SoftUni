package softuni.introtospringdatahomework.services;

import org.springframework.stereotype.Service;
import softuni.introtospringdatahomework.models.Category;
import softuni.introtospringdatahomework.repositories.CategoryRepository;
import softuni.introtospringdatahomework.services.interfaces.CategoryService;

import javax.transaction.Transactional;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;

@Service
public class CategoryServiceImpl implements CategoryService {
    private final CategoryRepository categoryRepository;

    public CategoryServiceImpl(CategoryRepository categoryRepository) {
        this.categoryRepository = categoryRepository;
    }

    @Override
    public void registerCategory(Category category) {
        this.categoryRepository.save(category);
    }

    @Override
    @Transactional
    public Set<Category> getRandomCategories() {
        long totalCategoriesCount = getCategoriesCount();

        int randomCategoryCountBetweenOneAndFour = ThreadLocalRandom.current().nextInt(1, 4);

        Set<Category> randomGeneratedCategories = new LinkedHashSet<>();

        for (int i = 0; i < randomCategoryCountBetweenOneAndFour; i++) {
            long randomCategoryId = ThreadLocalRandom.current().nextLong(1, totalCategoriesCount + 1);
            Category randomGeneratedCategory = this.categoryRepository.getById(randomCategoryId);
            randomGeneratedCategories.add(randomGeneratedCategory);
        }
        return randomGeneratedCategories;
    }

    @Override
    public long getCategoriesCount() {
        return this.categoryRepository.count();
    }
}
