package softuni.introtospringdatahomework.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import softuni.introtospringdatahomework.models.Author;

import java.util.Set;

@Repository
public interface AuthorRepository extends JpaRepository<Author, Long> {
    @Query("SELECT a FROM Author a ORDER BY SIZE(a.books) DESC")
    Set<Author> getAuthorsByBookCount();

    Set<Author> getAuthorsByFirstNameEndingWith(String criteria);

    Set<Author> getAuthorsByLastNameStartingWith(String criteria);

    @Query("SELECT a FROM Author a JOIN a.books b GROUP BY a ORDER BY SUM(b.copies) DESC")
    Set<Author> getAuthorsOrderedByTotalBookCopiesDescending();
}
