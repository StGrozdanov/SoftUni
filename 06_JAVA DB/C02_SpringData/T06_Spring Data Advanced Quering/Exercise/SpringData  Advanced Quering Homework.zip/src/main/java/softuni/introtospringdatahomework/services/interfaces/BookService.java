package softuni.introtospringdatahomework.services.interfaces;

import softuni.introtospringdatahomework.models.Book;
import softuni.introtospringdatahomework.models.base.AgeRestriction;

import java.time.LocalDate;
import java.util.List;

public interface BookService {
    void registerBook(Book book);

    long getBooksCount();

    void printBookTitlesReleasedAfterTheYearOf2000();

    void printBookAuthorsOfBooksReleasedBefore1990();

    void printBooksOrderedByReleaseDateByAuthorName(String firstName, String lastName);

    List<String> getBookTitlesByGivenAgeRestriction(AgeRestriction ageRestriction);

    List<String> getBookTitlesByGoldenEditionTypeAndLessThan5000Copies();

    List<String> getBooksPriceAndTitleForBooksWithPriceLowerThanFiveAndGreaterThanForty();

    List<String> getBookTitlesByReleaseYearThatIsNot(int year);

    List<String> getBookTitlesEditionsAndPriceByDateThatIsBefore(LocalDate date);

    List<String> getBookTitlesByTitleContaining(String criteria);

    List<String> getBooksByAuthorLastNameStartingWith(String criteria);

    int countBooksByTitleLongerThan(int number);

    List<String> getBookTitleEditionAgeRestrictionAndPriceByTitleInput(String title);

    void increaseBookCopiesOfBooksReleasedAfterAGivenDate(LocalDate releaseDate, Integer additionalCopies);

    void deleteBooksWithCopiesLowerThanTarget(Integer target);
}
