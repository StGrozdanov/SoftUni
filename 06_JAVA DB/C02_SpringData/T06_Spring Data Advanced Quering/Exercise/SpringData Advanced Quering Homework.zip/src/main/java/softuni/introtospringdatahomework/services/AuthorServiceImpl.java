package softuni.introtospringdatahomework.services;

import org.springframework.stereotype.Service;
import softuni.introtospringdatahomework.models.Author;
import softuni.introtospringdatahomework.models.Book;
import softuni.introtospringdatahomework.repositories.AuthorRepository;
import softuni.introtospringdatahomework.services.interfaces.AuthorService;

import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.Collectors;

@Service
public class AuthorServiceImpl implements AuthorService {
    private final AuthorRepository authorRepository;

    public AuthorServiceImpl(AuthorRepository authorRepository) {
        this.authorRepository = authorRepository;
    }

    @Override
    public void registerAuthor(Author author) {
        this.authorRepository.save(author);
    }

    @Override
    public Author getRandomAuthor() {
        long randomLong = ThreadLocalRandom.current().nextLong(1, this.getAuthorsCount() + 1);
        return this.authorRepository.getById(randomLong);
    }

    @Override
    public long getAuthorsCount() {
        return this.authorRepository.count();
    }

    @Override
    public void findAllAuthorsAndOrderByBookCountDesc() {
        this.authorRepository.getAuthorsByBookCount().forEach(author -> {
            System.out.printf("%s %s has written %d books.%n",
                    author.getFirstName(), author.getLastName(), author.getBooks().size());
        });
    }

    @Override
    public List<String> getAuthorsByFirstNameEndingWith(String symbols) {
        return this.authorRepository
                .getAuthorsByFirstNameEndingWith(symbols)
                .stream()
                .map(author -> String.format("%s %s", author.getFirstName(), author.getLastName()))
                .collect(Collectors.toList());
    }

    @Override
    public List<String> getAuthorsByLastNameStartingWith(String criteria) {
        return null;
    }

    @Override
    public List<String> getAuthorsTotalBookCopies() {
        return this.authorRepository
                .getAuthorsOrderedByTotalBookCopiesDescending()
                .stream()
                .map(author -> String.format("%s %s - %d", author.getFirstName(), author.getLastName(),
                        author.getBooks()
                                .stream()
                                .map(Book::getCopies)
                                .mapToInt(Integer::intValue)
                                .sum()
                ))
                .collect(Collectors.toList());
    }
}
