package softuni.introtospringdatahomework.services;

import org.springframework.stereotype.Service;
import softuni.introtospringdatahomework.models.Book;
import softuni.introtospringdatahomework.models.base.AgeRestriction;
import softuni.introtospringdatahomework.models.base.EditionType;
import softuni.introtospringdatahomework.repositories.BookRepository;
import softuni.introtospringdatahomework.services.interfaces.BookService;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class BookServiceImpl implements BookService {
    private final BookRepository bookRepository;

    public BookServiceImpl(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    @Override
    public void registerBook(Book book) {
        this.bookRepository.save(book);
    }

    @Override
    public long getBooksCount() {
        return this.bookRepository.count();
    }

    @Override
    public void printBookTitlesReleasedAfterTheYearOf2000() {
        LocalDate criteriaDate = LocalDate.of(1999, 12, 31);

        this.bookRepository
                .findBooksByReleaseDateAfter(criteriaDate)
                .forEach(book -> System.out.println(book.getTitle()));
    }

    @Override
    public void printBookAuthorsOfBooksReleasedBefore1990() {
        LocalDate criteriaDate = LocalDate.of(1999, 1, 1);

        this.bookRepository
                .findBooksByReleaseDateBefore(criteriaDate)
                .stream()
                .map(Book::getAuthor)
                .distinct()
                .forEach(author -> System.out.printf("%s %s%n", author.getFirstName(), author.getLastName()));
    }

    @Override
    public void printBooksOrderedByReleaseDateByAuthorName(String firstName, String lastName) {
        this.bookRepository
                .findBooksByAuthorFirstNameAndAuthorLastNameOrderByReleaseDateDescTitle(firstName, lastName)
                .forEach(book -> System.out.printf("Title: %s, Release Date: %s, Copies: %d%n",
                        book.getTitle(), book.getReleaseDate(), book.getCopies()));
    }

    @Override
    public List<String> getBookTitlesByGivenAgeRestriction(AgeRestriction ageRestriction) {
        return this.bookRepository
                .findBooksByAgeRestriction(ageRestriction)
                .stream()
                .map(Book::getTitle)
                .collect(Collectors.toList());
    }

    @Override
    public List<String> getBookTitlesByGoldenEditionTypeAndLessThan5000Copies() {
        return this.bookRepository.
                findBooksByEditionTypeAndCopiesLessThan(EditionType.GOLD, 5000)
                .stream()
                .map(Book::getTitle)
                .collect(Collectors.toList());
    }

    @Override
    public List<String> getBooksPriceAndTitleForBooksWithPriceLowerThanFiveAndGreaterThanForty() {
        return this.bookRepository
                .findBooksByPriceLessThanOrPriceGreaterThan(BigDecimal.valueOf(5), BigDecimal.valueOf(40))
                .stream()
                .map(book -> String.format("%s - $%.2f", book.getTitle(), book.getPrice()))
                .collect(Collectors.toList());
    }

    @Override
    public List<String> getBookTitlesByReleaseYearThatIsNot(int year) {
        LocalDate lowerBound = LocalDate.of(year, 1, 1);
        LocalDate upperBound = LocalDate.of(year, 12, 31);

        return this.bookRepository
                .findBooksByReleaseDateGreaterThanOrReleaseDateLessThan(upperBound, lowerBound)
                .stream()
                .map(Book::getTitle)
                .collect(Collectors.toList());

    }

    @Override
    public List<String> getBookTitlesEditionsAndPriceByDateThatIsBefore(LocalDate date) {
        return this.bookRepository
                .findBooksByReleaseDateBefore(date)
                .stream()
                .map(book -> String.format("%s %s %.2f",
                        book.getTitle(), book.getEditionType().toString(), book.getPrice()))
                .collect(Collectors.toList());
    }

    @Override
    public List<String> getBookTitlesByTitleContaining(String criteria) {
        return this.bookRepository
                .findBooksByTitleContaining(criteria)
                .stream()
                .map(Book::getTitle)
                .collect(Collectors.toList());
    }

    @Override
    public List<String> getBooksByAuthorLastNameStartingWith(String criteria) {
        return this.bookRepository
                .findAllByAuthorLastNameStartsWith(criteria)
                .stream()
                .map(book -> String.format("%s (%s %s)", book.getTitle(), book.getAuthor().getFirstName(),
                        book.getAuthor().getLastName()))
                .collect(Collectors.toList());
    }

    @Override
    public int countBooksByTitleLongerThan(int number) {
        return this.bookRepository.countBooksByTitleGreaterThan(number);
    }

    @Override
    public List<String> getBookTitleEditionAgeRestrictionAndPriceByTitleInput(String title) {
        return this.bookRepository
                .findBooksByTitle(title)
                .stream()
                .map(book -> String.format("%s %s %s %.2f", book.getTitle(), book.getEditionType().toString(),
                        book.getAgeRestriction().toString(), book.getPrice()))
                .collect(Collectors.toList());
    }
}
