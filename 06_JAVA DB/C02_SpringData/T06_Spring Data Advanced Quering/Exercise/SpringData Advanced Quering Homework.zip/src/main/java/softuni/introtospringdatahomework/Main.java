package softuni.introtospringdatahomework;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import softuni.introtospringdatahomework.models.Author;
import softuni.introtospringdatahomework.models.Book;
import softuni.introtospringdatahomework.models.Category;
import softuni.introtospringdatahomework.models.base.AgeRestriction;
import softuni.introtospringdatahomework.models.base.EditionType;
import softuni.introtospringdatahomework.services.interfaces.AuthorService;
import softuni.introtospringdatahomework.services.interfaces.BookService;
import softuni.introtospringdatahomework.services.interfaces.CategoryService;

import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.Set;
import java.util.stream.Collectors;

@Component
public class Main implements CommandLineRunner {
    private final CategoryService categoryService;
    private final AuthorService authorService;
    private final BookService bookService;
    private final Scanner scanner;

    public Main(CategoryService categoryService, AuthorService authorService, BookService bookService, Scanner scanner) {
        this.categoryService = categoryService;
        this.authorService = authorService;
        this.bookService = bookService;
        this.scanner = scanner;
    }

    @Override
    public void run(String... args) {
        try {
            seedDatabase();
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("Hello, please select exercise number you want to test - from 1 to 11, to exit type finish");
        String choice = this.scanner.nextLine();

        while (!choice.equals("finish")) {
            try {
                switch (choice) {
                    case "1" -> exerciseOne();
                    case "2" -> exerciseTwo();
                    case "3" -> exerciseThree();
                    case "4" -> exerciseFour();
                    case "5" -> exerciseFive();
                    case "6" -> exerciseSix();
                    case "7" -> exerciseSeven();
                    case "8" -> exerciseEight();
                    case "9" -> exerciseNine();
                    case "10" -> exerciseTen();
                    case "11" -> exerciseEleven();
                }
            } catch (IllegalArgumentException e) {
                e.printStackTrace();
            }
            System.out.println("Please select exercise number you want to test - from 1 to 11, to exit type finish");
            choice = this.scanner.nextLine();
        }

    }

    private void exerciseEleven() {
        System.out.println("What is the title of the book you are looking for?");
        String title = scanner.nextLine();

        this.bookService.getBookTitleEditionAgeRestrictionAndPriceByTitleInput(title).forEach(System.out::println);
    }

    private void exerciseTen() {
        this.authorService.getAuthorsTotalBookCopies().forEach(System.out::println);
    }

    private void exerciseNine() {
        System.out.println("What is the number?");
        int number = Integer.parseInt(scanner.nextLine());

        System.out.println(this.bookService.countBooksByTitleLongerThan(number));
    }

    private void exerciseEight() {
        System.out.println("Please enter the criteria.");
        String criteria = scanner.nextLine();

        this.bookService.getBooksByAuthorLastNameStartingWith(criteria).forEach(System.out::println);
    }

    private void exerciseSeven() {
        System.out.println("Please enter the criteria.");
        String criteria = scanner.nextLine();

        this.bookService.getBookTitlesByTitleContaining(criteria).forEach(System.out::println);
    }

    private void exerciseSix() {
        System.out.println("Please enter the criteria.");
        String criteria = scanner.nextLine();

        this.authorService.getAuthorsByFirstNameEndingWith(criteria).forEach(System.out::println);
    }

    private void exerciseFive() {
        System.out.println("What is the target date?");
        String input = scanner.nextLine();
        LocalDate date = LocalDate.parse(input, DateTimeFormatter.ofPattern("dd-MM-yyyy"));

        this.bookService
                .getBookTitlesEditionsAndPriceByDateThatIsBefore(date)
                .forEach(System.out::println);
    }

    private void exerciseFour() {
        System.out.println("What is the target year?");
        int targetYear = Integer.parseInt(scanner.nextLine());

        this.bookService.getBookTitlesByReleaseYearThatIsNot(targetYear).forEach(System.out::println);
    }

    private void exerciseThree() {
        this.bookService
                .getBooksPriceAndTitleForBooksWithPriceLowerThanFiveAndGreaterThanForty()
                .forEach(System.out::println);
    }

    private void exerciseTwo() {
        this.bookService.getBookTitlesByGoldenEditionTypeAndLessThan5000Copies().forEach(System.out::println);
    }

    private void exerciseOne() throws IllegalArgumentException {
        System.out.println("What is the age restriction?");
        String restriction = this.scanner.nextLine().toUpperCase();
        List<String> restrictionTypes = List.of("MINOR", "TEEN", "ADULT");

        if (!restrictionTypes.contains(restriction)) {
            System.out.println("Age restrictions can be one of the following: minor / teen / adult!");
            return;
        }

        this.bookService
                .getBookTitlesByGivenAgeRestriction(AgeRestriction.valueOf(restriction))
                .forEach(System.out::println);
    }

    private void seedDatabase() throws IOException {
        String CATEGORIES_PATH = "src/main/resources/files/categories.txt";
        String AUTHORS_PATH = "src/main/resources/files/authors.txt";
        String BOOKS_PATH = "src/main/resources/files/books.txt";

        seedCategories(CATEGORIES_PATH);
        seedAuthors(AUTHORS_PATH);
        seedBooks(BOOKS_PATH);
    }

    private void seedBooks(String path) throws IOException {
        if (this.bookService.getBooksCount() == 0) {
            Files.readAllLines(Path.of(path)).forEach(input -> {

                Book book = createBookByInput(input);
                Author author = this.authorService.getRandomAuthor();
                Set<Category> categories = this.categoryService.getRandomCategories();

                book.setAuthor(author);
                book.setCategories(categories);

                this.bookService.registerBook(book);
            });
        }
    }

    private Book createBookByInput(String input) {
        String[] tokens = input.split("\\s+");

        int editionTypeNumber = Integer.parseInt(tokens[0]);
        String date = tokens[1];
        double priceAsDouble = Double.parseDouble(tokens[3]);
        int ageRestrictionNumber = Integer.parseInt(tokens[4]);

        Integer soldCopies = Integer.parseInt(tokens[2]);
        String title = Arrays.stream(tokens).skip(5).collect(Collectors.joining(" "));
        EditionType editionType = EditionType.values()[editionTypeNumber];
        LocalDate releaseDate = LocalDate.parse(date, DateTimeFormatter.ofPattern("d/M/yyyy"));
        BigDecimal price = BigDecimal.valueOf(priceAsDouble);
        AgeRestriction ageRestriction = AgeRestriction.values()[ageRestrictionNumber];

        return new Book(title, releaseDate, price, soldCopies, editionType, ageRestriction);
    }

    private void seedAuthors(String path) throws IOException {
        if (this.authorService.getAuthorsCount() == 0) {
            Files.
                    readAllLines(Path.of(path))
                    .forEach(input -> {
                        String[] tokens = input.split("\\s+");
                        String firstName = tokens[0];
                        String lastName = tokens[1];

                        Author author = new Author(firstName, lastName);

                        this.authorService.registerAuthor(author);
                    });
        }
    }

    private void seedCategories(String path) throws IOException {
        if (this.categoryService.getCategoriesCount() == 0) {
            Files.
                    readAllLines(Path.of(path))
                    .stream()
                    .filter(category -> !category.isEmpty())
                    .collect(Collectors.toList())
                    .forEach(categoryName -> {
                        Category category = new Category(categoryName);
                        this.categoryService.registerCategory(category);
                    });
        }
    }
}
