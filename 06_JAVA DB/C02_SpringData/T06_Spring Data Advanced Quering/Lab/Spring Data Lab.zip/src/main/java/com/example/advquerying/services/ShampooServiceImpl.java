package com.example.advquerying.services;

import com.example.advquerying.entities.Size;
import com.example.advquerying.repositories.ShampooRepository;
import com.example.advquerying.services.interfaces.ShampooService;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;

@Service
public class ShampooServiceImpl implements ShampooService {
    private final ShampooRepository shampooRepository;

    public ShampooServiceImpl(ShampooRepository shampooRepository) {
        this.shampooRepository = shampooRepository;
    }

    @Override
    public void printShampoosBySize(Size size) {
        this.shampooRepository
                .findShampoosBySizeOrderById(size)
                .forEach(System.out::println);
    }

    @Override
    public void printShampoosBySizeOrLabelId(Size size, Long labelId) {
        this.shampooRepository
                .findShampoosBySizeOrLabel_IdOrderByPrice(size, labelId)
                .forEach(System.out::println);
    }

    @Override
    public void printShampoosWithBiggerPriceThanTarget(BigDecimal target) {
        this.shampooRepository
                .findShampoosByPriceGreaterThanOrderByPriceDesc(target)
                .forEach(System.out::println);
    }

    @Override
    public int countShampoosByPriceLessThanTarget(BigDecimal target) {
        return this.shampooRepository.countShampoosByPriceIsLessThan(target);
    }

    @Override
    public void printShampooNamesByIngredientNames(List<String> ingredientsNames) {
        this.shampooRepository.findShampoosNamesByIngredientsNames(ingredientsNames).forEach(System.out::println);
    }

    @Override
    public void printShampoosByIngredientsLessThanTargetNumber(long number) {
        this.shampooRepository.printShampoosByIngredientsLessThanTargetNumber(number).forEach(System.out::println);
    }
}
