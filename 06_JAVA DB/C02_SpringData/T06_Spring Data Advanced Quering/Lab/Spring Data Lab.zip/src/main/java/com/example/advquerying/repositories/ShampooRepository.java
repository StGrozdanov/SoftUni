package com.example.advquerying.repositories;

import com.example.advquerying.entities.Shampoo;
import com.example.advquerying.entities.Size;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;

@Repository
public interface ShampooRepository extends JpaRepository<Shampoo, Long> {
    List<Shampoo> findShampoosBySizeOrderById(Size size);

    List<Shampoo> findShampoosBySizeOrLabel_IdOrderByPrice(Size size, Long labelId);

    List<Shampoo> findShampoosByPriceGreaterThanOrderByPriceDesc(BigDecimal price);

    int countShampoosByPriceIsLessThan(BigDecimal price);

    @Query("SELECT DISTINCT s.brand FROM Shampoo s JOIN s.ingredients i WHERE i.name IN :names")
    List<String> findShampoosNamesByIngredientsNames(@Param("names") List<String> ingredientNames);

    @Query("SELECT s.brand FROM Shampoo s JOIN s.ingredients i GROUP BY s.id HAVING COUNT(i) < :number")
    List<String> printShampoosByIngredientsLessThanTargetNumber(@Param("number") long number);
}
