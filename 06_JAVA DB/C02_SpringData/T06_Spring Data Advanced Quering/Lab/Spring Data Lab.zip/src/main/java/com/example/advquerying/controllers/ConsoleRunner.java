package com.example.advquerying.controllers;

import com.example.advquerying.services.interfaces.IngredientService;
import com.example.advquerying.services.interfaces.ShampooService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Scanner;

@Component
public class ConsoleRunner implements CommandLineRunner {
    private final ShampooService shampooService;
    private final IngredientService ingredientService;

    public ConsoleRunner(ShampooService shampooService, IngredientService ingredientService) {
        this.shampooService = shampooService;
        this.ingredientService = ingredientService;
    }

    @Override
    public void run(String... args) throws Exception {
        Scanner scanner = new Scanner(System.in);

//        //P01
//        System.out.println("What is the size of the targeted shampoos? (SMALL, MEDIUM, LARGE");
//        Size size = Size.valueOf(scanner.nextLine());
//        this.shampooService.printShampoosBySize(size);

//        //P02
//        System.out.println("What is the size of the targeted shampoos? (SMALL, MEDIUM, LARGE");
//        Size size = Size.valueOf(scanner.nextLine());
//        System.out.println("Please enter label id");
//        Long labelId = Long.parseLong(scanner.nextLine());
//
//        this.shampooService.printShampoosBySizeOrLabelId(size, labelId);

//        //PO3
//        System.out.println("What is the target price?");
//        BigDecimal target = BigDecimal.valueOf(Double.parseDouble(scanner.nextLine()));
//        this.shampooService.printShampoosWithBiggerPriceThanTarget(target);

//        //P04
//        System.out.println("What is the starting sequence of the ingredient name?");
//        String sequence = scanner.nextLine();
//        this.ingredientService.printIngredientsStartingWithGivenSequence(sequence);

//        //P05
//        System.out.println("Enter 3 ingredients separated on new line");
//        List<String> names = List.of(scanner.nextLine(), scanner.nextLine(), scanner.nextLine());
//        this.ingredientService.printIngredientNamesContainedInAList(names);

//        //P06
//        System.out.println("What is the target price?");
//        BigDecimal target = BigDecimal.valueOf(Double.parseDouble(scanner.nextLine()));
//        System.out.println(this.shampooService.countShampoosByPriceLessThanTarget(target));

//        //P07
//        System.out.println("Enter 2 ingredients separated on new line");
//        List<String> ingredientsNames = List.of(scanner.nextLine(), scanner.nextLine());
//        this.shampooService.printShampooNamesByIngredientNames(ingredientsNames);

//        //P08
//        System.out.println("Enter number of ingredients");
//        long number = Long.parseLong(scanner.nextLine());
//        this.shampooService.printShampoosByIngredientsLessThanTargetNumber(number);

//
        //P09
//        System.out.println("Enter the name of ingredients you want to delete");
//        String name = scanner.nextLine();
//        int deletedEntities = this.ingredientService.deleteIngredientsByIngredientName(name);
//        System.out.printf("%d entities were deleted.", deletedEntities);

//        //P10
//        int updatedEntities = this.ingredientService.increaseIngredientPricesBy10Percent();
//        System.out.printf("%d ingredients are with updated price.", updatedEntities);

        //P11
        System.out.println("Enter the names of the ingredients you want to increase price for separated by space");
        List<String> names = List.of(scanner.nextLine().split("\\s+"));
        int updatedEntities = this.ingredientService.increaseIngredientPricesBy10PercentByGivenNames(names);
        System.out.printf("%d ingredients are with updated price.%n", updatedEntities);
    }
}
