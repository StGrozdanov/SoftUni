package com.example.advquerying.services;

import com.example.advquerying.repositories.IngredientRepository;
import com.example.advquerying.services.interfaces.IngredientService;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.Collection;
import java.util.List;

@Service
public class IngredientServiceImpl implements IngredientService {
    private final IngredientRepository ingredientRepository;

    public IngredientServiceImpl(IngredientRepository ingredientRepository) {
        this.ingredientRepository = ingredientRepository;
    }

    @Override
    public void printIngredientsStartingWithGivenSequence(String sequence) {
        this.ingredientRepository
                .findAllByNameStartingWith(sequence)
                .forEach(ingredient -> System.out.println(ingredient.getName()));
    }

    @Override
    public void printIngredientNamesContainedInAList(List<String> names) {
        this.ingredientRepository
                .findAllByNameInOrderByPrice(names)
                .forEach(ingredient -> System.out.println(ingredient.getName()));
    }

    @Override
    @Transactional
    public int deleteIngredientsByIngredientName(String name) {
        return this.ingredientRepository.deleteIngredientsByName(name);
    }

    @Override
    @Transactional
    public int increaseIngredientPricesBy10Percent() {
        return this.ingredientRepository.updateIngredientPricesBy10Percent();
    }

    @Override
    @Transactional
    public int increaseIngredientPricesBy10PercentByGivenNames(Collection<String> names) {
        return this.ingredientRepository.updateIngredientPricesBy10PercentForIngredientsInAGivenList(names);
    }
}
