package com.example.advquerying.services.interfaces;

import java.util.Collection;
import java.util.List;

public interface IngredientService {
    void printIngredientsStartingWithGivenSequence(String sequence);

    void printIngredientNamesContainedInAList(List<String> names);

    int deleteIngredientsByIngredientName(String name);

    int increaseIngredientPricesBy10Percent();

    int increaseIngredientPricesBy10PercentByGivenNames(Collection<String> names);
}
