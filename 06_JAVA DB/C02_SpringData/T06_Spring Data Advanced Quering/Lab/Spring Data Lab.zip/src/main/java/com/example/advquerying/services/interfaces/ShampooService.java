package com.example.advquerying.services.interfaces;

import com.example.advquerying.entities.Size;

import java.math.BigDecimal;
import java.util.List;

public interface ShampooService {
    void printShampoosBySize(Size size);

    void printShampoosBySizeOrLabelId(Size size, Long labelId);

    void printShampoosWithBiggerPriceThanTarget(BigDecimal target);

    int countShampoosByPriceLessThanTarget(BigDecimal target);

    void printShampooNamesByIngredientNames(List<String> ingredientsNames);

    void printShampoosByIngredientsLessThanTargetNumber(long number);
}
