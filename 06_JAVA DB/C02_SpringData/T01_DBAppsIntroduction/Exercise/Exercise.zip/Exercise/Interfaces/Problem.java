package T01_DBAppsIntroduction.Exercise.Interfaces;

import java.sql.SQLException;

public interface Problem {
    void solve() throws SQLException;
}
