The homework is wrapped as a whole program instead of a different one for
every single problem in order to evade the need of entering your username and
password credentials each and every time.

To start the project:

1) Setup the SDK
2) go to File -> Libraries -> + -> Java -> Navigate to the included connector in the zip
and click apply
3) Run Main and follow the instructions in the console. All you need to have is
minion_db, everything else is included.

The local host configuration is set to port 3306. If yours is different for
some reason, you can change it in Helpers directory -> DatabaseTool -> constant ADDRESS.

If you are testing exercise 9 read the TODO.

To stop the program type finish.