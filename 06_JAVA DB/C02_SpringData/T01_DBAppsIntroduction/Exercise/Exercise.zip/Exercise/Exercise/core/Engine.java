package T01_DBAppsIntroduction.Exercise.core;
import T01_DBAppsIntroduction.Exercise.Helpers.DatabaseTool;
import T01_DBAppsIntroduction.Exercise.Interfaces.Problem;
import T01_DBAppsIntroduction.Exercise.Problems.*;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

public class Engine implements Runnable {
    private DatabaseTool dbTool;
    private Scanner scanner;

    public Engine(DatabaseTool tool) {
        this.dbTool = tool;
        this.scanner = new Scanner(System.in);
    }

    @Override
    public void run() {
        System.out.println("Please, write down the exercise number you want to test - from 2 to 9");

        String input = this.scanner.nextLine();

        while (!input.equals("finish")) {
            int exerciseNumber = 0;
            try {
                exerciseNumber = Integer.parseInt(input);
            } catch (NumberFormatException e) {
                System.out.println("Try with a number this time :)");
            }
            testExerciseProblems(exerciseNumber, this.dbTool);
            System.out.println("Please enter the next exercise number you want to test or the same exercise number " +
                    "as the previous if you want to test the exercise with different input or write finish to end the " +
                    "program");
            input = this.scanner.nextLine();
        }
    }

    private static void testExerciseProblems(int problemNumber, DatabaseTool dbTool) {
        Map<Integer, Problem> problemMap = new LinkedHashMap<>(Map.of(
                2, new P02_GetVillainsNames(dbTool),
                3, new P03_GetMinionNames(dbTool),
                4, new P04_AddMinion(dbTool),
                5, new P05_ChangeTownNamesCasing(dbTool),
                6, new P06_RemoveVillain(dbTool),
                7, new P07_PrintAllMinionNames(dbTool),
                8, new P08_IncreaseMinionsAge(dbTool),
                9, new P09_IncreaseAgeStoredProcedure(dbTool)
        ));

        try {
            problemMap.get(problemNumber).solve();
        } catch (Exception e) {
            System.out.println("There isn't such exercise number in my homework :)");
        }
    }
}