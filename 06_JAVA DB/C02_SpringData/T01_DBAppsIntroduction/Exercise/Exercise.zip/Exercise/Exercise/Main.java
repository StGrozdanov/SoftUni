package T01_DBAppsIntroduction.Exercise;

import T01_DBAppsIntroduction.Exercise.Helpers.DatabaseTool;
import T01_DBAppsIntroduction.Exercise.core.Engine;

import java.sql.SQLException;
import java.util.Properties;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws SQLException {
        Properties props = getProperties();
        DatabaseTool dbTool = new DatabaseTool(props);
        Engine engine = new Engine(dbTool);
        engine.run();
    }

    private static Properties getProperties() {
        Scanner scanner = new Scanner(System.in);
        Properties props = new Properties();

        System.out.printf("Hello, please enter your local database credentials:%nUsername:%n");
        String username = scanner.nextLine();
        System.out.println("Password:");
        String password = scanner.nextLine();

        props.setProperty("user", username);
        props.setProperty("password", password);

        return props;
    }
}
