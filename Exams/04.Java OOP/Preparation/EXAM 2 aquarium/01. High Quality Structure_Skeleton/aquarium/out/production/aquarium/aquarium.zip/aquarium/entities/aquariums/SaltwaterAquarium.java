package aquarium.entities.aquariums;

import aquarium.entities.fish.Fish;

import java.util.Collection;

public class SaltwaterAquarium extends BaseAquarium{
    public SaltwaterAquarium(String name) {
        super(name, 25);
    }

    @Override
    public String getInfo() {
        StringBuilder sb = new StringBuilder();
        sb.append(this.getName())
                .append(" ")
                .append("(SaltwaterAquarium):")
                .append(System.lineSeparator())
                .append("Fish: ");

        if (super.getFish().isEmpty()) {
            sb.append("none");
        } else {
            Collection<Fish> fish = super.getFish();

            for (Fish fish1 : fish) {
                sb.append(fish1.getName()).append(" ");
            }

            String exit = sb.toString().trim();
            sb.setLength(0);
            sb.append(exit);
        }
        sb.append(System.lineSeparator())
                .append("Decorations: ")
                .append(super.getDecorations().size())
                .append(System.lineSeparator())
                .append("Comfort: ")
                .append(super.calculateComfort());

        return sb.toString().trim();
    }

}
