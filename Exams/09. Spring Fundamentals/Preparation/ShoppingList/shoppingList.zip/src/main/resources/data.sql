INSERT INTO categories (id, name, description)
VALUES (1, "FOOD", 'Something to eat, please');

INSERT INTO categories (id, name, description)
VALUES (2, "DRINK", 'Something to drink, please');

INSERT INTO categories (id, name, description)
VALUES (3, "HOUSEHOLD", 'I like my house');

INSERT INTO categories (id, name, description)
VALUES (4, "OTHER", 'I like other things better');