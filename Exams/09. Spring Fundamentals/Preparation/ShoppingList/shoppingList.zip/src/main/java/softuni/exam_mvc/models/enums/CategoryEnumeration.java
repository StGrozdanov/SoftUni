package softuni.exam_mvc.models.enums;

public enum CategoryEnumeration {
    FOOD, DRINK, HOUSEHOLD, OTHER
}
