package softuni.exam_mvc.models.dtos.ProductDTOs;

import org.springframework.format.annotation.DateTimeFormat;
import softuni.exam_mvc.models.enums.CategoryEnumeration;
import softuni.exam_mvc.utils.validators.UniqueProductNameValidator.UniqueProductName;

import javax.validation.constraints.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

public class CreateProductDTO {
    private String name;
    private String description;
    private BigDecimal price;
    private LocalDateTime neededBefore;
    private String category;

    public CreateProductDTO() {
    }

    @NotBlank(message = "Product name is required")
    @Size(min = 3, max = 20, message = "Product name length should be between 3 and 20 characters")
    @UniqueProductName
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @NotBlank
    @Size(min = 5)
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @NotNull
    @Positive
    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    @NotNull
    @FutureOrPresent
    @DateTimeFormat(pattern = "yyyy-MM-dd'T'HH:mm")
    public LocalDateTime getNeededBefore() {
        return neededBefore;
    }

    public void setNeededBefore(LocalDateTime neededBefore) {
        this.neededBefore = neededBefore;
    }

    @NotBlank
    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }
}
