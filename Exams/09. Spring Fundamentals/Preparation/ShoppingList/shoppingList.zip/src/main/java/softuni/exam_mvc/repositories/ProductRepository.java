package softuni.exam_mvc.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import softuni.exam_mvc.models.entities.ProductEntity;
import softuni.exam_mvc.models.enums.CategoryEnumeration;

import java.util.List;
import java.util.Optional;

@Repository
public interface ProductRepository extends JpaRepository<ProductEntity, Long> {
    Optional<ProductEntity> findByName(String name);

    List<ProductEntity> findByCategoryName(CategoryEnumeration category);
}
