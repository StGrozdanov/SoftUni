package softuni.exam_mvc.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import softuni.exam_mvc.models.dtos.UserDTOs.UserLoginDTO;
import softuni.exam_mvc.models.dtos.UserDTOs.UserRegisterDTO;
import softuni.exam_mvc.models.sessions.UserSession;
import softuni.exam_mvc.services.UserService;

import javax.validation.Valid;

@Controller
public class UserController {

    private final UserService userService;
    private final UserSession userSession;

    public UserController(UserService userService, UserSession userSession) {
        this.userService = userService;
        this.userSession = userSession;
    }

    @GetMapping("/login")
    public String loginPage() {
        return this.userSession.getLoggedIn() ? "home" : "login";
    }

    @PostMapping("/register")
    public String registerPage(
            @Valid UserRegisterDTO user,
            BindingResult bindingResult,
            RedirectAttributes redirectAttributes)
    {
        if (bindingResult.hasErrors()) {
            handleUserPostErrors(user, bindingResult, redirectAttributes);
            return "redirect:/register";
        }

        this.userService.registerUser(user);
        return "redirect:/login";
    }

    @PostMapping("login")
    public String loginUser(
            @Valid UserLoginDTO userLoginDTO,
            BindingResult bindingResult,
            RedirectAttributes redirectAttributes)
    {
        if (bindingResult.hasErrors()) {
            handleUserPostErrors(userLoginDTO, bindingResult, redirectAttributes);
            return "redirect:/login";
        }

        this.userService.userLogin(userLoginDTO);
        return "redirect:/";
    }

    @GetMapping("/register")
    public String registerPage() {
        return this.userSession.getLoggedIn() ? "home" : "register";
    }

    @GetMapping("/logout")
    public String logout() {
        this.userService.logout();
        return "redirect:/";
    }

    @ModelAttribute("userModel")
    public UserRegisterDTO initUserModel() {
        return new UserRegisterDTO();
    }

    private void handleUserPostErrors(Object userInput, BindingResult bindingResult, RedirectAttributes redirectAttributes) {
        redirectAttributes.addFlashAttribute("userModel", userInput);
        redirectAttributes.addFlashAttribute("org.springframework.validation.BindingResult.userModel",
                bindingResult);
    }
}
