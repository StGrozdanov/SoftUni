package softuni.exam_mvc.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import softuni.exam_mvc.models.dtos.ProductDTOs.CreateProductDTO;
import softuni.exam_mvc.models.sessions.UserSession;
import softuni.exam_mvc.services.ProductService;

import javax.validation.Valid;

@Controller
public class ProductController {
    private final UserSession userSession;
    private final ProductService productService;

    public ProductController(UserSession userSession, ProductService productService) {
        this.userSession = userSession;
        this.productService = productService;
    }

    @GetMapping("products/add")
    public String addProductPage() {
        return this.userSession.getLoggedIn() ? "product-add" : "index";
    }

    @PostMapping("products/add")
    public String addProduct(@Valid CreateProductDTO product,
                             BindingResult bindingResult,
                             RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            redirectAttributes.addFlashAttribute("productModel", product);
            redirectAttributes.addFlashAttribute(
                    "org.springframework.validation.BindingResult.productModel", bindingResult);
            return "redirect:/products/add";
        }

        this.productService.createNewProduct(product);

        return "redirect:/";
    }

    @ModelAttribute(name = "productModel")
    public CreateProductDTO initProduct() {
        return new CreateProductDTO();
    }

    @GetMapping("/products/buyAll")
    public String buyAllProducts() {
        this.productService.buyAllProducts();
        return "redirect:/";
    }

    @GetMapping("/buyProduct/{id}")
    public String buyProduct(@PathVariable Long id) {
        this.productService.buyProduct(id);
        return "redirect:/";
    }
}
