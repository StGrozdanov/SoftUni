package softuni.exam_mvc.models.entities;

import softuni.exam_mvc.models.enums.CategoryEnumeration;

import javax.persistence.*;

@Entity
@Table(name = "categories")
public class CategoryEntity extends BaseEntity {
    private CategoryEnumeration name;
    private String description;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    public CategoryEnumeration getName() {
        return name;
    }

    public void setName(CategoryEnumeration name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
