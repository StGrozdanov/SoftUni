package softuni.exam_mvc.services;

import org.springframework.stereotype.Service;
import softuni.exam_mvc.models.entities.CategoryEntity;
import softuni.exam_mvc.models.enums.CategoryEnumeration;
import softuni.exam_mvc.repositories.CategoryRepository;

@Service
public class CategoryService {
    private CategoryRepository categoryRepository;

    public CategoryService(CategoryRepository categoryRepository) {
        this.categoryRepository = categoryRepository;
    }

    public CategoryEntity findCategoryByName(String category) {
       return this.categoryRepository.findByName(CategoryEnumeration.valueOf(category)).orElse(null);
    }
}
