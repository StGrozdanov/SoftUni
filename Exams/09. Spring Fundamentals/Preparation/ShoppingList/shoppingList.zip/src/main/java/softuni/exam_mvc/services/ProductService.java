package softuni.exam_mvc.services;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import softuni.exam_mvc.models.dtos.ProductDTOs.CreateProductDTO;
import softuni.exam_mvc.models.entities.CategoryEntity;
import softuni.exam_mvc.models.entities.ProductEntity;
import softuni.exam_mvc.models.enums.CategoryEnumeration;
import softuni.exam_mvc.repositories.ProductRepository;

import java.math.BigDecimal;
import java.util.List;

@Service
public class ProductService {
    private ProductRepository productRepository;
    private ModelMapper modelMapper;
    private CategoryService categoryService;

    public ProductService(ProductRepository productRepository, ModelMapper modelMapper, CategoryService categoryService) {
        this.productRepository = productRepository;
        this.modelMapper = modelMapper;
        this.categoryService = categoryService;
    }

    public void createNewProduct(CreateProductDTO product) {
        ProductEntity createdProduct = this.modelMapper.map(product, ProductEntity.class);

        CategoryEntity category = this.categoryService.findCategoryByName(product.getCategory());

        createdProduct.setCategory(category);

        this.productRepository.save(createdProduct);
    }

    public List<ProductEntity> getAllProductsByCategory(String category) {
        return this.productRepository.findByCategoryName(CategoryEnumeration.valueOf(category));
    }

    public BigDecimal allProductsTotalPrice() {
        return this.productRepository
                                    .findAll()
                                    .stream()
                                    .map(ProductEntity::getPrice)
                                    .reduce(BigDecimal::add)
                                    .orElse(null);
    }

    public void buyAllProducts() {
        this.productRepository.deleteAll();
    }

    public void buyProduct(Long id) {
        this.productRepository.deleteById(id);
    }
}
