package softuni.exam_mvc.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import softuni.exam_mvc.models.sessions.UserSession;
import softuni.exam_mvc.services.ProductService;

@Controller
public class HomeController {

    private final UserSession userSession;
    private final ProductService productService;

    public HomeController(UserSession userSession, ProductService productService) {
        this.userSession = userSession;
        this.productService = productService;
    }

    @GetMapping("/")
    public String homePage(Model model) {
        model.addAttribute("foods", this.productService.getAllProductsByCategory("FOOD"));
        model.addAttribute("drinks", this.productService.getAllProductsByCategory("DRINK"));
        model.addAttribute("households", this.productService.getAllProductsByCategory("HOUSEHOLD"));
        model.addAttribute("others", this.productService.getAllProductsByCategory("OTHER"));
        model.addAttribute("totalPrice", this.productService.allProductsTotalPrice());

        return this.userSession.getLoggedIn() ? "home" : "index";
    }
}