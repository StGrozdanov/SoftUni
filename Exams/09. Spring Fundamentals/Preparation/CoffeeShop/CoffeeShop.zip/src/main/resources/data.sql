INSERT INTO categories (id, name, needed_time)
VALUES (1, 'DRINK', 1);

INSERT INTO categories (id, name, needed_time)
VALUES (2, 'COFFEE', 2);

INSERT INTO categories (id, name, needed_time)
VALUES (3, 'OTHER', 5);

INSERT INTO categories (id, name, needed_time)
VALUES (4, 'CAKE', 10);
