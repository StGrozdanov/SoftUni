package softuni.exam_mvc.models.dtos.UserDTOs;

public class EmployeeDTO {
    private String username;
    private Integer ordersCount;

    public EmployeeDTO() {
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Integer getOrdersCount() {
        return ordersCount;
    }

    public void setOrdersCount(Integer ordersCount) {
        this.ordersCount = ordersCount;
    }
}
