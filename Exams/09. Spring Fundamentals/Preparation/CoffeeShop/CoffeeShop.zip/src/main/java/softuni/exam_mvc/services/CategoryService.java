package softuni.exam_mvc.services;

import org.springframework.stereotype.Service;
import softuni.exam_mvc.models.entities.CategoryEntity;
import softuni.exam_mvc.models.enums.CategoryEnum;
import softuni.exam_mvc.repositories.CategoryRepository;

import java.util.Optional;

@Service
public class CategoryService {
    private CategoryRepository categoryRepository;

    public CategoryService(CategoryRepository categoryRepository) {
        this.categoryRepository = categoryRepository;
    }


    public Optional<CategoryEntity> findCategoryByName(String category) {
        return this.categoryRepository.findByName(CategoryEnum.valueOf(category));
    }
}
