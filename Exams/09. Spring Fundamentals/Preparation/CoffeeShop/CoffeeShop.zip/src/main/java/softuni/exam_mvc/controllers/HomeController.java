package softuni.exam_mvc.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import softuni.exam_mvc.models.sessions.UserSession;
import softuni.exam_mvc.services.OrderService;
import softuni.exam_mvc.services.UserService;

@Controller
public class HomeController {
    private final UserSession userSession;
    private final OrderService orderService;
    private final UserService userService;

    public HomeController(UserSession userSession, OrderService orderService, UserService userService) {
        this.userSession = userSession;
        this.orderService = orderService;
        this.userService = userService;
    }

    @GetMapping("/")
    public String homePage(Model model) {
        if (this.userSession.getLoggedIn()) {
            model.addAttribute("orders", this.orderService.getAllOrders());
            model.addAttribute("employees", this.userService.getAllEmployees());
            model.addAttribute("totalTimeNeeded", this.orderService.getTotalNeededTimeForOrders());

            return "home";
        }
        return "index";
    }
}
