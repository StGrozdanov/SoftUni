package softuni.exam_mvc.models.dtos.CategoryDTO;

public class CategoryDTO {
    private String name;
    private Integer neededTime;

    public CategoryDTO() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getNeededTime() {
        return neededTime;
    }

    public void setNeededTime(Integer neededTime) {
        this.neededTime = neededTime;
    }
}
