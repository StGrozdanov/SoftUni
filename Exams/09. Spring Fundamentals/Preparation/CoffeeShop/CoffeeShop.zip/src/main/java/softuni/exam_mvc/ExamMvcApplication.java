package softuni.exam_mvc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExamMvcApplication {

    public static void main(String[] args) {
        SpringApplication.run(ExamMvcApplication.class, args);
    }

}
