package softuni.exam_mvc.models.enums;

public enum CategoryEnum {
    COFFEE, CAKE, DRINK, OTHER
}
