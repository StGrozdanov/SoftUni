package softuni.exam_mvc.services;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import softuni.exam_mvc.models.dtos.UserDTOs.EmployeeDTO;
import softuni.exam_mvc.models.dtos.UserDTOs.UserLoginDTO;
import softuni.exam_mvc.models.dtos.UserDTOs.UserRegisterDTO;
import softuni.exam_mvc.models.entities.UserEntity;
import softuni.exam_mvc.models.enums.CategoryEnum;
import softuni.exam_mvc.models.sessions.UserSession;
import softuni.exam_mvc.repositories.UserRepository;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Service
public class UserService {
    private UserRepository userRepository;
    private ModelMapper modelMapper;
    private UserSession userSession;

    public UserService(UserRepository userRepository, ModelMapper modelMapper, UserSession userSession) {
        this.userRepository = userRepository;
        this.modelMapper = modelMapper;
        this.userSession = userSession;
    }

    public void registerUser(UserRegisterDTO user) {
        UserEntity createdUser = this.modelMapper.map(user, UserEntity.class);

        this.userRepository.save(createdUser);
    }

    public void userLogin(UserLoginDTO userLoginDTO) {
        UserEntity user = this.userRepository
                .findByUsernameAndPassword(userLoginDTO.getUsername(), userLoginDTO.getPassword())
                .orElse(null);

        this.userSession.setLoggedIn(true);
        this.userSession.setUsername(user.getUsername());
    }

    public void logout() {
        this.userSession.clear();
    }

    public Optional<UserEntity> findUserByUsername(String username) {
        return this.userRepository.findByUsername(username);
    }

    @Transactional
    public List<EmployeeDTO> getAllEmployees() {
        return this.userRepository
                .findAll()
                .stream()
                .map(user -> {
                    EmployeeDTO employee = this.modelMapper.map(user, EmployeeDTO.class);
                    employee.setOrdersCount(user.getOrders().size());
                    return employee;
                })
                .toList();
    }
}