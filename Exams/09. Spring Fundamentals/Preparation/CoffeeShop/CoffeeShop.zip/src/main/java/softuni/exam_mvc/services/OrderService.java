package softuni.exam_mvc.services;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import softuni.exam_mvc.models.dtos.OrderDTOs.CreateOrderDTO;
import softuni.exam_mvc.models.dtos.OrderDTOs.OrderDTO;
import softuni.exam_mvc.models.entities.CategoryEntity;
import softuni.exam_mvc.models.entities.OrderEntity;
import softuni.exam_mvc.models.entities.UserEntity;
import softuni.exam_mvc.models.sessions.UserSession;
import softuni.exam_mvc.repositories.OrderRepository;

import java.util.List;
import java.util.Optional;

@Service
public class OrderService {
    private OrderRepository orderRepository;
    private CategoryService categoryService;
    private ModelMapper modelMapper;
    private UserSession userSession;
    private UserService userService;

    public OrderService(OrderRepository orderRepository, CategoryService categoryService, ModelMapper modelMapper, UserSession userSession, UserService userService) {
        this.orderRepository = orderRepository;
        this.categoryService = categoryService;
        this.modelMapper = modelMapper;
        this.userSession = userSession;
        this.userService = userService;
    }

    public void createNewOrder(CreateOrderDTO createOrderDTO) {
        OrderEntity newOrder = this.modelMapper.map(createOrderDTO, OrderEntity.class);

        Optional<UserEntity> userByUsername = this.userService.findUserByUsername(this.userSession.getUsername());
        Optional<CategoryEntity> categoryByName = this.categoryService.findCategoryByName(createOrderDTO.getCategory());

        userByUsername.ifPresent(newOrder::setEmployee);
        categoryByName.ifPresent(newOrder::setCategory);

        this.orderRepository.save(newOrder);
    }

    public List<OrderDTO> getAllOrders() {
        return this.orderRepository
                .findAll()
                .stream()
                .map(order -> this.modelMapper.map(order, OrderDTO.class))
                .toList();
    }

    public Integer getTotalNeededTimeForOrders() {
        return this.orderRepository
                .findAll()
                .stream()
                .map(order -> order.getCategory().getNeededTime())
                .reduce(Integer::sum)
                .orElse(0);
    }

    public void completeOrder(Long id) {
        this.orderRepository.deleteById(id);
    }
}
