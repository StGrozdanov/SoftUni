package softuni.exam_mvc.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import softuni.exam_mvc.models.dtos.OrderDTOs.CreateOrderDTO;
import softuni.exam_mvc.models.sessions.UserSession;
import softuni.exam_mvc.services.OrderService;

import javax.validation.Valid;

@Controller
public class OrderController {
    private final UserSession userSession;
    private final OrderService orderService;

    public OrderController(UserSession userSession, OrderService orderService) {
        this.userSession = userSession;
        this.orderService = orderService;
    }

    @GetMapping("/orders/add")
    public String addOrderPage() {
        return this.userSession.getLoggedIn() ? "order-add" : "index";
    }

    @PostMapping("/orders/add")
    public String createNewOrder(@Valid CreateOrderDTO createOrderDTO,
                                 BindingResult bindingResult,
                                 RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            redirectAttributes.addFlashAttribute("createOrderModel", createOrderDTO);
            redirectAttributes.addFlashAttribute(
                    "org.springframework.validation.BindingResult.createOrderModel",
                    bindingResult);
            return "redirect:/orders/add";
        }
        this.orderService.createNewOrder(createOrderDTO);
        return "redirect:/";
    }

    @GetMapping("/orders/complete/{id}")
    public String completeOrder(@PathVariable Long id) {
        this.orderService.completeOrder(id);
        return "redirect:/";
    }

    @ModelAttribute(name = "createOrderModel")
    public CreateOrderDTO initOrderModel() {
        return new CreateOrderDTO();
    }
}