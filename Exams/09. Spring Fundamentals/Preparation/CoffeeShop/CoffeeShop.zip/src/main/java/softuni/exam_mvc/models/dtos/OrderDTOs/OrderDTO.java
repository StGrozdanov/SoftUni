package softuni.exam_mvc.models.dtos.OrderDTOs;

import softuni.exam_mvc.models.dtos.CategoryDTO.CategoryDTO;

import java.math.BigDecimal;

public class OrderDTO {
    private Long id;
    private String name;
    private BigDecimal price;
    private CategoryDTO category;

    public OrderDTO() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public CategoryDTO getCategory() {
        return category;
    }

    public void setCategory(CategoryDTO category) {
        this.category = category;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
