package softuni.exam_mvc.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import softuni.exam_mvc.models.sessions.UserSession;
import softuni.exam_mvc.services.AlbumService;

@Controller
public class HomeController {
    private final UserSession userSession;
    private final AlbumService albumService;

    public HomeController(UserSession userSession, AlbumService albumService) {
        this.userSession = userSession;
        this.albumService = albumService;
    }

    @GetMapping("/")
    public String homePage(Model model) {
        if (this.userSession.getLoggedIn()) {
            model.addAttribute("albums", this.albumService.getAllAlbums());
            model.addAttribute("soldAlbumsCount", this.albumService.getSoldAlbumsCount());
            return "home";
        }
        return "index";
    }

}
