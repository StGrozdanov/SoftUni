package softuni.exam_mvc.models.entities;

import softuni.exam_mvc.models.enums.ArtistEnum;

import javax.persistence.*;

@Entity
@Table(name = "artists")
public class ArtistEntity extends BaseEntity {
    private ArtistEnum name;
    private String careerInformation;

    @Enumerated(EnumType.STRING)
    public ArtistEnum getName() {
        return name;
    }

    public void setName(ArtistEnum name) {
        this.name = name;
    }

    @Column(columnDefinition = "TEXT", name = "career_information")
    public String getCareerInformation() {
        return careerInformation;
    }

    public void setCareerInformation(String description) {
        this.careerInformation = description;
    }
}
