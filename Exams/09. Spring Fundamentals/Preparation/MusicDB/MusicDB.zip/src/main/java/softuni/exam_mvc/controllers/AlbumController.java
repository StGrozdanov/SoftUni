package softuni.exam_mvc.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import softuni.exam_mvc.models.dtos.AlbumDTOs.CreateAlbumDTO;
import softuni.exam_mvc.models.sessions.UserSession;
import softuni.exam_mvc.services.AlbumService;

import javax.validation.Valid;

@Controller
public class AlbumController {
    private final UserSession userSession;
    private final AlbumService albumService;

    public AlbumController(UserSession userSession, AlbumService albumService) {
        this.userSession = userSession;
        this.albumService = albumService;
    }

    @GetMapping("/albums/add")
    public String addOrderPage() {
        return this.userSession.getLoggedIn() ? "add-album" : "index";
    }

    @PostMapping("/albums/add")
    public String createNewOrder(@Valid CreateAlbumDTO createAlbumDTO,
                                 BindingResult bindingResult,
                                 RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            redirectAttributes.addFlashAttribute("createAlbumModel", createAlbumDTO);
            redirectAttributes.addFlashAttribute(
                    "org.springframework.validation.BindingResult.createAlbumModel",
                    bindingResult);
            return "redirect:/albums/add";
        }
        this.albumService.createNewAlbum(createAlbumDTO);
        return "redirect:/";
    }

    @GetMapping("/albums/delete/{id}")
    public String deleteAlbum(@PathVariable Long id) {
        this.albumService.deleteAlbum(id);
        return "redirect:/";
    }

    @ModelAttribute(name = "createAlbumModel")
    public CreateAlbumDTO initAlbumModel() {
        return new CreateAlbumDTO();
    }
}