package softuni.exam_mvc.utils.validators.UniqueNameValidator;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class UniqueNameValidator implements ConstraintValidator<UniqueName, String> {
//    private ProductRepository productRepository;
//
//    public UniqueNameValidator(ProductRepository productRepository) {
//        this.productRepository = productRepository;
//    }

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
//        return this.productRepository.findByName(value).isEmpty();
        return true;
    }
}