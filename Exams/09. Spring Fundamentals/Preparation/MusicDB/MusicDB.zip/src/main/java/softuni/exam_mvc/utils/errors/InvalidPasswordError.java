package softuni.exam_mvc.utils.errors;

public class InvalidPasswordError extends Error {
}
