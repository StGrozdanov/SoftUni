package softuni.exam_mvc.models.dtos.AlbumDTOs;

import softuni.exam_mvc.models.entities.ArtistEntity;
import softuni.exam_mvc.models.enums.GenreEnum;

import java.math.BigDecimal;
import java.time.LocalDate;

public class AlbumDTO {
    private Long id;
    private String name;
    private Integer copies;
    private BigDecimal price;
    private LocalDate releasedDate;
    private GenreEnum genre;
    private ArtistEntity artist;

    public AlbumDTO() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getCopies() {
        return copies;
    }

    public void setCopies(Integer copies) {
        this.copies = copies;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public LocalDate getReleasedDate() {
        return releasedDate;
    }

    public void setReleasedDate(LocalDate releasedDate) {
        this.releasedDate = releasedDate;
    }

    public GenreEnum getGenre() {
        return genre;
    }

    public void setGenre(GenreEnum genre) {
        this.genre = genre;
    }

    public ArtistEntity getArtist() {
        return artist;
    }

    public void setArtist(ArtistEntity artist) {
        this.artist = artist;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
