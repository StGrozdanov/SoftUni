package softuni.exam_mvc.models.dtos.UserDTOs;

import org.hibernate.validator.constraints.Length;
import softuni.exam_mvc.utils.validators.MatchingFieldsValidator.FieldsMatcher;
import softuni.exam_mvc.utils.validators.UniqueEmailValidator.UniqueEmail;
import softuni.exam_mvc.utils.validators.UniqueUsernameValidator.UniqueUsername;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@FieldsMatcher(
        firstField = "password",
        secondField = "repeatPassword"
)
public class UserRegisterDTO {
    private String username;
    private String fullName;
    private String email;
    private String password;
    private String repeatPassword;

    public UserRegisterDTO() {
    }

    @NotBlank(message = "Username is required.")
    @Size(min = 3, max = 20, message = "Username length should be between 3 and 20 symbols.")
    @UniqueUsername
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    @NotBlank(message = "Password is required")
    @Size(min = 5, max = 20)
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @NotBlank(message = "Repeat password is required.")
    @Size(min = 5, max = 20, message = "Password length must be between 5 and 20 characters.")
    public String getRepeatPassword() {
        return repeatPassword;
    }

    public void setRepeatPassword(String repeatPassword) {
        this.repeatPassword = repeatPassword;
    }

    @NotBlank(message = "Email is required.")
    @Email(message = "Email should be valid.")
    @UniqueEmail
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @NotBlank
    @Size(min = 3, max = 20)
    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }
}
