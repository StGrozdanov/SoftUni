package softuni.exam_mvc.services;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import softuni.exam_mvc.models.dtos.AlbumDTOs.AlbumDTO;
import softuni.exam_mvc.models.dtos.AlbumDTOs.CreateAlbumDTO;
import softuni.exam_mvc.models.entities.AlbumEntity;
import softuni.exam_mvc.models.entities.ArtistEntity;
import softuni.exam_mvc.models.entities.UserEntity;
import softuni.exam_mvc.models.enums.ArtistEnum;
import softuni.exam_mvc.models.sessions.UserSession;
import softuni.exam_mvc.repositories.AlbumRepository;

import java.util.List;
import java.util.Optional;

@Service
public class AlbumService {
    private AlbumRepository albumRepository;
    private ModelMapper modelMapper;
    private ArtistService artistService;
    private UserSession userSession;
    private UserService userService;

    public AlbumService(AlbumRepository albumRepository, ModelMapper modelMapper, ArtistService artistService, UserSession userSession, UserService userService) {
        this.albumRepository = albumRepository;
        this.modelMapper = modelMapper;
        this.artistService = artistService;
        this.userSession = userSession;
        this.userService = userService;
    }

    public void createNewAlbum(CreateAlbumDTO createAlbumDTO) {
        AlbumEntity album = this.modelMapper.map(createAlbumDTO, AlbumEntity.class);

        ArtistEnum artist = ArtistEnum.valueOf(createAlbumDTO.getArtist());
        Optional<ArtistEntity> artistByName = this.artistService.findArtistByName(artist);

        String username = this.userSession.getUsername();
        Optional<UserEntity> user = this.userService.findUserByUsername(username);

        if (user.isPresent() && artistByName.isPresent()) {
            album.setArtist(artistByName.get());
            album.setAddedFrom(user.get());

            this.albumRepository.save(album);
        }
    }

    public List<AlbumDTO> getAllAlbums() {
        return this.albumRepository
                .findAll()
                .stream()
                .map(album -> this.modelMapper.map(album, AlbumDTO.class))
                .toList();
    }

    public Integer getSoldAlbumsCount() {
        return this.albumRepository
                .findAll()
                .stream()
                .map(AlbumEntity::getCopies)
                .reduce(Integer::sum)
                .orElse(0);
    }

    public void deleteAlbum(Long id) {
        this.albumRepository.deleteById(id);
    }
}
