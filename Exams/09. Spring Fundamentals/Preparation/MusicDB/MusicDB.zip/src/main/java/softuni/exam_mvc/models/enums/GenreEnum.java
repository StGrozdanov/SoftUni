package softuni.exam_mvc.models.enums;

public enum GenreEnum {
    POP, ROCK, METAL, OTHER
}
