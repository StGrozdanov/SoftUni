package softuni.exam_mvc.services;

import org.springframework.stereotype.Service;
import softuni.exam_mvc.models.entities.ArtistEntity;
import softuni.exam_mvc.models.enums.ArtistEnum;
import softuni.exam_mvc.repositories.ArtistRepository;

import java.util.Optional;

@Service
public class ArtistService {
    private ArtistRepository artistRepository;

    public ArtistService(ArtistRepository artistRepository) {
        this.artistRepository = artistRepository;
    }


    public Optional<ArtistEntity> findArtistByName(ArtistEnum artist) {
        return this.artistRepository.findArtistEntityByName(artist);
    }
}
