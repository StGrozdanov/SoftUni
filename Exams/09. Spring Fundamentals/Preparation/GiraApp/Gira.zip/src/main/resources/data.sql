INSERT INTO classifications (id, classification_name, description)
VALUES (1, 'BUG', 'A bug is a bug');

INSERT INTO classifications (id, classification_name, description)
VALUES (2, 'FEATURE', 'A feature is a feature');

INSERT INTO classifications (id, classification_name, description)
VALUES (3, 'SUPPORT', 'A support is a support');

INSERT INTO classifications (id, classification_name, description)
VALUES (4, 'OTHER', 'A other is ... a other?');