package softuni.exam_mvc.services;

import org.springframework.stereotype.Service;
import softuni.exam_mvc.models.entities.ClassificationEntity;
import softuni.exam_mvc.models.enums.ClassificationEnum;
import softuni.exam_mvc.repositories.ClassificationRepository;

import java.util.Optional;

@Service
public class ClassificationService {
    private ClassificationRepository classificationRepository;

    public ClassificationService(ClassificationRepository classificationRepository) {
        this.classificationRepository = classificationRepository;
    }

    public Optional<ClassificationEntity> findClassificationByName(ClassificationEnum classification) {
        return this.classificationRepository.findByClassificationName(classification);
    }
}
