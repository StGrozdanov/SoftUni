package softuni.exam_mvc.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import softuni.exam_mvc.models.dtos.TaskDTOs.CreateTaskDTO;
import softuni.exam_mvc.models.sessions.UserSession;
import softuni.exam_mvc.services.TaskService;

import javax.validation.Valid;

@Controller
public class TaskController {
    private final UserSession userSession;
    private final TaskService taskService;

    public TaskController(UserSession userSession, TaskService taskService) {
        this.userSession = userSession;
        this.taskService = taskService;
    }

    @GetMapping("/tasks/add")
    public String addOrderPage() {
        return this.userSession.getLoggedIn() ? "add-task" : "index";
    }

    @PostMapping("/tasks/add")
    public String createNewOrder(@Valid CreateTaskDTO createTaskDTO,
                                 BindingResult bindingResult,
                                 RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            redirectAttributes.addFlashAttribute("createTaskModel", createTaskDTO);
            redirectAttributes.addFlashAttribute(
                    "org.springframework.validation.BindingResult.createTaskModel",
                    bindingResult);
            return "redirect:/tasks/add";
        }
        this.taskService.createNewTask(createTaskDTO);
        return "redirect:/";
    }

    @GetMapping("/tasks/progress/{id}")
    public String progressTask(@PathVariable Long id) {
        this.taskService.progressTask(id);

        return "redirect:/";
    }

    @ModelAttribute(name = "createTaskModel")
    public CreateTaskDTO initTaskModel() {
        return new CreateTaskDTO();
    }
}