package softuni.exam_mvc.services;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import softuni.exam_mvc.models.dtos.TaskDTOs.CreateTaskDTO;
import softuni.exam_mvc.models.entities.ClassificationEntity;
import softuni.exam_mvc.models.entities.TaskEntity;
import softuni.exam_mvc.models.entities.UserEntity;
import softuni.exam_mvc.models.enums.ProgressEnum;
import softuni.exam_mvc.models.sessions.UserSession;
import softuni.exam_mvc.repositories.TaskRepository;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Service
public class TaskService {
    private TaskRepository taskRepository;
    private ModelMapper modelMapper;
    private UserSession userSession;
    private UserService userService;
    private ClassificationService classificationService;

    public TaskService(TaskRepository taskRepository, ModelMapper modelMapper, UserSession userSession, UserService userService, ClassificationService classificationService) {
        this.taskRepository = taskRepository;
        this.modelMapper = modelMapper;
        this.userSession = userSession;
        this.userService = userService;
        this.classificationService = classificationService;
    }

    public void createNewTask(CreateTaskDTO createTaskDTO) {
        String loggedUsername = this.userSession.getUsername();

        Optional<UserEntity> user = this.userService.findUserByUsername(loggedUsername);
        Optional<ClassificationEntity> classificationByName = this.classificationService
                .findClassificationByName(createTaskDTO.getClassification());

        if (user.isPresent() && classificationByName.isPresent()) {
            TaskEntity task = this.modelMapper.map(createTaskDTO, TaskEntity.class);

            ProgressEnum progress = ProgressEnum.OPEN;

            task.setUser(user.get());
            task.setProgress(progress);
            task.setClassification(classificationByName.get());

            this.taskRepository.save(task);
        }
    }

    public List<TaskEntity> getAllTasks() {
        return this.taskRepository.findAll();
    }

    @Transactional
    public void progressTask(Long id) {
        Optional<TaskEntity> task = this.taskRepository.findById(id);
        if (task.isPresent()) {
            TaskEntity taskToUpdate = task.get();

            int currentProgress = ProgressEnum.valueOf(taskToUpdate.getProgress().name()).ordinal();
            int updatedProgress = currentProgress + 1;

            ProgressEnum newProgress = ProgressEnum.values()[updatedProgress];

            if (newProgress.name().equals("OTHER")) {
                this.taskRepository.delete(taskToUpdate);
            } else {
                taskToUpdate.setProgress(newProgress);
                this.taskRepository.save(taskToUpdate);
            }
        }
    }
}
