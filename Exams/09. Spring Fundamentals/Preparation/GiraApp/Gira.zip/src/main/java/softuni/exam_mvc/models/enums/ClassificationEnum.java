package softuni.exam_mvc.models.enums;

public enum ClassificationEnum {
    BUG, FEATURE, SUPPORT, OTHER
}
