package softuni.exam_mvc.models.entities;

import softuni.exam_mvc.models.enums.ClassificationEnum;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;

@Entity
@Table(name = "classifications")
public class ClassificationEntity extends BaseEntity {
    private ClassificationEnum classificationName;
    private String description;

    @Enumerated(EnumType.STRING)
    public ClassificationEnum getClassificationName() {
        return classificationName;
    }

    public void setClassificationName(ClassificationEnum classificationName) {
        this.classificationName = classificationName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
