package softuni.exam_mvc.models.dtos.TaskDTOs;

import org.springframework.format.annotation.DateTimeFormat;
import softuni.exam_mvc.models.enums.ClassificationEnum;
import softuni.exam_mvc.utils.validators.UniqueNameValidator.UniqueName;

import javax.validation.constraints.*;
import java.time.LocalDate;

public class CreateTaskDTO {
    private String name;
    private String description;
    private LocalDate dueDate;
    private ClassificationEnum classification;

    public CreateTaskDTO() {
    }

    @NotBlank(message = "Task name is required")
    @Size(min = 3, max = 20, message = "Task name length should be between 3 and 20 characters")
    @UniqueName
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @NotBlank
    @Size(min = 5)
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @NotNull
    @FutureOrPresent
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    public LocalDate getDueDate() {
        return dueDate;
    }

    public void setDueDate(LocalDate dueDate) {
        this.dueDate = dueDate;
    }

    @NotNull
    public ClassificationEnum getClassification() {
        return classification;
    }

    public void setClassification(ClassificationEnum classification) {
        this.classification = classification;
    }
}
