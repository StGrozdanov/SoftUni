package softuni.exam_mvc.models.enums;

public enum ProgressEnum {
    OPEN, IN_PROGRESS, COMPLETED, OTHER
}
