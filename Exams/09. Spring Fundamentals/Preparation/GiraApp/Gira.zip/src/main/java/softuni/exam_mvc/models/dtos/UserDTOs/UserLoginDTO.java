package softuni.exam_mvc.models.dtos.UserDTOs;

import org.hibernate.validator.constraints.Length;
import softuni.exam_mvc.utils.validators.CorrectCredentialsValidator.CredentialsValidator;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@CredentialsValidator(
        firstField = "email",
        secondField = "password"
)
public class UserLoginDTO {
    private String email;
    private String password;

    public UserLoginDTO() {
    }

    @NotBlank
    @Email
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @NotBlank
    @Size(min = 3, max = 20)
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
