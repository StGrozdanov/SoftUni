package softuni.exam_mvc.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import softuni.exam_mvc.models.entities.ClassificationEntity;
import softuni.exam_mvc.models.enums.ClassificationEnum;

import java.util.Optional;

@Repository
public interface ClassificationRepository extends JpaRepository<ClassificationEntity, Long> {
    Optional<ClassificationEntity> findByClassificationName(ClassificationEnum classification);
}
