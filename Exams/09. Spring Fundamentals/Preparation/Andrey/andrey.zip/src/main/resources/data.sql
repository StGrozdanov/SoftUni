# INSERT INTO categories (id, name, description)
# VALUES (1, 0, 'Aggressive ships with high attack and low defense');
#
# INSERT INTO categories (id, name, description)
# VALUES (2, 1, 'Transport ships');
#
# INSERT INTO categories (id, name, description)
# VALUES (3, 2, 'Spy ships');