package softuni.exam_mvc.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import softuni.exam_mvc.models.dtos.ProductDTOs.CreateProductDTO;
import softuni.exam_mvc.models.dtos.ProductDTOs.ProductDTO;
import softuni.exam_mvc.models.sessions.UserSession;
import softuni.exam_mvc.services.ProductService;

import javax.validation.Valid;

@Controller
public class ProductController {
    private final UserSession userSession;
    private final ProductService productService;

    public ProductController(UserSession userSession, ProductService productService) {
        this.userSession = userSession;
        this.productService = productService;
    }

    @GetMapping("/products/add")
    public String addOrderPage() {
        return this.userSession.getLoggedIn() ? "add-product" : "index";
    }

    @PostMapping("/products/add")
    public String createNewOrder(@Valid CreateProductDTO createProductDTO,
                                 BindingResult bindingResult,
                                 RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            redirectAttributes.addFlashAttribute("createProductModel", createProductDTO);
            redirectAttributes.addFlashAttribute(
                    "org.springframework.validation.BindingResult.createProductModel",
                    bindingResult);
            return "redirect:/products/add";
        }
        this.productService.createNewOrder(createProductDTO);
        return "redirect:/";
    }

    @GetMapping("/products/details/{id}")
    public String productDetailsPage(@PathVariable Long id, Model model) {
        if (this.userSession.getLoggedIn()) {
            ProductDTO product = this.productService.getProductById(id);
            model.addAttribute("product", product);
            return "details-product";
        }
        return "index";
    }

    @PostMapping("/products/delete/{id}")
    public String productDelete(@PathVariable Long id) {
        if (this.userSession.getLoggedIn()) {
            this.productService.deleteProduct(id);
            return "redirect:/";
        }
        return "index";
    }


    @ModelAttribute(name = "createProductModel")
    public CreateProductDTO initProductModel() {
        return new CreateProductDTO();
    }
}