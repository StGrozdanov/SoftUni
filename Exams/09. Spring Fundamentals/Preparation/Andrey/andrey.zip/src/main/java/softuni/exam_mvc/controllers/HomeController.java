package softuni.exam_mvc.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import softuni.exam_mvc.models.dtos.ProductDTOs.ProductDTO;
import softuni.exam_mvc.models.sessions.UserSession;
import softuni.exam_mvc.services.ProductService;

import java.util.List;

@Controller
public class HomeController {
    private final UserSession userSession;
    private final ProductService productService;

    public HomeController(UserSession userSession, ProductService productService) {
        this.userSession = userSession;
        this.productService = productService;
    }

    @GetMapping("/")
    public String homePage(Model model) {
        if (this.userSession.getLoggedIn()) {
            List<ProductDTO> products = this.productService.getAllProducts();
            model.addAttribute("products", products);
            return "home";
        }
        return "index";
    }
}
