package softuni.exam_mvc.services;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import softuni.exam_mvc.models.dtos.ProductDTOs.CreateProductDTO;
import softuni.exam_mvc.models.dtos.ProductDTOs.ProductDTO;
import softuni.exam_mvc.models.entities.ProductEntity;
import softuni.exam_mvc.repositories.ProductRepository;

import java.util.List;

@Service
public class ProductService {
    private ProductRepository productRepository;
    private ModelMapper modelMapper;

    public ProductService(ProductRepository productRepository, ModelMapper modelMapper) {
        this.productRepository = productRepository;
        this.modelMapper = modelMapper;
    }

    public void createNewOrder(CreateProductDTO createProductDTO) {
        ProductEntity product = this.modelMapper.map(createProductDTO, ProductEntity.class);
        this.productRepository.save(product);
    }

    public ProductDTO getProductById(Long id) {
        ProductEntity product = this.productRepository.findById(id).orElse(null);
        ProductDTO targetProduct = this.modelMapper.map(product, ProductDTO.class);

        return targetProduct;
    }

    public List<ProductDTO> getAllProducts() {
        return this.productRepository
                .findAll()
                .stream()
                .map(product -> this.modelMapper.map(product, ProductDTO.class))
                .toList();
    }

    public void deleteProduct(Long id) {
        this.productRepository.deleteById(id);
    }
}
