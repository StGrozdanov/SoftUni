package softuni.exam_mvc.models.dtos.UserDTOs;

import org.hibernate.validator.constraints.Length;
import softuni.exam_mvc.utils.validators.CorrectCredentialsValidator.CredentialsValidator;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@CredentialsValidator(
        firstField = "username",
        secondField = "password"
)
public class UserLoginDTO {
    private String username;
    private String password;

    public UserLoginDTO() {
    }

    @NotBlank
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    @NotBlank
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
