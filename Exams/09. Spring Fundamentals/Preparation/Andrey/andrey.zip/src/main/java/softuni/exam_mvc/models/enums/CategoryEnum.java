package softuni.exam_mvc.models.enums;

public enum CategoryEnum {
    SHIRT, DENIM, SHORTS, JACKET
}
