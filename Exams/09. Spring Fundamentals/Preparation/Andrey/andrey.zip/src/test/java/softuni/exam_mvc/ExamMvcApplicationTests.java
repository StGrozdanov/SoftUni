package softuni.exam_mvc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamMvcApplicationTests {

    @Test
    void contextLoads() {
    }

}
