package softuni.exam_mvc.models.dtos.UserDTOs;

import org.hibernate.validator.constraints.Length;
import softuni.exam_mvc.utils.validators.MatchingFieldsValidator.FieldsMatcher;
import softuni.exam_mvc.utils.validators.UniqueEmailValidator.UniqueEmail;
import softuni.exam_mvc.utils.validators.UniqueUsernameValidator.UniqueUsername;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@FieldsMatcher(
        firstField = "password",
        secondField = "repeatPassword"
)
public class RegisterUserDTO {
    private String username;
    private String password;
    private String repeatPassword;
    private String fullName;
    private String email;

    public RegisterUserDTO() {
    }

    @NotBlank(message = "Username is required.")
    @Length(min = 3, max = 10, message = "Username length should be between 3 and 10 symbols.")
    @UniqueUsername
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    @NotBlank(message = "Password is required")
    @Size(min = 4)
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @NotBlank(message = "Repeat password is required.")
    public String getRepeatPassword() {
        return repeatPassword;
    }

    public void setRepeatPassword(String repeatPassword) {
        this.repeatPassword = repeatPassword;
    }

    @NotBlank
    @Size(min = 5, max = 20)
    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    @Email(message = "email should be valid")
    @NotBlank(message = "email is required")
    @UniqueEmail
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
