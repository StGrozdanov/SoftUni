package softuni.exam_mvc.models.dtos.UserDTOs;

import org.hibernate.validator.constraints.Length;
import softuni.exam_mvc.utils.validators.CorrectCredentialsValidator.CredentialsValidator;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@CredentialsValidator(
        firstField = "username",
        secondField = "password"
)
public class LoginUserDTO {
    private String username;
    private String password;

    public LoginUserDTO() {
    }

    @NotBlank
    @Length(min = 3, max = 10)
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    @NotBlank
    @Size(min = 4)
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
