package softuni.exam_mvc.services;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import softuni.exam_mvc.models.dtos.ShipDTOs.AttackShipDTO;
import softuni.exam_mvc.models.dtos.ShipDTOs.CreateShipDTO;
import softuni.exam_mvc.models.entities.CategoryEntity;
import softuni.exam_mvc.models.entities.ShipEntity;
import softuni.exam_mvc.models.entities.UserEntity;
import softuni.exam_mvc.models.sessions.UserSession;
import softuni.exam_mvc.repositories.ShipRepository;

import javax.transaction.Transactional;
import java.util.List;

@Service
public class ShipService {
    private ShipRepository shipRepository;
    private ModelMapper modelMapper;
    private UserSession userSession;
    private UserService userService;
    private CategoryService categoryService;

    public ShipService(ShipRepository shipRepository, ModelMapper modelMapper, UserSession userSession, UserService userService, CategoryService categoryService) {
        this.shipRepository = shipRepository;
        this.modelMapper = modelMapper;
        this.userSession = userSession;
        this.userService = userService;
        this.categoryService = categoryService;
    }

    public void createNewShip(CreateShipDTO createShipDTO) {
        ShipEntity ship = this.modelMapper.map(createShipDTO, ShipEntity.class);

        if (!userSession.getLoggedIn()) {
            return;
        }

        CategoryEntity category = this.categoryService.getCategoryByName(createShipDTO.getCategory());
        UserEntity user = this.userService.getUserByUsername(userSession.getUsername());

        ship.setCategory(category);
        ship.setUser(user);

        this.shipRepository.save(ship);
    }

    public List<ShipEntity> getCurrentUserShips() {
        return this.shipRepository.findAllByUser_Username(this.userSession.getUsername());
    }

    public List<ShipEntity> getAllShipsExceptCurrentUserShips() {
        return this.shipRepository.findAllByUser_UsernameNot(this.userSession.getUsername());
    }

    public List<ShipEntity> getAllShips() {
        return this.shipRepository.findAll();
    }

    @Transactional
    public void attackShip(AttackShipDTO attackShipDTO) {
        ShipEntity userShip = this.shipRepository.findById(attackShipDTO.getOwnerShipId()).get();
        ShipEntity enemyShip = this.shipRepository.findById(attackShipDTO.getDatabaseShipId()).get();

        enemyShip.takeDamage(userShip.getPower());

        if (enemyShip.getHealth() <= 0) {
            this.shipRepository.delete(enemyShip);
        } else {
            this.shipRepository.save(enemyShip);
        }
    }
}
