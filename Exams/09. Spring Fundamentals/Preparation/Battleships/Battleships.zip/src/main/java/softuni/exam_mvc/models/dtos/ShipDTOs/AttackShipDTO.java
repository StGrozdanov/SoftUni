package softuni.exam_mvc.models.dtos.ShipDTOs;

public class AttackShipDTO {
    private Long ownerShipId;
    private Long databaseShipId;

    public AttackShipDTO() {
    }

    public void setOwnerShipId(Long ownerShipId) {
        this.ownerShipId = ownerShipId;
    }

    public void setDatabaseShipId(Long databaseShipId) {
        this.databaseShipId = databaseShipId;
    }

    public Long getOwnerShipId() {
        return ownerShipId;
    }

    public Long getDatabaseShipId() {
        return databaseShipId;
    }
}
