package softuni.exam_mvc.models.dtos.ShipDTOs;

import org.springframework.format.annotation.DateTimeFormat;
import softuni.exam_mvc.models.enums.CategoryNameEnum;
import softuni.exam_mvc.utils.validators.UniqueShipNameValidator.UniqueShipName;

import javax.validation.constraints.*;
import java.time.LocalDate;

public class CreateShipDTO {
    private String name;
    private Integer power;
    private Integer health;
    private LocalDate created;
    private CategoryNameEnum category;

    public CreateShipDTO() {
    }

    @NotBlank(message = "Ship name is required")
    @Size(min = 2, max = 10, message = "Ship name should be between 2 and 10 characters")
    @UniqueShipName
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @NotNull
    @Positive
    public Integer getPower() {
        return power;
    }

    public void setPower(Integer power) {
        this.power = power;
    }

    @NotNull
    @Positive
    public Integer getHealth() {
        return health;
    }

    public void setHealth(Integer health) {
        this.health = health;
    }

    @NotNull
    @PastOrPresent
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    public LocalDate getCreated() {
        return created;
    }

    public void setCreated(LocalDate created) {
        this.created = created;
    }

    @NotNull
    public CategoryNameEnum getCategory() {
        return category;
    }

    public void setCategory(CategoryNameEnum category) {
        this.category = category;
    }
}