package softuni.exam_mvc.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import softuni.exam_mvc.models.entities.ShipEntity;

import java.util.List;
import java.util.Optional;

@Repository
public interface ShipRepository extends JpaRepository<ShipEntity, Long> {
    Optional<ShipEntity> findByName(String name);

    List<ShipEntity> findAllByUser_Username(String username);

    List<ShipEntity> findAllByUser_UsernameNot(String username);
}
