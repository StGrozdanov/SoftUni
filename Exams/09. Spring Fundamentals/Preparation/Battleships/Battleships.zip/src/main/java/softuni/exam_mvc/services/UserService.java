package softuni.exam_mvc.services;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import softuni.exam_mvc.models.dtos.UserDTOs.LoginUserDTO;
import softuni.exam_mvc.models.dtos.UserDTOs.RegisterUserDTO;
import softuni.exam_mvc.models.entities.UserEntity;
import softuni.exam_mvc.models.sessions.UserSession;
import softuni.exam_mvc.repositories.UserRepository;

@Service
public class UserService {
    private UserRepository userRepository;
    private ModelMapper modelMapper;
    private UserSession userSession;

    public UserService(UserRepository userRepository, ModelMapper modelMapper, UserSession userSession) {
        this.userRepository = userRepository;
        this.modelMapper = modelMapper;
        this.userSession = userSession;
    }

    public void registerUser(RegisterUserDTO user) {
        UserEntity createdUser = this.modelMapper.map(user, UserEntity.class);

        this.userRepository.save(createdUser);
    }

    public void userLogin(LoginUserDTO userLoginDTO) {
        UserEntity user = this.userRepository
                .findByUsernameAndPassword(userLoginDTO.getUsername(), userLoginDTO.getPassword())
                .orElse(null);

        this.userSession.setLoggedIn(true);
        this.userSession.setUsername(user.getUsername());
    }

    public void logout() {
        this.userSession.clear();
    }

    public UserEntity getUserByUsername(String username) {
        return this.userRepository.findByUsername(username).orElse(null);
    }
}