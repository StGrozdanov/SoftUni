package softuni.exam_mvc.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import softuni.exam_mvc.models.dtos.UserDTOs.LoginUserDTO;
import softuni.exam_mvc.models.dtos.UserDTOs.RegisterUserDTO;
import softuni.exam_mvc.services.UserService;

import javax.validation.Valid;

@Controller
@RequestMapping("/users")
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/login")
    public String loginPage() {
        return "login";
    }

    @PostMapping("/register")
    public String registerPage(
            @Valid RegisterUserDTO user,
            BindingResult bindingResult,
            RedirectAttributes redirectAttributes)
    {
        if (bindingResult.hasErrors()) {
            handleUserPostErrors(user, bindingResult, redirectAttributes);
            return "redirect:/users/register";
        }

        this.userService.registerUser(user);
        return "redirect:/users/login";
    }

    @PostMapping("login")
    public String loginUser(
            @Valid LoginUserDTO userLoginDTO,
            BindingResult bindingResult,
            RedirectAttributes redirectAttributes)
    {
        if (bindingResult.hasErrors()) {
            handleUserPostErrors(userLoginDTO, bindingResult, redirectAttributes);
            return "redirect:/users/login";
        }

        this.userService.userLogin(userLoginDTO);
        return "redirect:/";
    }

    @GetMapping("/register")
    public String registerPage() {
        return "register";
    }

    @GetMapping("/logout")
    public String logout() {
        this.userService.logout();
        return "redirect:/";
    }

    @ModelAttribute("userModel")
    public RegisterUserDTO initUserModel() {
        return new RegisterUserDTO();
    }

    private void handleUserPostErrors(Object userInput, BindingResult bindingResult, RedirectAttributes redirectAttributes) {
        redirectAttributes.addFlashAttribute("userModel", userInput);
        redirectAttributes.addFlashAttribute("org.springframework.validation.BindingResult.userModel",
                bindingResult);
    }
}
