package softuni.exam_mvc.services;

import org.springframework.stereotype.Service;
import softuni.exam_mvc.models.entities.CategoryEntity;
import softuni.exam_mvc.models.enums.CategoryNameEnum;
import softuni.exam_mvc.repositories.CategoryRepository;

@Service
public class CategoryService {
    private CategoryRepository categoryRepository;

    public CategoryService(CategoryRepository categoryRepository) {
        this.categoryRepository = categoryRepository;
    }


    public CategoryEntity getCategoryByName(CategoryNameEnum category) {
        return this.categoryRepository.findByName(category);
    }
}
