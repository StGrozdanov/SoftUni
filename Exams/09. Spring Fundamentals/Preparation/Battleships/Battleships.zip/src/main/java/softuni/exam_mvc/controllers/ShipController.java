package softuni.exam_mvc.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import softuni.exam_mvc.models.dtos.ShipDTOs.CreateShipDTO;
import softuni.exam_mvc.services.ShipService;

import javax.validation.Valid;

@Controller
public class ShipController {

    private ShipService shipService;

    public ShipController(ShipService shipService) {
        this.shipService = shipService;
    }

    @GetMapping("/add-ship")
    public String addShipPage() {
        return "ship-add";
    }

    @PostMapping("/add-ship")
    public String createShip(@Valid CreateShipDTO createShipDTO,
                             BindingResult bindingResult,
                             RedirectAttributes redirectAttributes)
    {
        if (bindingResult.hasErrors()) {
            redirectAttributes.addFlashAttribute("createShipModel", createShipDTO);
            redirectAttributes.addFlashAttribute("org.springframework.validation.BindingResult.createShipModel",
                    bindingResult);
            return "redirect:/add-ship";
        }

        this.shipService.createNewShip(createShipDTO);
        return "redirect:/";
    }

    @ModelAttribute("createShipModel")
    public CreateShipDTO initShip() {
        return new CreateShipDTO();
    }
}
