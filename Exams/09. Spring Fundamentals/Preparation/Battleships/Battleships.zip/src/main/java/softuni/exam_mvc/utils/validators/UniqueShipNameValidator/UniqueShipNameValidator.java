package softuni.exam_mvc.utils.validators.UniqueShipNameValidator;

import softuni.exam_mvc.repositories.ShipRepository;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class UniqueShipNameValidator implements ConstraintValidator<UniqueShipName, String> {
    private ShipRepository shipRepository;

    public UniqueShipNameValidator(ShipRepository shipRepository) {
        this.shipRepository = shipRepository;
    }

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        return this.shipRepository.findByName(value).isEmpty();
    }
}