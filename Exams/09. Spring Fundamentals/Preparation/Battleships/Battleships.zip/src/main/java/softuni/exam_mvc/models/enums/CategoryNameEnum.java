package softuni.exam_mvc.models.enums;

public enum CategoryNameEnum {
    BATTLE, CARGO, PATROL
}
