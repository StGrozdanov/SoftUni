package softuni.exam_mvc.utils.validators.CorrectCredentialsValidator;

import org.springframework.beans.BeanWrapper;
import org.springframework.beans.PropertyAccessorFactory;
import softuni.exam_mvc.repositories.UserRepository;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.util.Objects;

public class CorrectCredentialsValidator implements ConstraintValidator<CredentialsValidator, Object> {
    private String firstField;
    private String secondField;
    private String message;
    private UserRepository userRepository;

    @Override
    public void initialize(CredentialsValidator constraintAnnotation) {
        this.firstField = constraintAnnotation.firstField();
        this.secondField = constraintAnnotation.secondField();
        this.message = constraintAnnotation.message();
    }

    public CorrectCredentialsValidator(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public boolean isValid(Object value, ConstraintValidatorContext context) {
        BeanWrapper wrapper = PropertyAccessorFactory.forBeanPropertyAccess(value);

        String firstValue = Objects.requireNonNull(wrapper.getPropertyValue(this.firstField)).toString();
        String secondValue = Objects.requireNonNull(wrapper.getPropertyValue(this.secondField)).toString();

        boolean isValid = this.userRepository.findByUsernameAndPassword(firstValue, secondValue).isPresent();

        if (!isValid) {
            appendFieldViolations(context);
        }

        return isValid;
    }

    private void appendFieldViolations(ConstraintValidatorContext context) {
        context
                .buildConstraintViolationWithTemplate(this.message)
                .addConstraintViolation()
                .disableDefaultConstraintViolation();
    }
}
