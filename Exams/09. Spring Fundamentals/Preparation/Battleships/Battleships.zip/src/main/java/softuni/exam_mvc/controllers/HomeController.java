package softuni.exam_mvc.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import softuni.exam_mvc.models.dtos.ShipDTOs.AttackShipDTO;
import softuni.exam_mvc.models.sessions.UserSession;
import softuni.exam_mvc.services.ShipService;

@Controller
public class HomeController {
    private UserSession userSession;
    private ShipService shipService;

    public HomeController(UserSession userSession, ShipService shipService) {
        this.userSession = userSession;
        this.shipService = shipService;
    }

    @GetMapping("/")
    public String homePage(Model model) {
        model.addAttribute("userShips", this.shipService.getCurrentUserShips());
        model.addAttribute("otherUsersShips", this.shipService.getAllShipsExceptCurrentUserShips());
        model.addAttribute("allShips", this.shipService.getAllShips());

        return this.userSession.getLoggedIn() ? "home" : "index";
    }

    @PostMapping("/")
    public String attackShip(AttackShipDTO attackShipDTO) {
        this.shipService.attackShip(attackShipDTO);

        return "redirect:/";
    }

    @ModelAttribute(name = "attackShipDTO")
    public AttackShipDTO initializeAttackShip() {
        return new AttackShipDTO();
    }
}
