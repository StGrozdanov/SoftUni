INSERT INTO styles (id, style_name, description)
VALUES (1, 'ROCK', 'Some description here');

INSERT INTO styles (id, style_name, description)
VALUES (2, 'POP', 'Some description here');

INSERT INTO styles (id, style_name, description)
VALUES (3, 'JAZZ', 'Some description here');