package softuni.exam_mvc.services;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import softuni.exam_mvc.models.dtos.SongDTOs.CreateSongDTO;
import softuni.exam_mvc.models.dtos.SongDTOs.SongCollectionDTO;
import softuni.exam_mvc.models.entities.SongEntity;
import softuni.exam_mvc.models.entities.StyleEntity;
import softuni.exam_mvc.models.entities.UserEntity;
import softuni.exam_mvc.models.enums.StyleEnum;
import softuni.exam_mvc.repositories.SongRepository;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Service
public class SongService {
    private SongRepository songRepository;
    private ModelMapper modelMapper;
    private StyleService styleService;
    private UserService userService;

    public SongService(SongRepository songRepository, ModelMapper modelMapper, StyleService styleService, UserService userService) {
        this.songRepository = songRepository;
        this.modelMapper = modelMapper;
        this.styleService = styleService;
        this.userService = userService;
    }

    public void createNewSong(CreateSongDTO createSongDTO) {
        Optional<StyleEntity> styleByStyleName = this.styleService.findStyleByStyleName(createSongDTO.getStyle());

        if (styleByStyleName.isPresent()) {
            SongEntity createdSong = this.modelMapper.map(createSongDTO, SongEntity.class);
            createdSong.setStyle(styleByStyleName.get());

            this.songRepository.save(createdSong);
        }
    }

    public List<SongCollectionDTO> getAllPopSongs() {
        return this.songRepository
                .findAllByStyle_StyleName(StyleEnum.POP)
                .stream()
                .map(style -> this.modelMapper.map(style, SongCollectionDTO.class))
                .toList();
    }

    public List<SongCollectionDTO> getAllRockSongs() {
        return this.songRepository
                .findAllByStyle_StyleName(StyleEnum.ROCK)
                .stream()
                .map(style -> this.modelMapper.map(style, SongCollectionDTO.class))
                .toList();
    }

    public List<SongCollectionDTO> getAllJazzSongs() {
        return this.songRepository
                .findAllByStyle_StyleName(StyleEnum.JAZZ)
                .stream()
                .map(style -> this.modelMapper.map(style, SongCollectionDTO.class))
                .toList();
    }

    @Transactional
    public void addSongToUserPlaylist(Long id, String username) {
        Optional<UserEntity> userByUsername = this.userService.findUserByUsername(username);
        Optional<SongEntity> songById = this.songRepository.findById(id);

        if (userByUsername.isPresent() && songById.isPresent()) {
            UserEntity user = userByUsername.get();
            SongEntity song = songById.get();

            user.getPlaylist().add(song);

            this.userService.saveUserPlaylist(user);
        }
    }
}
