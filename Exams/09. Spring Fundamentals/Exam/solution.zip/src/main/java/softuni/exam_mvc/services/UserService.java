package softuni.exam_mvc.services;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import softuni.exam_mvc.models.dtos.SongDTOs.SongCollectionDTO;
import softuni.exam_mvc.models.dtos.UserDTOs.UserLoginDTO;
import softuni.exam_mvc.models.dtos.UserDTOs.UserPlaylistDTO;
import softuni.exam_mvc.models.dtos.UserDTOs.UserRegisterDTO;
import softuni.exam_mvc.models.entities.SongEntity;
import softuni.exam_mvc.models.entities.UserEntity;
import softuni.exam_mvc.models.sessions.UserSession;
import softuni.exam_mvc.repositories.UserRepository;

import javax.transaction.Transactional;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

@Service
public class UserService {
    private UserRepository userRepository;
    private ModelMapper modelMapper;
    private UserSession userSession;

    public UserService(UserRepository userRepository, ModelMapper modelMapper, UserSession userSession) {
        this.userRepository = userRepository;
        this.modelMapper = modelMapper;
        this.userSession = userSession;
    }

    public void registerUser(UserRegisterDTO user) {
        UserEntity createdUser = this.modelMapper.map(user, UserEntity.class);

        this.userRepository.save(createdUser);
    }

    public void userLogin(UserLoginDTO userLoginDTO) {
        UserEntity user = this.userRepository
                .findByUsernameAndPassword(userLoginDTO.getUsername(), userLoginDTO.getPassword())
                .orElse(null);

        this.userSession.setLoggedIn(true);
        this.userSession.setUsername(user.getUsername());
    }

    public void logout() {
        this.userSession.clear();
    }

    @Transactional
    public UserPlaylistDTO getCurrentUserPlaylist(String username) {
        UserPlaylistDTO userPlaylistDTO = new UserPlaylistDTO();

        Optional<UserEntity> optionalUser = this.userRepository.findByUsername(username);

        if (optionalUser.isEmpty()) {
            return userPlaylistDTO;
        }

        UserEntity user = optionalUser.get();

        List<SongEntity> userPlaylist = user.getPlaylist();

        List<SongCollectionDTO> songCollectionDTOS = userPlaylist
                .stream()
                .map(song -> this.modelMapper.map(song, SongCollectionDTO.class))
                .toList();

        int totalPlaylistDurationSeconds = songCollectionDTOS
                .stream()
                .map(SongCollectionDTO::getDuration)
                .reduce(Integer::sum).orElse(0);

        String durationInMinutesAndSeconds = getDurationInMinutesAndSeconds(totalPlaylistDurationSeconds);

        userPlaylistDTO.setId(user.getId());
        userPlaylistDTO.setSongs(songCollectionDTOS);
        userPlaylistDTO.setDuration(durationInMinutesAndSeconds);

        return userPlaylistDTO;
    }

    public Optional<UserEntity> findUserByUsername(String username) {
        return this.userRepository.findByUsername(username);
    }

    @Transactional
    public void saveUserPlaylist(UserEntity user) {
        this.userRepository.save(user);
    }

    @Transactional
    public void clearUserPlaylist(Long id) {
        Optional<UserEntity> userById = this.userRepository.findById(id);

        if (userById.isPresent()) {
            UserEntity user = userById.get();
            user.getPlaylist().clear();

            this.userRepository.save(user);
        }
    }

    private String getDurationInMinutesAndSeconds(int duration) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("mm:ss");
        LocalTime time = LocalTime.MIN.plusSeconds(duration);

        return formatter.format(time);
    }

}