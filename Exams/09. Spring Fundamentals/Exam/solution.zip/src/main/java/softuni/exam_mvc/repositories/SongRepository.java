package softuni.exam_mvc.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import softuni.exam_mvc.models.entities.SongEntity;
import softuni.exam_mvc.models.enums.StyleEnum;

import java.util.List;
import java.util.Optional;

@Repository
public interface SongRepository extends JpaRepository<SongEntity, Long> {
    List<SongEntity> findAllByStyle_StyleName(StyleEnum styleName);

    Optional<SongEntity> findByPerformer(String value);
}