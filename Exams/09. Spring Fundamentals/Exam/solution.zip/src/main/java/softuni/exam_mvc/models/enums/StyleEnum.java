package softuni.exam_mvc.models.enums;

public enum StyleEnum {
    POP, ROCK, JAZZ
}
