package softuni.exam_mvc.services;

import org.springframework.stereotype.Service;
import softuni.exam_mvc.models.entities.StyleEntity;
import softuni.exam_mvc.models.enums.StyleEnum;
import softuni.exam_mvc.repositories.StyleRepository;

import java.util.Optional;

@Service
public class StyleService {
    private StyleRepository styleRepository;

    public StyleService(StyleRepository styleRepository) {
        this.styleRepository = styleRepository;
    }

    public Optional<StyleEntity> findStyleByStyleName(StyleEnum style) {
        return this.styleRepository.findByStyleName(style);
    }
}
