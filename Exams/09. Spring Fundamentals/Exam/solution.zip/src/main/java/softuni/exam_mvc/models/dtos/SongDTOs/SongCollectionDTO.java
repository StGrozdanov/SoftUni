package softuni.exam_mvc.models.dtos.SongDTOs;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class SongCollectionDTO {
    private Long id;
    private String performer;
    private String title;
    private Integer duration;

    public SongCollectionDTO() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getPerformer() {
        return performer;
    }

    public void setPerformer(String performer) {
        this.performer = performer;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Integer getDuration() {
        return duration;
    }

    public void setDuration(Integer duration) {
        this.duration = duration;
    }

    public String getDurationInMinutesAndSeconds() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("mm:ss");
        LocalTime time = LocalTime.MIN.plusSeconds(duration);

        return formatter.format(time);
    }

    @Override
    public String toString() {
        String minutesAndSeconds = getDurationInMinutesAndSeconds();

        return String.format("%s - %s (%s min)",
                this.performer,
                this.title,
                minutesAndSeconds
        );
    }
}
