package softuni.exam_mvc.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import softuni.exam_mvc.models.dtos.UserDTOs.UserLoginDTO;
import softuni.exam_mvc.models.dtos.UserDTOs.UserRegisterDTO;
import softuni.exam_mvc.models.sessions.UserSession;
import softuni.exam_mvc.services.UserService;

import javax.validation.Valid;

@Controller
@RequestMapping("/users")
public class UserController {
    private final UserSession userSession;
    private final UserService userService;

    public UserController(UserSession userSession, UserService userService) {
        this.userSession = userSession;
        this.userService = userService;
    }

    @GetMapping("/register")
    public String registerPage() {
        return this.userSession.getLoggedIn() ? "redirect:/" : "register";
    }

    @PostMapping("/register")
    public String registerPage(
            @Valid UserRegisterDTO user,
            BindingResult bindingResult,
            RedirectAttributes redirectAttributes)
    {
        if (this.userSession.getLoggedIn()) {
            return "redirect:/";
        }

        if (bindingResult.hasErrors()) {
            handleUserPostErrors(user, bindingResult, redirectAttributes, "userRegisterModel");
            return "redirect:/users/register";
        }

        this.userService.registerUser(user);
        return "redirect:/users/login";
    }

    @GetMapping("/login")
    public String loginPage() {
        return this.userSession.getLoggedIn() ? "redirect:/" : "login";
    }

    @PostMapping("login")
    public String loginUser(
            @Valid UserLoginDTO userLoginDTO,
            BindingResult bindingResult,
            RedirectAttributes redirectAttributes)
    {
        if (this.userSession.getLoggedIn()) {
            return "redirect:/";
        }

        if (bindingResult.hasErrors()) {
            handleUserPostErrors(userLoginDTO, bindingResult, redirectAttributes, "userLoginModel");
            return "redirect:/users/login";
        }

        this.userService.userLogin(userLoginDTO);
        return "redirect:/";
    }

    @GetMapping("/logout")
    public String logout() {
        this.userService.logout();
        return "redirect:/";
    }

    @ModelAttribute("userRegisterModel")
    public UserRegisterDTO initUserRegisterModel() {
        return new UserRegisterDTO();
    }

    @ModelAttribute("userLoginModel")
    public UserLoginDTO initUserLoginModel() {
        return new UserLoginDTO();
    }

    private void handleUserPostErrors(
            Object model,
            BindingResult bindingResult,
            RedirectAttributes redirectAttributes,
            String modelName
    ) {
        redirectAttributes.addFlashAttribute(modelName, model);
        redirectAttributes.addFlashAttribute(
                String.format("org.springframework.validation.BindingResult.%s", modelName),
                bindingResult
        );
    }
}