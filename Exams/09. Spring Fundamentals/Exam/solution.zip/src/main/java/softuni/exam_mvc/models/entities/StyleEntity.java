package softuni.exam_mvc.models.entities;

import softuni.exam_mvc.models.enums.StyleEnum;

import javax.persistence.*;

@Entity
@Table(name = "styles")
public class StyleEntity extends BaseEntity {
    private StyleEnum styleName;
    private String description;

    @Enumerated(EnumType.STRING)
    @Column(name = "style_name", unique = true, nullable = false)
    public StyleEnum getStyleName() {
        return styleName;
    }

    public void setStyleName(StyleEnum styleName) {
        this.styleName = styleName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
