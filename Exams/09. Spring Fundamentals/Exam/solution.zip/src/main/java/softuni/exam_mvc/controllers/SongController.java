package softuni.exam_mvc.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import softuni.exam_mvc.models.dtos.SongDTOs.CreateSongDTO;
import softuni.exam_mvc.models.sessions.UserSession;
import softuni.exam_mvc.services.SongService;
import softuni.exam_mvc.services.UserService;

import javax.validation.Valid;

@Controller
@RequestMapping("/songs")
public class SongController {
    private final UserSession userSession;
    private final SongService songService;
    private final UserService userService;

    public SongController(UserSession userSession, SongService songService, UserService userService) {
        this.userSession = userSession;
        this.songService = songService;
        this.userService = userService;
    }

    @GetMapping("/add")
    public String addSongPage() {
        return this.userSession.getLoggedIn() ? "song-add" : "index";
    }

    @PostMapping("/add")
    public String createNewSong(@Valid CreateSongDTO createSongDTO,
                                BindingResult bindingResult,
                                RedirectAttributes redirectAttributes) {

        if (!this.userSession.getLoggedIn()) {
            return "redirect:/";
        }

        if (bindingResult.hasErrors()) {
            redirectAttributes.addFlashAttribute("createSongModel", createSongDTO);
            redirectAttributes.addFlashAttribute(
                    "org.springframework.validation.BindingResult.createSongModel",
                    bindingResult);
            return "redirect:/songs/add";
        }
        this.songService.createNewSong(createSongDTO);
        return "redirect:/";
    }

    @GetMapping("/addPlaylist/{id}")
    public String addSongToPlaylist(@PathVariable Long id) {
        if (!this.userSession.getLoggedIn()) {
            return "redirect:/";
        }

        this.songService.addSongToUserPlaylist(id, this.userSession.getUsername());

        return "redirect:/";
    }

    @GetMapping("/clearPlaylist/{id}")
    public String clearPlaylist(@PathVariable Long id) {
        if (!this.userSession.getLoggedIn()) {
            return "redirect:/";
        }

        this.userService.clearUserPlaylist(id);

        return "redirect:/";
    }

    @ModelAttribute(name = "createSongModel")
    public CreateSongDTO initSongModel() {
        return new CreateSongDTO();
    }
}