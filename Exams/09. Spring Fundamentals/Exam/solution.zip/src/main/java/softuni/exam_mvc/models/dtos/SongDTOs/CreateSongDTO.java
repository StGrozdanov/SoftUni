package softuni.exam_mvc.models.dtos.SongDTOs;

import org.springframework.format.annotation.DateTimeFormat;
import softuni.exam_mvc.models.enums.StyleEnum;
import softuni.exam_mvc.utils.validators.UniqueNameValidator.UniqueName;

import javax.validation.constraints.*;
import java.time.LocalDate;

public class CreateSongDTO {
    private String performer;
    private String title;
    private LocalDate releaseDate;
    private Integer duration;
    private StyleEnum style;

    public CreateSongDTO() {
    }

    @NotBlank(message = "Performer name is required")
    @Size(min = 3, max = 20, message = "Performer name length should be between 3 and 20 characters")
    @UniqueName
    public String getPerformer() {
        return performer;
    }

    public void setPerformer(String performer) {
        this.performer = performer;
    }

    @NotBlank
    @Size(min = 2, max = 20)
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    @PastOrPresent
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    public LocalDate getReleaseDate() {
        return releaseDate;
    }

    public void setReleaseDate(LocalDate releaseDate) {
        this.releaseDate = releaseDate;
    }

    @NotNull
    @Positive
    public Integer getDuration() {
        return duration;
    }

    public void setDuration(Integer duration) {
        this.duration = duration;
    }

    @NotNull
    public StyleEnum getStyle() {
        return style;
    }

    public void setStyle(StyleEnum style) {
        this.style = style;
    }
}
