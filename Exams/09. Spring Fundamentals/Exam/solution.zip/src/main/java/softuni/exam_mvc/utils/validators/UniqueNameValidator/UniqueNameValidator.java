package softuni.exam_mvc.utils.validators.UniqueNameValidator;

import softuni.exam_mvc.repositories.SongRepository;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class UniqueNameValidator implements ConstraintValidator<UniqueName, String> {
    private SongRepository songRepository;

    public UniqueNameValidator(SongRepository songRepository) {
        this.songRepository = songRepository;
    }

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        return this.songRepository.findByPerformer(value).isEmpty();
    }
}