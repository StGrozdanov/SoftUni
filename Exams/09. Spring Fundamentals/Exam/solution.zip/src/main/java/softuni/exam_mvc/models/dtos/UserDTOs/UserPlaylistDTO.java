package softuni.exam_mvc.models.dtos.UserDTOs;

import softuni.exam_mvc.models.dtos.SongDTOs.SongCollectionDTO;

import java.util.ArrayList;
import java.util.List;

public class UserPlaylistDTO {
    private List<SongCollectionDTO> songs;
    private String duration;
    private long id;

    public UserPlaylistDTO() {
        this.songs = new ArrayList<>();
        this.duration = "0:00";
        this.id = 0;
    }

    public List<SongCollectionDTO> getSongs() {
        return songs;
    }

    public void setSongs(List<SongCollectionDTO> songs) {
        this.songs = songs;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }
}
